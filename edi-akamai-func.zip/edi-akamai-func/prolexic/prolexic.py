import requests
import gzip
import json
import datetime
import time
import os
import hashlib
import logging
from datetime import timezone
from akamai.edgegrid import EdgeGridAuth
from azure.storage.blob import ContentSettings, BlobServiceClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.keyvault.secrets import SecretClient
import azure.functions as func
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

# log error format
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("requests.packages.urllib3")

class Export:
    def __init__(self):
        self.utcTimeNow = datetime.datetime.utcnow()
        self.execStart = self.utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.startDate = (self.utcTimeNow - datetime.timedelta(hours=24)).replace(hour=0, minute=0, second=0)
        self.endDate = self.startDate + datetime.timedelta(hours=24)
        self.startTime = (self.utcTimeNow - datetime.timedelta(minutes=30)).replace(second=0, microsecond=0)
        self.endTime = self.startTime + datetime.timedelta(minutes=30)
        self.blobFolderName = self.utcTimeNow.strftime('%Y%m%d%H%M')
        self.epocSubFolderName = str(int(time.time()))
        self.feedName = "prolexic"
        self.basePath = self.feedName + "\\" + self.blobFolderName + "\\" + self.epocSubFolderName + "\\"
        self.fileNameSuffix = ".json.gz"

        self.proxyDict = {
            "http" : os.getenv("OUTBOUND_PROXY"),
            "https": os.getenv("OUTBOUND_PROXY")
        }

    def compressConnectUpload(self, data, fileName):
        blobPath = self.basePath + fileName + self.fileNameSuffix

        try:
            dataIn = json.dumps(data)
            dataInEncoded = dataIn.encode('utf-8')
            dataOut = gzip.compress(dataInEncoded)

            try:
                self.connectBlob()

                try:
                    blob = self.blobContainerClient.get_blob_client(blobPath)

                    blobContentSettings = ContentSettings (
                        content_encoding="gzip"
                        ,content_type='application/octec-stream'
                    )

                    blob.upload_blob (
                        dataOut
                        ,blob_type='BlockBlob'
                        ,content_settings=blobContentSettings
                    )
                except Exception as e:
                    logger.error("Error Uploading Blob:  Akamai Prolexic: " + blobPath + " >> " + str(e))
            except Exception as e:
                logger.error("Error connecting to Azure Blob Storage: Akamai Prolexic >> " + str(e))

        except Exception as e:
            logger.error("Error Gzipping data >> "+str(e))

    def connectUpload(self, data, fileName):
        blobPath = self.basePath + fileName
        dataOut = json.dumps(data)
        try:
            self.connectBlob()

            try:
                blob = self.blobContainerClient.get_blob_client(blobPath)

                blobContentSettings = ContentSettings (
                    content_type='application/json'
                )

                blob.upload_blob (
                    dataOut
                    ,blob_type='BlockBlob'
                    ,content_settings=blobContentSettings
                )
            except Exception as e:
                logger.error("Error Uploading Blob:  Akamai Prolexic: " + blobPath + " >> " + str(e))
        except Exception as e:
            logger.error("Error connecting to Azure Blob Storage: Akamai Prolexic >> " + str(e))

    def connectBlob(self):
        try:
            msiCredential = ManagedIdentityCredential()
            credentialChain = ChainedTokenCredential(msiCredential)

            blobServiceClient = BlobServiceClient(
                os.getenv("DATASOURCE_STORAGE_URL")
                ,credential=credentialChain
            )

            self.blobContainerClient = blobServiceClient.get_container_client("default")

            logger.info('Successfully Connected To Blob')
        except Exception as e:
            logger.critical("Unable To Connect Blob"+str(e))
            raise

    def readSecrets(self):
        try:
            secretClient = SecretClient(
                vault_url=os.getenv("DATASOURCE_KEYVAULT_URL"), credential=ManagedIdentityCredential())
            secret = secretClient.get_secret("credentialsProlexic")
            self.credentials = json.loads(secret.value)

            self.url = self.credentials['url']
            self.contracts = self.credentials['contracts']
            self.auth = EdgeGridAuth(
                client_token=self.credentials['client_token']
                ,client_secret=self.credentials['client_secret']
                ,access_token=self.credentials['access_token']
            )

            logger.info('Successfully Fetched Secrets From KeyVault')
        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical("Azure SDK was not able to connect to Key Vault", cae)
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical("Possible wrong Vault name given", hse)
        except ServiceRequestError:
            # Network error, I will let it raise to higher level
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical("Azure SDK was not able to deal with my query", ae)
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical("Unknown error I can't blame Azure for", e)
            raise

    def download(self):
        self.readSecrets()

        self.knownAttackReports, self.knownEvents, self.knownCriticalEvents = [], [], []

        # for each contract download reports
        for c in self.contracts:
            logger.info("Working on contract "+c)
            self.subnets = []
            self.downloadMetricsTypes(c)
            self.downloadMetricsData(c)
            self.downloadAttackReports(c)
            self.downloadEvents(c)
            self.downloadCriticalEvents(c)

        self.compressConnectUpload(self.knownAttackReports, "attackReports")
        self.compressConnectUpload(self.knownEvents, "events")
        self.compressConnectUpload(self.knownCriticalEvents, "criticalEvents")

        logger.info('Successfully Written attakReportIDs,eventIDs,criticalEventIDs Files')
        self.writeSuccessFile()

    def downloadMetricsTypes(self, contract):
        logger.info("Downloading Metrics Types...")
        for i in range(0, 10):
            try:
                req = requests.get(
                    "{}/prolexic-analytics/v2/metric-types/{}".format(self.url, contract)
                    ,auth=self.auth
                    ,proxies=self.proxyDict
                )
                resp = req.json()
                break
            except Exception as e:
                if i == 9:
                    logger.warning("Request Failed")
                    logger.warning(str(e))
                    raise e
                logger.debug("Request Failed, Retrying in 10s")
                time.sleep(10)
        try:
            if resp["status"] != True:
                return False
        except:
            logger.warning(req.text)
            return False
        data = []
        data = resp['data']
        self.subnets = data['fbm']['metrics']['bandwidth']['subnets']

        self.compressConnectUpload(data, "{}-metrics_types".format(contract))

        logger.info('Successfully Written metric-types file')
        return True

    def downloadMetricsData(self, contract):
        logger.info("Downloading Metrics Data...")
        samples = 30
        body = {}
        body['contract'] = contract
        body['start'] = int(self.startTime.timestamp())
        body['end'] = int(self.endTime.timestamp())
        body['samples'] = samples
        body['type'] = {}
        body['type']['routed'] = ["bandwidthIn", "packetsIn"]
        body['type']['connect'] = ["bandwidthIn", "packetsIn"]
        body['type']['mitigationPost'] = ["packets", "bandwidth"]
        body['type']['mitigationPre'] = ["packets", "bandwidth"]
        body['type']['proxy'] = ["latency", "bandwidthIn", "bandwidthOut",
                                 "connections", "packetsOut", "requests", "packetsIn"]

        for i in range(0, 10):
            try:
                req = requests.post(
                    "{}/prolexic-analytics/v2/metrics".format(self.url)
                    ,json=body
                    ,auth=self.auth
                    ,proxies=self.proxyDict
                )

                resp = req.json()
                break
            except Exception as e:
                if i == 9:
                    logger.warning("request failed")
                    logger.warning(str(e))
                    raise e
                logger.debug("Request Failed, Retrying in 10s")
                time.sleep(10)
        try:
            if resp["status"] != True:
                return False
        except:
            logger.warning(req.text)
            return False
        data = []
        data = resp['data']
        for subnet in self.subnets:
            body['contract'] = contract
            body['start'] = int(self.startTime.timestamp())
            body['end'] = int(self.endTime.timestamp())
            body['samples'] = samples
            body['type'] = {}
            body['type']['fbm'] = []
            body['type']['fbm'].append({
                "metric": "bandwidth",
                "protocol": "total",
                "subnet": subnet
            })
            for i in range(0, 10):
                try:
                    req = requests.post(
                        "{}/prolexic-analytics/v2/metrics".format(self.url)
                        ,json=body
                        ,auth=self.auth
                        ,proxies=self.proxyDict
                    )
                    resp = req.json()
                    break
                except Exception as e:
                    if i == 9:
                        logger.warning("request failed")
                        logger.warning(str(e))
                        raise e
                    logger.debug("request failed, retrying in 10s")
                    time.sleep(10)
            try:
                if resp["status"] != True:
                    return False
            except:
                logger.warning(req.text)
                return False
            data.append(resp['data'])

        self.compressConnectUpload(data, "{}-metrics_data".format(contract))

        logger.info('Successfully Written metric-data file')
        return True

    def downloadAttackReports(self, contract):
        logger.info("Downloading Attack Reports...")
        for i in range(0, 10):
            try:
                req = requests.get(
                    "{}/prolexic-analytics/v2/attack-reports/contract/{}/start/{}/end/{}"
                        .format(self.url, contract, int(self.startDate.timestamp())-(60*60*24*30), int(self.endDate.timestamp()))
                    ,auth=self.auth
                    ,proxies=self.proxyDict
                )
                resp = req.json()
                break
            except Exception as e:
                if i == 9:
                    logger.warning("request failed")
                    logger.warning(str(e))
                    raise e
                logger.debug("request failed, retrying in 10s")
                time.sleep(10)
        try:
            if resp["data"] == 'Incorrect URI or Data doesnt exist':
                return True
            if resp["status"] != True:
                return False
        except:
            logger.warning(req.text)
            return False
        data = []
        for e in resp['data']:
            if e['attackId'] in self.knownAttackReports:
                continue
            data.append(e)
            self.knownAttackReports.append(e['attackId'])

        self.compressConnectUpload(data, "{}-attack_reports".format(contract))

        logger.info('Successfully Written attack-reports file')
        return True

    def downloadEvents(self, contract):
        logger.info("Downloading Events...")
        for i in range(0, 10):
            try:
                req = requests.get(
                    "{}/prolexic-analytics/v2/events/contract/{}".format(self.url, contract)
                    ,auth=self.auth
                    ,proxies=self.proxyDict
                )
                resp = req.json()
                break
            except Exception as e:
                if i == 9:
                    logger.warning("request failed")
                    logger.warning(str(e))
                    raise e
                logger.debug("request failed, retrying in 10s")
                time.sleep(10)
        try:
            if 'statusMsg' in resp and resp['statusMsg'] == "Query successful. No data returned.":
                return True
            if resp["status"] != True:
                return False
        except:
            logger.warning(req.text)
            return False
        data = []
        for e in resp['data']:
            h = hashlib.sha1(json.dumps(
                e, sort_keys=True).encode()).hexdigest()
            if h in self.knownEvents:
                continue
            data.append(e)
            self.knownEvents.append(h)
        self.knownEventsData = self.knownEvents

        self.compressConnectUpload(data, "{}-events".format(contract))

        logger.info('Successfully Written events file')
        return True

    def downloadCriticalEvents(self, contract):
        logger.info("Downloading Critical Events...")
        for i in range(0, 10):
            try:
                req = requests.get(
                    "{}/prolexic-analytics/v2/critical-events/contract/{}".format(self.url, contract)
                    ,auth=self.auth
                    ,proxies=self.proxyDict
                )
                resp = req.json()
                break
            except Exception as e:
                if i == 9:
                    logger.warning("request failed")
                    logger.warning(str(e))
                    raise e
                logger.debug("request failed, retrying in 10s")
                time.sleep(10)
        try:
            if 'statusMsg' in resp and resp['statusMsg'] == "Query successful. No data returned.":
                return True
            if resp["status"] != True:
                return False
        except:
            logger.warning(req.text)
            return False
        data = []
        for e in resp['data']:
            h = hashlib.sha1(json.dumps(
                e, sort_keys=True).encode()).hexdigest()
            if h in self.knownCriticalEvents:
                continue
            data.append(e)
            self.knownCriticalEvents.append(h)

        self.compressConnectUpload(data, "{}-critical_events".format(contract))

        logger.info('Successfully Written critical-events file')
        return True

    def writeSuccessFile(self):  # construct success file and write to dest location
        try:
            blob_list = self.blobContainerClient.list_blobs(
                name_starts_with="{}/{}/{}".format(
                    self.feedName, self.blobFolderName, self.epocSubFolderName))
            fileLoadedCount = len(list(blob_list))

            if fileLoadedCount > 0:  # write success file only when data is loaded
                successFile = {}
                successFile["ediFunctionName"] = "kk-cde-edi-dev-neu-fa-py-akami"
                successFile["ediTriggerType"] = "TimerTrigger"
                successFile["ediFunctionLoadStatus"] = "Success"
                successFile["ediFeedRunStartDtTime"] = self.execStart
                successFile["ediFeedRunEndDtTime"] = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                successFile["ediFilesWritten"] = fileLoadedCount
                successFile["ediDestinationPath"] = self.feedName + "/" + self.blobFolderName + "/" + self.epocSubFolderName

                self.connectUpload(successFile, "EDISTG_SUCCESS.json")

                logger.info("Successfully Written EDISTG_SUCCESS file")
            else:
                logger.info("There Is No Data Available To Load")
        except Exception as e:
            logging.error("Unable To write EDISTG_SUCCESS file"+str(e))

# For Timer trigger
# {
#   "scriptFile": "__init__.py",
#   "bindings": [
#     {
#       "name": "mytimer",
#       "type": "timerTrigger",
#       "direction": "in",
#       "schedule": "0 */30 * * * *"
#     }
#   ]
# }

def main(mytimer: func.TimerRequest) -> None:
    logger.info('Starting To Loading Akamai Prolexic Data')
    mod = Export()  # create object for class
    mod.download()  # function call
    logger.info('Successfully Loaded Akamai Prolexic Data')

# For HTTP Trigger
# {
#   "scriptFile": "__init__.py",
#   "bindings": [
#     {
#       "authLevel": "anonymous",
#       "type": "httpTrigger",
#       "direction": "in",
#       "name": "req",
#       "methods": [
#         "get",
#         "post"
#       ]
#     },
#     {
#       "type": "http",
#       "direction": "out",
#       "name": "$return"
#     }
#   ]
# }

# def main(req: func.HttpRequest) -> func.HttpResponse:
#     logger.info('Starting To Loading Akamai Prolexic Data')

#     mod = Export()  # create object for class
#     mod.download()  # function call

#     logger.info('Successfully Loaded Akamai Prolexic Data')

#     return func.HttpResponse(f"Hello Akamai Prolexic user. This HTTP triggered function executed successfully.")
