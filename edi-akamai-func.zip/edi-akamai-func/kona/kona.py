import requests
import gzip
import json
import datetime
import time
import os
import re
import logging
from akamai.edgegrid import EdgeGridAuth
from azure.storage.blob import ContentSettings, BlobServiceClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.keyvault.secrets import SecretClient
import azure.functions as func
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    AzureError
)

# log error format
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("akamaiKona")

class Export:

    def __init__(self):
        self.utcTimeNow        = datetime.datetime.utcnow()
        self.execStart         = self.utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.blobFolderName    = self.utcTimeNow.strftime('%Y%m%d%H%M')
        self.feedName          = "kona"
        self.epocSubFolderName = str(int(time.time()))
        self.basePath          = "{}/{}/{}/".format(self.feedName, self.blobFolderName, self.epocSubFolderName)
        self.fileNameSuffix    = ".json.gz"
        self.proxyDict         = {
            "http" : os.getenv("OUTBOUND_PROXY"),
            "https": os.getenv("OUTBOUND_PROXY")
        }
        self.connectBlob()
        self.readSecrets()

    def connectBlob(self):
        try:
            msiCredential     = ManagedIdentityCredential()
            credentialChain   = ChainedTokenCredential(msiCredential)
            blobServiceClient = BlobServiceClient(
                os.environ["DATASOURCE_STORAGE_URL"]
                ,credential   = credentialChain
            )
            containerName = "default"
            self.blobContainerClient = blobServiceClient.get_container_client(containerName)

            logger.info('EDI-AKAMAI-FUNC-KONA-Successfully Connected To Blob')
        except Exception as e:
            logger.critical("EDI-AKAMAI-FUNC-KONA-Exception-Unable To Connect Blob: {}".format(e))
            raise    

    def readSecrets(self):
        try:
            secretClient = SecretClient(
                            vault_url  = os.environ["DATASOURCE_KEYVAULT_URL"], 
                            credential = ManagedIdentityCredential()
                            )
            secret = secretClient.get_secret("credentialsKona")
            self.credentials = json.loads(secret.value)
            self.baseUrl   = self.credentials['url']
            self.configids = self.credentials['configids']
            self.auth      = EdgeGridAuth(client_token = self.credentials['client_token']
                                    ,client_secret = self.credentials['client_secret']
                                    ,access_token = self.credentials['access_token']
            )
            logger.info('EDI-AKAMAI-FUNC-KONA-Successfully Fetched Secrets From KeyVault')


        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical("EDI-AKAMAI-FUNC-KONA-Exception-Function:readSecrets - Azure SDK was not able to connect to Key Vault", cae)
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical("EDI-AKAMAI-FUNC-KONA-Exception-Function:readSecrets - Possible wrong Vault name given", hse)
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            logger.critical("EDI-AKAMAI-FUNC-KONA-Exception-Function:readSecrets - service request error", sre)
            raise
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical("EDI-AKAMAI-FUNC-KONA-Exception-Function:readSecrets - Azure SDK was not able to deal with my query", ae)
            raise
        except KeyError as ke:
            # the key many not be found in application settings)
            logger.critical("EDI-AKAMAI-FUNC-KONA-Exception-Function:readSecrets - KeyError:The key may not be present in application setting", ke)
            raise 
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical("EDI-AKAMAI-FUNC-KONA-Exception-Function:readSecrets -Unknown error I can't blame Azure for", e)
            raise       

    def connectUpload(self, data, fileName):

        try:

            #create different path for success file and laststop
            if "EDISTG_SUCCESS" in fileName:
                self.blobPath      = self.basePath + fileName  
                self.overWriteBool = False

            elif "konaLastStop" in fileName:
                self.blobPath = self.feedName+'/'+fileName
                self.overWriteBool = True

            self.dataOut = json.dumps(data)
            blob = self.blobContainerClient.get_blob_client(self.blobPath)
            blobContentSettings = ContentSettings (
                content_type='application/json'
            )

            blob.upload_blob (
                self.dataOut
                ,blob_type='BlockBlob'
                ,content_settings=blobContentSettings
                ,overwrite = self.overWriteBool
            )
        except Exception as e:
            logger.error("EDI-AKAMAI-FUNC-KONA-Exception connecting to Azure Blob Storage: Akamai Kona >> {}".format(e))
            raise    

    def compressConnectUpload(self, data, fileName):

        self.blobPath = self.basePath + fileName + self.fileNameSuffix

        try:
            dataIn = json.dumps(data)
            dataInEncoded = dataIn.encode('utf-8')
            dataOut = gzip.compress(dataInEncoded)

            blob = self.blobContainerClient.get_blob_client(self.blobPath)

            blobContentSettings = ContentSettings (
                content_encoding = "gzip"
                ,content_type = 'application/octec-stream'
            )

            blob.upload_blob (
                dataOut
                ,blob_type='BlockBlob'
                ,content_settings=blobContentSettings 
            )

        except Exception as e:
            logger.error("EDI-AKAMAI-FUNC-KONA-Exception Gzipping data >> {}".format(e)) 

    def urlCall(self,queryStringVal,configId):

        try:
            for i in range(0,5):

                try:
                    url = "{}/siem/v1/configs/{}".format(self.baseUrl,configId)
                    headers = {"Accept": "application/json"}
                    queryString = queryStringVal

                    #get the response from end point 
                    response = requests.request("GET"
                    , url
                    , headers = headers
                    ,auth = self.auth
                    ,params = queryString
                    ,proxies = self.proxyDict
                    #,verify = False
                    )
                    logger.info("EDI-AKAMAI-FUNC-KONA-success: url has been invoked")
                    break

                except Exception as e:
                    if i == 4:
                        logger.warning("EDI-AKAMAI-FUNC-KONA-request failed:{}".format(e))
                        raise
                    logger.debug("EDI-AKAMAI-FUNC-KONA-request failed, retrying in 10s")
                    time.sleep(10)

            #read the response data(json msg break) as list
            if ("total" in response.text[-5000:]):

                contentList = response.text.splitlines()
                logger.info("EDI-AKAMAI-FUNC-KONA-success: read the response as list") 

                #load data into blob as json
                eachChunkFileLen = 10000
                fileCount = 0
                #cast text data into json
                jsonDataList = [json.loads(data) for data in contentList]
                totalLen = len(jsonDataList)
                for idx in range(0,totalLen,eachChunkFileLen):
                    fileCount += 1
                    data = jsonDataList[idx:idx+eachChunkFileLen] #split data
                    self.compressConnectUpload(data,"{}_configid_{}".format(fileCount,configId)) 
                    logger.info("EDI-AKAMAI-FUNC-KONA-success: uploaded compressed data to blob")

                message   = json.loads(contentList[-1])
                self.lastStopdata['offset_{}'.format(configId)] = message['offset']

                #fetch the latest date from the last data loaded;used in case of offset expires.
                if len(contentList) > 1:
                    lastLoadedDate =  json.loads(contentList[-2])
                    self.lastStopdata['date_{}'.format(configId)] = lastLoadedDate["httpMessage"]["start"]
                else:
                    self.lastStopdata['date_{}'.format(configId)] = ""

            #logic: if offset is expired,load the data based on last loaded date
            elif "Expired offset parameter in the request" in response.text:

                logger.info("EDI-AKAMAI-FUNC-KONA-Inside offset expired response block..call url based on date") 

                startDate = self.lastStopdata['date_{}'.format(configId)]
                if len(startDate) > 0:
                    queryStringVal = { "from": startDate,"limit":"50000"}
                    self.urlCall(queryStringVal,configId)
                else: 
                    queryStringVal = { "from": "946684800","limit":"50000"}
                    self.urlCall(queryStringVal,configId)   

        except Exception as e:
            logger.error("EDI-AKAMAI-FUNC-KONA-Exception urlCall function :{}".format(e))
            raise

    def downloadData(self):

        try:
            #check if my laststop exists in default/kona folder,else create empty offset file
            blob_client  = self.blobContainerClient.get_blob_client("{}/konaLastStop.json".format(self.feedName))
            exists       = blob_client.exists()
            self.lastStopdata = {}
            #load the existsing laststop
            if exists == True:
                self.lastStopdata = json.loads(blob_client.download_blob().readall())

                logger.info("EDI-AKAMAI-FUNC-KONA-Reading konaLastStop file from default/kona folder")

            #for every configId,
            # if the configId present in previous laststop use its offset,
            # else add the new configid with empty offset
            for configId in self.configids:  

                if configId in self.lastStopdata:
                    offsetVal  = self.lastStopdata["offset_{}".format(configId)]

                else:
                    offsetVal  = ""
                    self.lastStopdata["offset_{}".format(configId)] = offsetVal
              
                logger.info("EDI-AKAMAI-FUNC-KONA-Retrieved offset from konalaststop file")

                #if offset exist,call url with offset & limit
                if len(offsetVal) > 0:
                    logger.info("EDI-AKAMAI-FUNC-KONA-Offset exist in konalaststop..retrieving data in offset mode")
                    queryStringVal = { "offset": offsetVal,"limit":"50000"}
                    self.urlCall(queryStringVal,configId) # execute url      

                #if offset doesn't exist,call url with from(January 1,2000 12:00:00 AM) and limit
                else:
                    logger.info("EDI-AKAMAI-FUNC-KONA-Offset doesn't exist in konalaststop..retrieving data in timebased mode")
                    queryStringVal = { "from": "946684800","limit":"50000"}
                    self.urlCall(queryStringVal,configId) # execute url

            #check if new offset is append to dict;prevent empty dict write to laststop file
            if len(self.configids) == len(re.findall("offset",json.dumps(self.lastStopdata))):
                self.connectUpload(self.lastStopdata,"konaLastStop.json")
                logger.info("EDI-AKAMAI-FUNC-KONA-success: overwritten offset to konalaststop file")

            #after successful execution
            self.writeSuccessFile() 

        except TypeError as te:
            logger.critical(str(te))
            raise
        except Exception as e:
            logger.error("EDI-AKAMAI-FUNC-KONA-Error downloadData function :{}".format(e))
            raise     

    def writeSuccessFile(self):  # construct success file and write to dest location
        try:

            blob_list = self.blobContainerClient.list_blobs(name_starts_with="{}/{}/{}".format(self.feedName, self.blobFolderName, self.epocSubFolderName))
            fileLoadedCount = len(list(blob_list))

            if fileLoadedCount > 0:  # write success file only when data is loaded
                successFile = {}
                successFile["ediFunctionName"]       = "kk-cde-edi-prd-neu-fa-py-akami-kona"
                successFile["ediTriggerType"]        = "TimerTrigger"
                successFile["ediFunctionLoadStatus"] = "Success"
                successFile["ediFeedRunStartDtTime"] = self.execStart
                successFile["ediFeedRunEndDtTime"]   = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                successFile["ediFilesWritten"]       = fileLoadedCount
                successFile["ediDestinationPath"]    = self.basePath

                self.connectUpload(successFile, "EDISTG_SUCCESS.json")

                logger.info("EDI-AKAMAI-FUNC-KONA-Successfully Written EDISTG_SUCCESS file {}".format(self.basePath))
            else:
                logger.info("EDI-AKAMAI-FUNC-KONA-There Is No Data Available To Load")
        except Exception as e:
            logging.error("EDI-AKAMAI-FUNC-KONA-Unable To write EDISTG_SUCCESS file >> Path >> {}".format(e))
       

# For Timer trigger
# {
#   "scriptFile": "__init__.py",
#   "bindings": [
#     {
#       "name": "mytimer",
#       "type": "timerTrigger",
#       "direction": "in",
#       "schedule": "0 */30 * * * *"
#     }
#   ]
# }

def main(mytimer: func.TimerRequest) -> None:
    logger.info('EDI-AKAMAI-FUNC-KONA-Starting to execute Akamai Kona function')
    mod = Export()  # create object for class
    mod.downloadData()  # function call

# For HTTP Trigger
# {
#   "scriptFile": "__init__.py",
#   "bindings": [
#     {
#       "authLevel": "anonymous",
#       "type": "httpTrigger",
#       "direction": "in",
#       "name": "req",
#       "methods": [
#         "get",
#         "post"
#       ]
#     },
#     {
#       "type": "http",
#       "direction": "out",
#       "name": "$return"
#     }
#   ]
# }

# def main(req: func.HttpRequest) -> func.HttpResponse:
#     logger.info('Triggered Akamai Kona function')

#     mod = Export()  # create object for class
#     mod.downloadData()  # function call

#     logger.info('Successfully completed Akamai Kona function')

#     return func.HttpResponse(f"Hello Akamai Kona user. This HTTP triggered function executed successfully.")

