#!/usr/bin/python3

import sys, os
import subprocess
import traceback
from datetime import datetime

import MetricsLogging

from Export import Export
from Transform import Transform
from Load import Load


# setup folder structures:
fbase = os.path.dirname(os.path.abspath(__file__))
if not os.path.isdir(fbase+'/logs'):
	os.mkdir(fbase+'/logs')

if not os.path.isdir(fbase+'/tmp'):
	os.makedirs(fbase+'/tmp', exist_ok=True)


# configuration
pipeline = "secure-code-warrior-pipeline"
lockFile = os.path.dirname(os.path.abspath(__file__))+'/tmp/lock'
startTime = datetime.now()
debug = False

MetricsLogging.basicConfig(pipeline=pipeline, filename=os.path.dirname(os.path.abspath(__file__))+'/logs/run.log')

# execution
MetricsLogging.info("run.py executed")

# if pipeline is running: exit
if os.path.exists(lockFile):
	MetricsLogging.info("Lock file present, exiting")
	sys.exit(0)

# start pipeline
try:
	# create lock file
	with open(lockFile, 'w+') as f:
		f.write(str(datetime.now()))

	# check for new data
	ex = Export(pipeline, debug)
	if not ex.dataAvailible():
		MetricsLogging.info("No data to export")
		sys.exit(0)

	# export the data from the source
	ex.run()

	# transform the data to prepare it for storage
	tr = Transform(pipeline, debug)
	tr.run()

	# load the data into storage
	ld = Load(pipeline, debug)
	ld.run()

	# clean-up
	ex.cleanDumpFolder()

	# pipeline executed fully without errors
	MetricsLogging.endExecution(True)
	MetricsLogging.info("run.py executed successful")
	MetricsLogging.info("time to execute: "+str(datetime.now() - startTime))

except Exception as e:
	MetricsLogging.endExecution(False)
	MetricsLogging.critical("run.py experienced a exception:")
	MetricsLogging.critical("error: " + str(e))
	MetricsLogging.critical(traceback.format_exc())

finally:
	# delete lock file
	if os.path.exists(lockFile):
		os.remove(lockFile)
