#!/usr/bin/python3

import subprocess
import glob, os
import datetime

from mtrdata import datas3


class Load:
	def __init__(self, pipeline, debug = False):
		self.pipeline = pipeline
		self.debug = debug
		self.dumpFolder = os.path.dirname(os.path.abspath(__file__))+'/../tmp/export'
		self.s3 = datas3("s3-metrics-perm")


	def run(self):
		self.upload()


	def upload(self):
		t = str(datetime.datetime.utcnow().replace(microsecond=0).isoformat())

		self.s3.folderUpload(self.dumpFolder, "/{}/{}/".format(self.pipeline, t))



if __name__ == '__main__':
	print('Executing Load as standalone script')
	mod = Load()
	print(mod.run())
