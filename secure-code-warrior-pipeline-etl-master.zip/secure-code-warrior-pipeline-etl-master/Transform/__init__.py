#!/usr/bin/python3


class Transform:
	def __init__(self, pipeline, debug = False):
		self.pipeline = pipeline
		self.debug = debug


	def run(self):
		return


if __name__ == '__main__':
	print('Executing Transform as standalone script')
	mod = Transform()
	print(mod.run())
