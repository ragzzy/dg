#!/usr/bin/python3

import os
import shutil
import math
import requests
import json
import datetime
import time

import MetricsLogging


class Export:
	def __init__(self, pipeline, debug = False):
		self.pipeline = pipeline
		self.debug = debug

		self.dumpFolder = os.path.dirname(os.path.abspath(__file__))+'/../tmp/export'

		with open(self.dumpFolder+'/../credentials.json', "r") as f:
			credentials = json.load(f)
			self.key = credentials['key']
			self.headers = {'X-API-Key': self.key}


		self.startDate = (datetime.datetime.utcnow() - datetime.timedelta(hours=8)).isoformat()[:-3] + "Z"

		self.session = requests.session()


	def run(self):
		self.cleanDumpFolder()
		self.download()

		importSize = math.ceil(self.folderSize(self.dumpFolder)/1024)
		MetricsLogging.addUpload(importSize)
		
		MetricsLogging.info("Uploaded {}kb of data".format(importSize))


	def dataAvailible(self):
		return True


	def cleanDumpFolder(self):
		self.cleanFolder(self.dumpFolder)


	def cleanFolder(self, folder):
		if os.path.isdir(folder):
			shutil.rmtree(folder)
		os.mkdir(folder)


	def compress(self, file):
		os.system("gzip "+file)


	def download(self):
		self.downloadUsers()
		self.downloadDeveloperProgress()
		self.downloadDeveloperActivity()
		self.downloadAssessments()


	def downloadAssessments(self):
		MetricsLogging.info("Downloading assessments...")

		page = 1
		data = []

		attempts = []

		while True:
			for i in range(0, 10):
				try:
					req = self.session.get("https://portal-api.securecodewarrior.com/api/v2/assessments", params={"page": page}, headers=self.headers)
					resp = req.json()
					break

				except Exception as e:
					if i == 9:
						MetricsLogging.warning("downloadDeveloperActivity failed")
						MetricsLogging.warning(str(e))
						raise e

					self.session = requests.session()
					time.sleep(10)

			for a in resp["assessments"]:
				attempts.extend(self.downloadAssessmentAttempts(a['_id']))
				data.append(a)

			if page < resp["links"]["total_pages"]:
				page += 1
			else:
				break

		file = self.dumpFolder+'/assessments.json'
		with open(file, "w") as f:
			json.dump(data, f, indent=2)
		self.updateDownloadSize(file)
		self.compress(file)

		file = self.dumpFolder+'/attempts.json'
		with open(file, "w") as f:
			json.dump(attempts, f, indent=2)
		self.updateDownloadSize(file)
		self.compress(file)

		return data

	
	def downloadAssessmentAttempts(self, aId):
		MetricsLogging.info("Downloading attempts for #{}...".format(aId))

		page = 1
		data = []

		while True:
			for i in range(0, 10):
				try:
					req = self.session.get("https://portal-api.securecodewarrior.com/api/v2/assessments/{}/attempts".format(aId), params={"page": page}, headers=self.headers)
					resp = req.json()
					break

				except Exception as e:
					if i == 9:
						MetricsLogging.warning("downloadDeveloperActivity failed")
						MetricsLogging.warning(str(e))
						raise e

					self.session = requests.session()
					time.sleep(10)

			data.extend(resp["attempts"])

			if page < resp["links"]["total_pages"]:
				page += 1
			else:
				break

		return data

		"""
		for assessment in assessments:
			aid = assessment['id']
			page = 1
			data = []

			while True:
				req = requests.get("https://portal-api.securecodewarrior.com/api/v2/assessments/{}/attempts".format(aid), params={"page": page}, headers=self.headers)
				resp = req.json()

				data.extend(resp["assessments"])

				if page < resp["links"]["total_pages"]:
					page += 1
				else:
					break

		file = self.dumpFolder+'/assessments.json'
		with open(file, "w") as f:
			json.dump(data, f, indent=2)
		self.updateDownloadSize(file)
		self.compress(file)

		return data
		"""

	
	def downloadUsers(self):
		MetricsLogging.info("Downloading users...")

		page = 1
		data = []

		while True:
			for i in range(0, 10):
				try:
					req = self.session.get("https://portal-api.securecodewarrior.com/api/v2/users", params="page="+str(page)+"&fields=email,role,name,status,tags,team.name,preferredDevLanguages,invite-date,last-login-date", headers=self.headers)
					resp = req.json()
					break

				except Exception as e:
					if i == 9:
						MetricsLogging.warning("downloadUsers failed")
						MetricsLogging.warning(str(e))
						raise e

					self.session = requests.session()
					time.sleep(10)

			data.extend(resp["users"])

			if page < resp["links"]["total_pages"]:
				page += 1
			else:
				break

		file = self.dumpFolder+'/users.json'
		with open(file, "w") as f:
			json.dump(data, f, indent=2)
		self.updateDownloadSize(file)
		self.compress(file)

		return data

	
	def downloadDeveloperProgress(self):
		MetricsLogging.info("Downloading developer-progress...")

		page = 1
		data = []

		while True:
			for i in range(0, 10):
				try:
					req = self.session.get("https://portal-api.securecodewarrior.com/api/v2/training/developers-progress", params={"page": page}, headers=self.headers)
					resp = req.json()
					break

				except Exception as e:
					if i == 9:
						MetricsLogging.warning("downloadDeveloperProgress failed")
						MetricsLogging.warning(str(e))
						raise e

					self.session = requests.session()
					time.sleep(10)

			data.extend(resp["developers"])

			if page < resp["links"]["total_pages"]:
				page += 1
			else:
				break

		file = self.dumpFolder+'/developer-progress.json'
		with open(file, "w") as f:
			json.dump(data, f, indent=2)
		self.updateDownloadSize(file)
		self.compress(file)

		return data

	
	def downloadDeveloperActivity(self):
		MetricsLogging.info("Downloading developer-activity...")

		page = 1
		data = []

		while True:
			for i in range(0, 10):
				try:
					req = self.session.get("https://portal-api.securecodewarrior.com/api/v2/training/developers-activity", params={"page": page}, headers=self.headers)
					resp = req.json()
					break

				except Exception as e:
					if i == 9:
						MetricsLogging.warning("downloadDeveloperActivity failed")
						MetricsLogging.warning(str(e))
						raise e

					self.session = requests.session()
					time.sleep(10)

			data.extend(resp["activities"])

			if page < resp["links"]["total_pages"]:
				page += 1
			else:
				break

		file = self.dumpFolder+'/developer-activity.json'
		with open(file, "w") as f:
			json.dump(data, f, indent=2)
		self.updateDownloadSize(file)
		self.compress(file)

		return data

	
	def folderSize(self, path):
		total = 0
		for entry in os.scandir(path):
			if entry.is_file():
				total += entry.stat().st_size
			elif entry.is_dir():
				total += self.folderSize(entry.path)
		return total


	def updateDownloadSize(self, path):
		MetricsLogging.addDownload(int(os.stat(path).st_size/1024))


if __name__ == '__main__':
	print('Executing Export as standalone script')
	mod = Export()
	print(mod.run())
