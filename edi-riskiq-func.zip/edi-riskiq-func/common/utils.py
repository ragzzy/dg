import os, json
from datetime import datetime
from typing import Any, Callable, List
from concurrent.futures import ThreadPoolExecutor, as_completed

def runParallel(func:Callable, delta:List, logger, function_friendly_name: str):
    try:
        results = []
        with ThreadPoolExecutor(os.cpu_count()) as pool:
            futures = [pool.submit(func, i) for i in delta]	
            for future in as_completed(futures):
                res = future.result()
                results.append(json.loads(str(res.content.decode('utf-8'))))
                logger.info("runParallel successful")
        return results

    except Exception as e:
        logger.error(f"{function_friendly_name} - Exception - Error:runParallel: {e}")
        raise e


def get_manifest(file_count: int, files: dict, status: str, function_friendly_name: str, basePath: str, execStart: str, function_name: str) -> dict :  
    StatusFile = {}
    StatusFile["ediFunctionName"]          = function_name
    StatusFile["ediTriggerType"]           = "TimerTrigger"
    StatusFile["ediFunctionLoadStatus"]    = status
    StatusFile["ediFeedRunStartDtTime"]    = execStart
    StatusFile["ediFeedRunEndDtTime"]      = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
    StatusFile["ediFilesWritten"]          = file_count
    StatusFile["batchInfo"]                = files
    StatusFile["ediDestinationPath"]       = basePath
    return StatusFile     