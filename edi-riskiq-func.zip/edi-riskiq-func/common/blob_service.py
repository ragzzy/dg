import os
import json
import gzip
import typing as t
from azure.storage.blob import ContentSettings, BlobServiceClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential

from  .constant import BlobConnectionStrategy, APPLICATION_JSON_CONTENT, APPLICATION_STREAM_CONTENT, APPLICATION_ENCODING, BLOB_TYPE

class BlobService:

    def __init__(self, config,  logger):
        self.logger = logger
        self.config = config
        self.connection_string = os.getenv("DATASOURCE_STORAGE_URL")
        self.blobContainerClient = self.setup()
        
    def setup(self):
        try:
            self.logger.info(f"{self.config.function_friendly_name} - configuring connection to blob client")
            if self.config.connection_strategy == BlobConnectionStrategy.CONNECTION_STRING:
                blobServiceClient = BlobServiceClient.from_connection_string(self.connection_string)
            else:
                msiCredential = ManagedIdentityCredential()
                credentialChain = ChainedTokenCredential(msiCredential)
                blobServiceClient = BlobServiceClient(self.connection_string, credential=credentialChain)
           
            self.logger.info(f"{self.config.function_friendly_name} - blob client successfully configured !")
            return blobServiceClient.get_container_client(self.config.container_name)     

        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception  - creating a blob client >> {e} ")
            raise e


    def Upload(self, data: t.Any, blobPath: str, overwrite_if_exists: bool = True):
        try:
            self.logger.info(f"{self.config.function_friendly_name} - starting blob upload")
            blob = self.blobContainerClient.get_blob_client(blobPath)
            try:
                blobContentSettings = ContentSettings(content_type=APPLICATION_JSON_CONTENT)
                blob.upload_blob(data, blob_type=BLOB_TYPE, content_settings=blobContentSettings, overwrite=overwrite_if_exists)
                self.logger.info(f"{self.config.function_friendly_name} - blob '{blobPath}' successfully uploaded !")  
            except Exception as e:
                self.logger.error(f"{self.config.function_friendly_name} - Exception - uploadinng blob '{blobPath}' >> {str(e)}")
                raise
        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception - connecting to Azure Blob Storage >> {str(e)}")
            raise e


    def compressUpload(self, data: t.Any, blobPath: str, overwrite_if_exists: str = True):
        try:
            self.logger.info(f"{self.config.function_friendly_name} - starting blob compression and upload") 
            dataOut = gzip.compress(data.encode('utf-8'))
            try:
                blob = self.blobContainerClient.get_blob_client(blobPath)
                try:
                    blobContentSettings = ContentSettings(content_encoding="gzip", content_type="application/octec-stream")
                    blob.upload_blob(dataOut, blob_type=BLOB_TYPE, content_settings=blobContentSettings, overwrite=overwrite_if_exists)
                    self.logger.info(f"{self.config.function_friendly_name} - blob '{blobPath}' successfully uploaded and compressed !")
                except Exception as e:
                    self.logger.error(f"{self.config.function_friendly_name}  - Exception -  uploadinng blob: '{blobPath}' >> {str(e)}")
            except Exception as e:
                self.logger.error(f"{self.config.function_friendly_name} - Exception - connecting to Azure Blob Storage >> {str(e)}")
                raise e
        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception - gzipping data >> {str(e)}")
            raise e


    def list_blobs(self, basePath: str) -> dict:
        try:
            self.logger.info(f"{self.config.function_friendly_name} - listing blob paths '{basePath}'")
            files = list(self.blobContainerClient.list_blobs(name_starts_with=basePath))
            self.logger.info(f"{self.config.function_friendly_name} - blob paths '{basePath}' successfully listed !")
            return {'fileCount': len(files), 'files': [{'name':file['name'].replace(basePath,''), 'size':file['size']} for file in files]}
        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception - listing blob  in '{basePath}' >> {e}")
            raise e


    def merge_blobs(self, chunkPaths: list, blobPath: str, compression: bool = True):
        try:
            chunkPaths_string = "' '".join(chunkPaths)
            self.logger.info(f"{self.config.function_friendly_name} - merging blobs '{chunkPaths_string}'")
            data = []
            for path in chunkPaths:
                blob = self.blobContainerClient.get_blob_client(path)
                data.extend(blob.download_blob().readall())
            if compression: self.compressUpload(json.dumps(data), blobPath)
            else: self.Upload(json.dumps(data), blobPath)
            for file in chunkPaths: self.delete_blob(file)
            self.logger.info(f"{self.config.function_friendly_name} - blobs '{chunkPaths_string}' successfully merged !")
        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception - merging blobs '{chunkPaths_string}' >> {e}")
            raise e


    def delete_blob(self, blobPath: str):
        try:
            self.logger.info(f"{self.config.function_friendly_name} - deleting blob '{blobPath}'")
            self.blobContainerClient.get_blob_client(blobPath).delete_blob()
            self.logger.info(f"{self.config.function_friendly_name} - blob '{blobPath}' successfully deleted !")
        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception -  deleting blob '{blobPath}' >> {e}")
            raise e

    def blob_exists(self, filePath: str):
        try:
            blob_client    = self.blobContainerClient.get_blob_client(filePath)
            exists = blob_client.exists()
            self.logger.info(f"{self.config.function_friendly_name} -  blob exists '{exists}'")
            return exists
        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception -  checking if blob exists '{filePath}' >> {e}")
            raise e
    
    def blob_read_json(self,filePath: str):
        try:
            blob_client = self.blobContainerClient.get_blob_client(filePath)
            content = blob_client.download_blob().readall()
            return json.loads(content)
        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception -  checking if blob exists '{filePath}' >> {e}")
            raise e