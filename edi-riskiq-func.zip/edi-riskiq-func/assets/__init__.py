#!/usr/bin/env python3

from datetime import datetime, timedelta
import json, os
import logging
from retry import retry
import requests
from requests.exceptions import HTTPError
import azure.functions as func 
from ..common import config, blob_service, utils
from ..common.constant import FEED_NAME, FUNCTION_FRIENDLY_NAME, RETRY, RETRY_INTERVAL, SUCCESS_FILE_NAME, FAILURE_FILE_NAME

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger('riskiq-assets')

class Export:

    def __init__(self):
        self.config = config.Config(logger)
        self.blob_service = blob_service.BlobService(self.config, logger)
        self.baseUrl ='https://api.riskiq.net/v1/globalinventory'

        self.stop = datetime.strftime(datetime.now(), '%Y-%m-%d')
        
        logger.info(f'\tEDI-RISKIQ-FUNC - assets -  EndDate {self.stop} \n')
        
        self.startDate = self.get_startdate(self.blob_service)
        self.Token, self.Key = self.get_credentials(self.config)

    def get_credentials(self, config):
        try:
            creds = json.dumps(config.credentials)
            creds = json.loads(creds)
            creds = creds["Inventory"]
            Token = creds["Token"]
            Key = creds["Key"]

            return Token, Key
        except Exception as e:
            logger.exception("EDI-RISKIQ-FUNC - assets -  Exception - Error:get_credentials :{}".format(e))
            raise e

    def get_startdate(self, blob_service):
        try:
            if blob_service.blob_exists("assets/assetsLastStop.json"):
                logger.info(f'EDI-RISKIQ-FUNC - assets -  assetsLastStop exists - {blob_service.blob_exists("assetsLastStop.json")}')
                data = blob_service.blob_read_json("assets/assetsLastStop.json")
                startDate = data["lastStopDt"]

                logger.info(f'\tEDI-RISKIQ-FUNC - assets -  StartDate {startDate} \n')
            else:
                startDate = datetime.date(datetime.now() - timedelta(days=5))
                logger.info(f'\tEDI-RISKIQ-FUNC - assets -  StartDate {startDate} \n')
            return startDate
        except Exception as e:
            logger.exception("EDI-RISKIQ-FUNC - assets -  Exception - Error:get_startdate :{}".format(e))
            raise e

    @retry(Exception, tries=5)
    def get_all_asset_ids(self):
        try:
            page_size = 2000
            params = {'idsOnly': True, 'mark': '*', 'size': page_size}
            query = {"filters":{"condition":"AND","value":[{"condition":"OR","value":[{"name":"createdAt","operator":"GTE","value":str(self.startDate)},
                    {"name":"updatedAt","operator":"GTE","value":str(self.startDate)}]}]}}

            r = requests.post(self.baseUrl + '/search', params=params, json=query, auth=(self.Token, self.Key), proxies=self.config.proxyDict)
            r.raise_for_status()

            total_items = r.json().get('totalElements', None)
            totalPages = r.json().get('totalPages', None)

            logger.info(f"EDI-RISKIQ-FUNC - assets -  Total Items = {total_items} Total Pages = {totalPages}")

            params['size'] = response_size = page_size          

            data = []
            cpage = 0
            while (page_size == response_size):
                try:

                    r = requests.post(self.baseUrl + '/search', params=params, json=query, auth=(self.Token, self.Key), proxies=self.config.proxyDict)
                    r.raise_for_status()

                    jdata = r.json()
                    data.extend(jdata.get('content')) 
                    cpage += 1

                    logger.info(f"EDI-RISKIQ-FUNC - assets -  Pulled down {cpage} of {totalPages} pages")

                    response_size = jdata['numberOfElements']
                    params['mark'] = jdata.get('mark')

                except HTTPError as exc:
                    logger.exception("EDI-RISKIQ-FUNC - assets -  Exception - Error: HTTPError get_all_asset_ids :{}".format(exc))
                    raise

            logger.info(f'\tEDI-RISKIQ-FUNC - assets -  Pulled down all {total_items} asset IDs!\n')
            return data

        except Exception as e:
            logger.exception("EDI-RISKIQ-FUNC - assets -  Exception - Error:get_all_asset_ids :{}".format(e))
            raise e

    @retry(Exception, tries=5)
    def get_asset(self, total_items):
        try:
            logger.info(f"EDI-RISKIQ-FUNC - assets -  Getting Asset details Type - {total_items['type']} and Name - {total_items['name']} ")
            resp = requests.get(
                self.baseUrl + f'/assets/{total_items["type"]}',
                params={'name': {total_items["name"]}},
                auth=(self.Token, self.Key),
                proxies=self.config.proxyDict
            )
            resp.raise_for_status()
            
            return resp
        except Exception as e:
            logger.exception("EDI-RISKIQ-FUNC - assets -  Exception - Error:get_asset :{}".format(e))
            raise e

    def main(self):
        try:
            
            total_items = self.get_all_asset_ids()
            if len(total_items)>0:
                
                # data = self.runParallel(self.get_asset, total_items)
                data = utils.runParallel(self.get_asset, total_items, logger, "EDI-RISKIQ-FUNC - assets")

                self.blob_service.compressUpload(json.dumps(data),f'assets/{self.config.basePath}assets.json.gz')

                # Update lastStop
                lastStop = {}
                lastStop["lastStopDt"] = self.stop
                self.blob_service.Upload(json.dumps(lastStop), f'assets/assetsLastStop.json')        

                # write success file
                files = self.blob_service.list_blobs(f"assets/{self.config.basePath}")
                file_count = len(files['files'])
                if file_count >0:
                    manifest  = utils.get_manifest(file_count, files, "SUCCESS", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
                    self.blob_service.Upload(json.dumps(manifest), f"assets/{self.config.basePath}{SUCCESS_FILE_NAME}.json")
                else: logger.info(f"{self.config.function_friendly_name} - There is no data available to load to {self.config.basePath}")

        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - pipeline has failed ")
            manifest  = utils.get_manifest("", "", "FAILURE", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
            self.blob_service.Upload(json.dumps(manifest), f"assets/{self.config.basePath}{FAILURE_FILE_NAME}.json")
            raise e

def main(mytimer: func.TimerRequest) -> None:
    logger.info('EDI-RISKIQ-FUNC - assets -  Starting RISKIQ Function')
    mod = Export()
    mod.main()
    logger.info("EDI-RISKIQ-FUNC - assets -  pipeline has completed successfully!")


