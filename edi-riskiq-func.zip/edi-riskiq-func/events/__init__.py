#!/usr/bin/env python3

from datetime import datetime
import json
import logging
from retry import retry
import requests
import datetime
import azure.functions as func 
from ..common import config, blob_service, utils
from ..common.constant import SUCCESS_FILE_NAME, FAILURE_FILE_NAME

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger('riskiq-events')

class Export:

    def __init__(self):
        self.config = config.Config(logger)
        self.blob_service = blob_service.BlobService(self.config, logger)
        self.baseUrl ='https://ws.riskiq.net/v1/'
        self.page_size = 2000

        self.stop = datetime.datetime.now()
        self.stop = datetime.datetime.strftime(self.stop, '%Y-%m-%d')
        
        logger.info(f'\tEDI-RISKIQ-FUNC - Events -EndDate {self.stop} \n')
        self.startDate = self.get_startdate(self.blob_service)

    def get_startdate(self, blob_service):
        try:
            if blob_service.blob_exists("events/eventsLastStop.json"):
                logger.info(f'EDI-RISKIQ-FUNC - Events -  eventsLastStop exists - {blob_service.blob_exists("events/eventsLastStop.json")}')
                data = blob_service.blob_read_json("events/eventsLastStop.json")
                startDate = data["lastStopDt"]
                startDate = datetime.datetime.strptime(startDate, '%Y-%m-%d')
                logger.info(f'\tEDI-RISKIQ-FUNC - Events -StartDate {startDate} \n')
            else:
                startDate = "1970-01-01"
                logger.info(f'\tEDI-RISKIQ-FUNC - Events -StartDate {startDate} \n')
            return startDate
        except Exception as e:
            logger.exception("EDI-RISKIQ-FUNC - Events -  Exception - Error:get_startdate :{}".format(e))
            raise e

    @retry(Exception, tries=5)
    def get_event_ids(self):
        try:

            logger.info('EDI-RISKIQ-FUNC - Events - Pulling down all events')
            params = {'idsOnly': True, 'scroll': '', 'results': self.page_size}
            
            if self.ws == "Inventory":
                query = {"filters": [{"filters": [{"field": "createdAt","value": str(self.startDate), "type": "GTE"}], "filters": [{"field": "reviewCode", "value": "SUSPECT", "type": "IN"}]}]}
            else:
                query = {'filters': [{'filters': [{"field": "createdAt","value": str(self.startDate),"type": "GTE"}]}]}

            eventIds = []
            while True:
                logger.info(f"EDI-RISKIQ-FUNC - Events - Requesting - {self.baseUrl} - {params['scroll']}")
                resp = requests.get(self.baseUrl + '/event/search', params=params, json=query, auth=(self.Token, self.Key),proxies=self.config.proxyDict)
                resp.raise_for_status()
                jdata = resp.json()
                eventIds.extend(jdata.get('Results'))
                response_size = len(jdata.get('Results'))
                params['scroll'] = jdata.get('scroll')

                logger.info(f"EDI-RISKIQ-FUNC - Events - Received - {self.baseUrl} - {params['scroll']}")

                if (self.page_size != response_size):
                    break;

            logger.info(f'EDI-RISKIQ-FUNC - Events - Total EventID {response_size}')

            return eventIds

        except Exception as e:
            logger.exception("EDI-RISKIQ-FUNC - Events -Exception - Error:get_event_ids :{}".format(e))
            raise e

    @retry(Exception, tries=5)
    def get_events(self, total_items):
        try:
            logger.info(f"EDI-RISKIQ-FUNC - Events -Getting Event details - {total_items} ")

            resp = requests.get(
                self.baseUrl + f'event/{total_items["eventID"]}',
                auth=(self.Token, self.Key),
                proxies=self.config.proxyDict
            )
            resp.raise_for_status()
        
            return resp
        except Exception as e:
            logger.exception("EDI-RISKIQ-FUNC - Events -Exception - Error:get_events :{}".format(e))
            raise e

    def main(self):
        try:
            logger.info(f"EDI-RISKIQ-FUNC - Events - Executing main")

            creds = json.dumps(self.config.credentials)
            creds = json.loads(creds)

            for k, v in creds.items(): 
                logger.info(f"EDI-RISKIQ-FUNC - Events - extracting events from {k} - workspace")
                creds = json.dumps(v)
                creds = json.loads(creds)
                self.Key = creds["Key"]
                self.Token = creds["Token"]
                self.ws = k

                total_items = self.get_event_ids()
                # logger.info(f'Total items - {len(total_items)}')
                if len(total_items)>0:
                    data = utils.runParallel(self.get_events, total_items, logger,"EDI-RISKIQ-FUNC - events")
                    self.blob_service.compressUpload(json.dumps(data),f'events/{self.config.basePath}{self.ws}_events.json.gz')

            # Update lastStop
            lastStop = {}
            lastStop["lastStopDt"] = self.stop
            self.blob_service.Upload(json.dumps(lastStop), f'events/eventsLastStop.json')

            # Write Success file
            files = self.blob_service.list_blobs(f"events/{self.config.basePath}")
            file_count = len(files['files'])
            if file_count >0:
                manifest  = utils.get_manifest(file_count, files, "SUCCESS", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
                self.blob_service.Upload(json.dumps(manifest), f"events/{self.config.basePath}{SUCCESS_FILE_NAME}.json")
            else: logger.info(f"{self.config.function_friendly_name} - There is no data available to load to {self.config.basePath}")

        except Exception as e:
            logger.error(f"EDI-RISKIQ-FUNC - Events - pipeline has failed ")
            manifest  = utils.get_manifest("", "", "FAILURE", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
            self.blob_service.Upload(json.dumps(manifest), f"events/{self.config.basePath}{FAILURE_FILE_NAME}.json")
            raise e

def main(mytimer: func.TimerRequest) -> None:
    logger.info('EDI-RISKIQ-FUNC - Events -Starting RISKIQ Function')
    mod = Export()
    mod.main()
    logger.info("EDI-RISKIQ-FUNC - Events -pipeline has completed successfully!")


