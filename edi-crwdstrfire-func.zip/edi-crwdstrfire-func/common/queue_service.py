import os
from azure.storage.queue import QueueServiceClient, TextBase64EncodePolicy
from azure.core.exceptions import ResourceExistsError


class QueueService:

    def __init__(self, logger, function_friendly_name: str,  processingQueueName: str, connection_string: str = os.getenv("DATASOURCE_STORAGE_CONNECTIONSTRING", None)):
        self.logger = logger
        self.connection_strategy = 'Local' if os.getenv("isLocal", None) else 'Azure'
        self.queue_connection_string = connection_string
        self.function_friendly_name = function_friendly_name
        self.processingQueueName = processingQueueName
        self.queueClient = self.conenctQueue()


    def conenctQueue(self):
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function conenctQueue for '{self.processingQueueName}' queue")
            if self.connection_strategy == 'Local':
                queueServiceClient = QueueServiceClient.from_connection_string(self.queue_connection_string)
            else:
                ### Testing with connection string for now
                # msiCredential = ManagedIdentityCredential()
                # credentialChain = ChainedTokenCredential(msiCredential)
                # queueServiceClient = QueueServiceClient(
                #                                             self.queue_connection_string,
                #                                             credential=credentialChain,
                #                                         )
                queueServiceClient = QueueServiceClient.from_connection_string(self.queue_connection_string)

            
            try:
                if self.processingQueueName not in queueServiceClient.list_queues():
                    queueServiceClient.create_queue(self.processingQueueName)
            except ResourceExistsError as err:
                pass

            queueClient = queueServiceClient.get_queue_client(self.processingQueueName)  
            queueClient.message_encode_policy =  TextBase64EncodePolicy()

            self.logger.info(f"{self.function_friendly_name} - Success: Function conenctQueue for '{self.processingQueueName}' queue")
            return queueClient

        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function conenctQueue for '{self.processingQueueName}' queue >> {e} ")
            raise e


    def writeToQueue(self, message):
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function writeToQueue in '{self.processingQueueName}' queue")
            self.queueClient.send_message(message)
            self.logger.info(f"{self.function_friendly_name} - Success: Function writeToQueue in '{self.processingQueueName}' queue")
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function writeToQueue in '{self.processingQueueName}' queue >> {e}")
            raise e
