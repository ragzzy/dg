import os
import json
from datetime import datetime
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

from .constant import FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME, CONTAINER_NAME


class Config:
    def __init__(self, logger, feedName: str= FEED_NAME, function_name: str= FUNCTION_NAME, function_friendly_name: str = FUNCTION_FRIENDLY_NAME, container_name: str = CONTAINER_NAME):
        utcTimeNow = datetime.utcnow()
        self.execStart = utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.blobFolderName = utcTimeNow.strftime('%Y%m%d%H%M')
        self.epocSubFolderName = int((utcTimeNow.timestamp()))
        self.basePath = "{}/{}".format(self.blobFolderName, self.epocSubFolderName)
        self.proxyDict = {
                            "http": os.getenv("http_proxy") or os.getenv("OUTBOUND_PROXY"),
                            "https": os.getenv("https_proxy") or os.getenv("OUTBOUND_PROXY")
                        }
        self.logger = logger
        self.feedName = feedName
        self.function_name = function_name
        self.function_friendly_name = function_friendly_name
        self.container_name = container_name
        self.visibilityTimeout = int(os.environ.get("visibilityTimeout",300))
        self.maxNumberOfSqsMessages_toRetrieve = int(os.environ.get("maxNumberOfSqsMessages_toRetrieve", 10))
        self.numberOfSqsCalls = int(os.environ.get("numberOfSqsCalls", 20))
        self.credentials = self.readSecrets()


    def readSecrets(self):
        try:
            self.logger.info(f"{self.function_friendly_name} - Excecuting Function readSecrets")
			
            if os.environ.get("isLocal",None):
                self.credentials = {
                                     "accessKeyId": os.getenv("accessKeyId", None),
                                     "secretAccessKey": os.getenv("secretAccessKey", None),
                                     "sqsUrl": os.getenv("sqsUrl", None),
                                     "sqsRegion": os.getenv("sqsRegion", None),
                                    }
            else:
                secretClient = SecretClient(
                                            vault_url=os.getenv("DATASOURCE_KEYVAULT_URL"), 
                                            credential=ManagedIdentityCredential()
                                            )
                secret = secretClient.get_secret("credentials")
                self.credentials = json.loads(secret.value)

            self.logger.info(f"{self.function_friendly_name} - Success: Function readSecrets")
            return  self.credentials

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Azure SDK was not able to connect to Key Vault")
            raise 
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Possible wrong Vault name given")
            raise      
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Network Error")
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Azure SDK was not able to deal with my query")
            raise
        except KeyError as ke:
            # check if the key vault URL is present in application insights
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Maybe missing key in Application Insights")
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Unknown error I can't blame Azure for")
            raise  



