import os
import json
import typing as t
import gzip
from datetime import datetime
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.storage.blob import BlobServiceClient, ContentSettings

from  .constant import APPLICATION_JSON_CONTENT, APPLICATION_STREAM_CONTENT, APPLICATION_ENCODING, BLOB_TYPE, SUCCESS_FILE_NAME, FAILURE_FILE_NAME


class BlobService:

    def __init__(self, logger, function_friendly_name: str, container_name: str, connection_string: str = os.getenv("DATASOURCE_STORAGE_URL", None)):
        self.logger = logger
        self.connection_strategy = 'Local' if os.getenv("isLocal", None) else 'Azure'
        self.connection_string = connection_string
        self.container_name = container_name
        self.function_friendly_name = function_friendly_name
        self.blobContainerClient = self.connectBlob()
        

    def connectBlob(self):
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function connectBlob for '{self.container_name}' container")
            if self.connection_strategy == 'Local':
                blobServiceClient = BlobServiceClient.from_connection_string(self.connection_string)
            else:
                msiCredential = ManagedIdentityCredential()
                credentialChain = ChainedTokenCredential(msiCredential)
                blobServiceClient = BlobServiceClient(
                                                        self.connection_string, 
                                                        credential=credentialChain
                                                    )
            self.logger.info(f"{self.function_friendly_name} - Success: Function connectBlob for '{self.container_name}' container")
            return blobServiceClient.get_container_client(self.container_name)     
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function connectBlob for '{self.container_name}' container >> {e} ")
            raise e


    def Upload(self, data: t.Any, blobPath: str, compress: bool = False, overwrite_if_exists: bool = True):
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function Upload for blob '{blobPath}'")
            blob = self.blobContainerClient.get_blob_client(blobPath)
            try:
                if compress: 
                    if blobPath.endswith('json.gz'):
                        data = gzip.compress(data.encode('utf-8'))
                    blobContentSettings = ContentSettings(content_encoding=APPLICATION_ENCODING, content_type=APPLICATION_STREAM_CONTENT)
                else :  
                    blobContentSettings = ContentSettings(content_type=APPLICATION_JSON_CONTENT)
                blob.upload_blob(
                                  data, 
                                  blob_type=BLOB_TYPE, 
                                  content_settings=blobContentSettings, 
                                  overwrite=overwrite_if_exists
                                )
                self.logger.info(f"{self.function_friendly_name} - Success: Function Upload for blob '{blobPath}'")  
            except Exception as e:
                self.logger.error(f"{self.function_friendly_name} - Exception: Function Upload for blob '{blobPath}' >> {e}")
                raise e
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function Upload for blob '{blobPath}' >> {e}")
            raise e
    

    def list_blobs(self, basePath: str):
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function list_blobs for path '{basePath}'")
            files = list(self.blobContainerClient.list_blobs(name_starts_with=basePath))
            self.logger.info(f"{self.function_friendly_name} - Success: Function list_blobs for path '{basePath}'")
            return len(files), [{'name':file['name'].replace(basePath,''), 'size':file['size']} for file in files] , set([os.path.dirname(file['name']) for file in files])
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function list_blobs for path '{basePath}' >> {e}")
            raise e


    def delete_blob(self, blobPath: str):
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function delete_blob for blob '{blobPath}'")
            self.blobContainerClient.get_blob_client(blobPath).delete_blob()
            self.logger.info(f"{self.function_friendly_name} - Success: Function delete_blob for blob '{blobPath}'")
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function delete_blob for blob '{blobPath}' >> {e}")
            raise e


    def writeSuccessFile(self, status: str, function_name: str, execStart: str, fileCount: int, files: list, destPath: str):  
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function writeSuccessFile with {status} status in '{destPath}'")
            StatusFile = {}
            StatusFile["ediFunctionLoadStatus"]    = status
            StatusFile["ediFunctionName"]          = function_name
            StatusFile["ediFeedRunStartDtTime"]    = execStart
            StatusFile["ediFeedRunEndDtTime"]      = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
            StatusFile["ediFilesWritten"]          = fileCount
            StatusFile["batchInfo"]                = files
            StatusFile["ediDestinationPath"]       = destPath
            filename = SUCCESS_FILE_NAME if status == 'SUCCESS' else FAILURE_FILE_NAME
            self.Upload(json.dumps(StatusFile), f"{destPath}/{filename}.json")
            self.logger.info(f"{self.function_friendly_name} - Success: Function writeSuccessFile with {status} status in '{destPath}'")
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function writeSuccessFile with {status} status in '{destPath}' >> {e}")
            raise e
