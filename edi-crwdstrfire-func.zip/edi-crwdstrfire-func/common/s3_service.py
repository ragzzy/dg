import boto3
from typing import Any, List
from botocore.config import Config


class S3Service:

    def __init__(self, logger, function_friendly_name: str, credentials: dict, proxyDict: dict, visibilityTimeout: int, maxNumberOfSqsMessages_toRetrieve: int):
        self.logger = logger
        self.credentials = credentials
        self.proxyDict = proxyDict
        self.function_friendly_name = function_friendly_name
        self.visibilityTimeout = visibilityTimeout
        self.maxNumberOfSqsMessages_toRetrieve = maxNumberOfSqsMessages_toRetrieve
        self.sqsQueue, self.sqsClient = self.connectSqs()
        self.s3Client = self.connectS3()
   

    def connectSqs(self) -> Any:
        try: 
            self.logger.info(f"{self.function_friendly_name} - Executing Function connectSqs in '{self.credentials['sqsRegion']}' region")
            sqs = boto3.resource(
                                "sqs",
                                region_name=self.credentials["sqsRegion"],
                                aws_access_key_id=self.credentials["accessKeyId"],
                                aws_secret_access_key=self.credentials["secretAccessKey"],
                                config=Config(proxies=self.proxyDict),
                                )
            sqs_client  = boto3.client(
                                        "sqs",
                                        region_name=self.credentials["sqsRegion"],
                                        aws_access_key_id=self.credentials["accessKeyId"],
                                        aws_secret_access_key=self.credentials["secretAccessKey"],
                                        config=Config(proxies=self.proxyDict)
                                        )
            self.logger.info(f"{self.function_friendly_name} - Success: Function connectSqs  in '{self.credentials['sqsRegion']}' region")
            return (sqs.Queue(url=self.credentials["sqsUrl"]) , sqs_client)
        except Exception as e:
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function connectSqs  in '{self.credentials['sqsRegion']}' region >> {e}")
            raise e


    def connectS3(self):
        try: 
            self.logger.info(f"{self.function_friendly_name} - Executing Function connectS3  in '{self.credentials['sqsRegion']}' region")
            s3_client = boto3.client(
                                's3',
                                region_name = self.credentials['sqsRegion'],
                                aws_access_key_id  = self.credentials['accessKeyId'],
                                aws_secret_access_key = self.credentials['secretAccessKey'],
                                config = Config(proxies = self.proxyDict)
                            ) 
            self.logger.info(f"{self.function_friendly_name} - Success: Function connectS3  in '{self.credentials['sqsRegion']}' region")
            return s3_client
        except Exception as e:
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function connectS3  in '{self.credentials['sqsRegion']}' region >> {e}")
            raise e

       
    def getQueueMessages(self, queue, numberOfSqsCalls: int) -> List:
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function getQueueMessages")
            rawMsgList = []
            for _ in range(numberOfSqsCalls):
                queueList = []
                queueList = queue.receive_messages(
                                                VisibilityTimeout=self.visibilityTimeout, 
                                                MaxNumberOfMessages=self.maxNumberOfSqsMessages_toRetrieve
                                                )
                if len(queueList) > 0:
                    rawMsgList.extend(iter(queueList))
                elif rawMsgList:
                    return rawMsgList
            self.logger.info(f"{self.function_friendly_name} - Fetched {len(rawMsgList)} messages from SQS")
            self.logger.info(f"{self.function_friendly_name} - Success: Function getQueueMessages")
            return rawMsgList
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function getQueueMessages >> {e}")
            raise e
    

    def getS3Files(self, s3bucketName: str, s3PrefixPath: str):
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function getS3Files for '{s3PrefixPath}'")
            s3_objects = self.s3Client.list_objects(Bucket = s3bucketName, Prefix = s3PrefixPath)['Contents']
            s3_keys = [s3_object['Key'] for s3_object in s3_objects]
            self.logger.info(f"{self.function_friendly_name} - Success: Function getS3Files for '{s3PrefixPath}' ") 
            return s3_keys
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function getS3Files for '{s3PrefixPath}' >> {e}")   
            raise e


    def loadS3Files(self, s3bucketName: str, s3FileName: str):
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function loadS3Files for '{s3FileName}'")
            s3_response_object = self.s3Client.get_object(Bucket = s3bucketName, Key = s3FileName)
            object_content = s3_response_object['Body'].read()
            self.logger.info(f"{self.function_friendly_name} - Success: Function loadS3Files for '{s3FileName}'") 
            return object_content
        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function loadS3Files for '{s3FileName}' >> {e}")   
            raise e

    
    def deleteSqsMessages(self, deleteMessageList, environment = "prd"):
        def _delete_message(QueueUrl, ReceiptHandle):
            self.logger.info(f"Monkey Patched Version - {self.function_friendly_name} - Deleting message from {QueueUrl} using {ReceiptHandle}")
            return  {"ResponseMetadata": {"HTTPStatusCode" : 200 }}
             
        try:
            self.logger.info(f"{self.function_friendly_name} - Executing Function deleteSqsMessages totalMessages {len(deleteMessageList)}")
            sqsClient = self.sqsClient
            if environment != "prd":
                self.logger.info(f"{self.function_friendly_name} - Enviroment is not prd, SQS type is {type(sqsClient)}")
                sqsClient.delete_message = _delete_message
        
            deleteMessageCount = 0
            for deleteMsg in deleteMessageList:
                self.logger.info(f"{self.function_friendly_name} - Deleting message from {deleteMsg['queueUrl']} using {deleteMsg['MessageReceiptHandle']}")
                respDelete = sqsClient.delete_message(
                                                    QueueUrl=deleteMsg["queueUrl"],
                                                    ReceiptHandle=deleteMsg["MessageReceiptHandle"]
                                                    )
                if respDelete["ResponseMetadata"]["HTTPStatusCode"] == 200:
                    deleteMessageCount += 1

            if deleteMessageCount == len(deleteMessageList):
                self.logger.info(f"{self.function_friendly_name} - Success: Function deleteSqsMessages")
            else: raise Exception("Deletion count missmatches")

        except Exception as e:
            self.logger.error(f"{self.function_friendly_name} - Exception: Function deleteSqsMessages >> {e}")
            raise e



        
        

        
        
    
    
