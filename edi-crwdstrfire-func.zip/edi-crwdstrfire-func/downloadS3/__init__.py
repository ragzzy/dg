import os
import json 
import logging
import azure.functions as func
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..common import blob_service, s3_service, config, queue_service
from ..common.constant import  FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME



SUFFIX = '-downloadS3'
FEED_NAME += SUFFIX
FUNCTION_FRIENDLY_NAME += SUFFIX.upper()
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger(FEED_NAME)


class downloadS3:
    def __init__(self, queueData: dict):
        self.config = config.Config(logger, FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME)
        self.blob_service = blob_service.BlobService(logger, self.config.function_friendly_name, self.config.container_name)
        self.queue_services_sqsExports = queue_service.QueueService(logger, self.config.function_friendly_name, "sqs-exports")
        self.s3_service = s3_service.S3Service(logger, self.config.function_friendly_name, self.config.credentials, self.config.proxyDict, self.config.visibilityTimeout, self.config.maxNumberOfSqsMessages_toRetrieve)
        self.bucketName = queueData['bucketName']
        self.rawFiles = queueData['rawFiles']
        self.fileTimeStamps = queueData['fileTimeStamps']


    def copyS3Files(self, s3Filename: str):
        try:
            logger.info(f"{self.config.function_friendly_name} - Executing Function copyS3Files for '{s3Filename}'")
            object_resource = self.s3_service.loadS3Files(self.bucketName, s3Filename)
            blobFilename = f'{self.config.basePath}/{self.blobPathPrefix}/{s3Filename.split("/")[-1]}'
            self.blob_service.Upload(object_resource, blobFilename, compress= True)
            logger.info(f"{self.config.function_friendly_name} - Success: Function copyS3Files for '{s3Filename}'")
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function copyS3Files for '{s3Filename}' >> {e}")
            raise e

    def moveRawFiles(self, sourceTuple: tuple):
        try:
            sourcePath, sourceTime = sourceTuple
            logger.info(f"{self.config.function_friendly_name} - Executing Function moveRawFiles for '{sourcePath}'")
            _ , rawFiles,  _ = self.blob_service.list_blobs(f'sqsRawMessages/{sourcePath}') 
            for rawFile in rawFiles:
                rawFile = rawFile["name"]
                sourceFile = f'sqsRawMessages/{sourcePath}{rawFile}'
                destPath =  sourcePath.split("/")
                destPath = "/".join(destPath[:-1]) + "/" + sourceTime + "-" + destPath[-1]
                destFile = f'{self.config.basePath}/{destPath}/sqsRawMessages/{rawFile.split("/")[-1]}'
                sourceBlob = self.blob_service.blobContainerClient.get_blob_client(sourceFile)
                data = sourceBlob.download_blob().readall()
                self.blob_service.Upload(data, destFile)
                self.blob_service.blobContainerClient.delete_blob(sourceFile)
                logger.info(f"{self.config.function_friendly_name} - Deleted succesfully '{sourceFile}'")
            logger.info(f"{self.config.function_friendly_name} - Success: Function moveRawFiles for '{sourcePath}'")
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function moveRawFiles for '{sourcePath}' >> {e}")
            raise e      

    def runParallel(self, idList: str, items: list):
        logger.info(f"{self.config.function_friendly_name} - Executing Function runParallel for {idList}")
        try: 
            parallelFunc = self.moveRawFiles  if idList == 'raw' else self.copyS3Files
            logger.info(f"{self.config.function_friendly_name} - running Parallel for {len(items)} items in {idList}")
            with ThreadPoolExecutor(os.cpu_count()) as pool:
                futures = [pool.submit(parallelFunc, item) for item in items]	
                for future in as_completed(futures):
                    e = future.exception()
                    if e:
                        logger.critical(f"{self.config.function_friendly_name} - One of the worker failed while loading s3 files to blob - '{self.config.basePath}'")
                        raise e
            logger.info(f"{self.config.function_friendly_name} - Success: Function runParallel for {idList}")
            return []
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function runParallel for {idList} >> {e}")

            raise e


    def run(self):  # sourcery skip: raise-specific-error
        try:
            for i in range(len(self.rawFiles)):
                s3PathPrefix = self.rawFiles[i]
                s3Files = self.s3_service.getS3Files(self.bucketName, s3PathPrefix)
                pathPrefix = s3PathPrefix.split("/")
                pathPrefix = "/".join(pathPrefix[:-1]) + "/" + self.fileTimeStamps[i] + "-" + pathPrefix[-1]
                self.blobPathPrefix = pathPrefix
                self.runParallel(self.rawFiles[i], s3Files)

            self.runParallel('raw', list(zip(self.rawFiles, self.fileTimeStamps)))

            fileCount, files , directories = self.blob_service.list_blobs(self.config.basePath)
            if fileCount > 0:
                # this needs some error handling what happends when one of the files fails.
                error = {'rawFiles': [], 'fileTimeStamps': [] , 'bucketName' : self.bucketName }
                for dir in directories:
                    if "sqsRawMessages" not in dir:
                        try:
                            fileCount, files , directories = self.blob_service.list_blobs(f"{dir}")
                            self.blob_service.writeSuccessFile('SUCCESS', self.config.function_name, self.config.execStart, fileCount, files, f'{dir}')
                            logging.info(f"Uploaded Success file for directory {dir}")
                        except Exception as e : 
                            folder_with_timestamp = dir.split("/")[-1]
                            timestamp = folder_with_timestamp.split("-")[0]
                            folder_name= folder_with_timestamp.replace(f"{timestamp}-",  "")
                            path_prefix = dir.split("/")[:-1]
                            path_prefix.append(folder_name)
                            joined_path_prefix =   "/".join(path_prefix[2:])
                            error["rawFiles"].append(joined_path_prefix)
                            error["fileTimeStamps"].append(timestamp)
                            
                if len(error["rawFiles"])> 0:
                    self.queue_services_sqsExports.writeToQueue(json.dumps(error))
            else: 
                logger.info(f"{self.config.function_friendly_name} - There is no data available to load to {self.config.basePath}")
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - pipeline has failed ")
            fileCount, files, directories = self.blob_service.list_blobs(self.config.basePath)
            self.blob_service.writeSuccessFile('FAILURE', self.config.function_name, self.config.execStart, fileCount, files, self.config.basePath) 
            raise e


def main(msg: func.QueueMessage):
    try:
        logger.info(f"{FUNCTION_FRIENDLY_NAME} - Starting {FEED_NAME.upper()} FUNCTION")
        queueData = json.loads(msg.get_body().decode("utf-8"))
        mod = downloadS3(queueData)
        mod.run()
        logger.info(f"{FUNCTION_FRIENDLY_NAME} - pipeline has completed successfully !")      
    except Exception as ex:
        logger.exception(f"{FUNCTION_FRIENDLY_NAME} - Exception: Export for {FEED_NAME.upper()}")
        raise ex
