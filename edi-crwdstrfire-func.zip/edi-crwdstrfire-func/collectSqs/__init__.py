import json 
import os
import logging
import azure.functions as func

from ..common import blob_service, queue_service, s3_service, config
from ..common.constant import  FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME


SUFFIX = '-collectSqs'
FEED_NAME += SUFFIX
FUNCTION_FRIENDLY_NAME += SUFFIX.upper()
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger(FEED_NAME)


class exportSQS:

    def __init__(self):
        self.config = config.Config(logger, FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME)
        self.blob_service = blob_service.BlobService(logger, self.config.function_friendly_name, self.config.container_name)
        self.queue_services_sqsExports = queue_service.QueueService(logger, self.config.function_friendly_name, "sqs-exports")
        self.s3_service = s3_service.S3Service(logger, self.config.function_friendly_name, self.config.credentials, self.config.proxyDict, self.config.visibilityTimeout, self.config.maxNumberOfSqsMessages_toRetrieve)
        self.basePath = 'sqsRawMessages' 
    

    def collectSQS(self):
        try:
            logger.info(f"{self.config.function_friendly_name} - Executing Function collectSQS")
            queue = self.s3_service.sqsQueue
            rawMsgList = self.s3_service.getQueueMessages(queue, self.config.numberOfSqsCalls)

            query_message = {'rawFiles': [], 'fileTimeStamps': []}
            sqs_to_delete = []
            for message in rawMsgList:
                data = json.loads(message.body)
                data['MessageReceiptHandle'] = message.receipt_handle
                data['queueUrl'] = message.queue_url

                pathPrefix = data["pathPrefix"]
                bucket = data['bucket']
                fileTimestamp = str(data["timestamp"])
                rawFilename = f"{pathPrefix}/{fileTimestamp}_rawSQSMessage.json"
                try: 
                    successFile = self.s3_service.s3Client.get_object(Bucket = bucket, Key = f"{pathPrefix}/_SUCCESS")
                except:
                    successFile = None
                if successFile:
                    query_message['rawFiles'].append(pathPrefix)
                    query_message['fileTimeStamps'].append(fileTimestamp)
                self.blob_service.Upload(json.dumps(data), f"{self.basePath}/{rawFilename}")
                sqs_to_delete.append({"MessageReceiptHandle": message.receipt_handle, "queueUrl": message.queue_url})

            query_message['bucketName'] = bucket if 'bucket' in locals() else '' 
            number_newRawFiles = len(query_message['rawFiles'])
            number_sqs = len(rawMsgList)

            queue = True 
            if number_sqs > 0 and number_newRawFiles == number_sqs:
                logger.info(f"{self.config.function_friendly_name} - There were {number_newRawFiles} new pathPrefixes ready to ingest, same as sqs messages")
            elif number_sqs > 0:
                logger.info(f"{self.config.function_friendly_name} - There were {number_newRawFiles} new pathPrefixes ready to ingest and {number_sqs} sqs messages")
            else: 
                queue  = False
                logger.warning(f"{self.config.function_friendly_name} - There weren't any pathPreffixes nor sqs message ready")
                
            if queue: 
                logger.info(f"{self.config.function_friendly_name} - Query written: {query_message}")
                self.queue_services_sqsExports.writeToQueue(json.dumps(query_message))
                logger.warning(f"{self.config.function_friendly_name} - SQS to be deleted: {sqs_to_delete}")
                self.s3_service.deleteSqsMessages(sqs_to_delete,  os.getenv("ENVIRONMENT", None))                       

            logger.info(f"{self.config.function_friendly_name} - Success: Function collectSQS")

        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function collectSQS >> {e}")
            raise e


def main(mytimer: func.TimerRequest) -> None:
    try:
        logger.info(f"{FUNCTION_FRIENDLY_NAME} - Starting {FEED_NAME.upper()} FUNCTION")
        mod = exportSQS()
        mod.collectSQS()
        logger.info(f"{FUNCTION_FRIENDLY_NAME} - pipeline has completed successfully !")
    except Exception as ex:
        logger.exception(f"{FUNCTION_FRIENDLY_NAME} - Exception: Export for {FEED_NAME.upper()}")
        raise ex



