import json 
import logging
import azure.functions as func

from ..common import config, queue_service
from ..common.constant import  FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME


SUFFIX = '-downloadS3Failures'
FEED_NAME += SUFFIX
FUNCTION_FRIENDLY_NAME += SUFFIX.upper()
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger(FEED_NAME)


class managePoisonQueue:
    def __init__(self):
        self.config = config.Config(logger, FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME)
        self.queue_services_sqsExports = queue_service.QueueService(logger, self.config.function_friendly_name, "sqs-exports")
        self.queue_services_sqsExportsPoison = queue_service.QueueService(logger, self.config.function_friendly_name, "sqs-exports-poison")


    def run(self):
        try:
            queues =  self.queue_services_sqsExportsPoison.queueClient.receive_messages()
            count = 0
            for queue in queues:
                count += 1
                self.queue_services_sqsExports.writeToQueue(queue.content)
                logger.info(f"{self.config.function_friendly_name} - Queue {queue.content} was exported again to 'sqs-exports' queue ")
                self.queue_services_sqsExportsPoison.queueClient.delete_message(queue.id, queue.pop_receipt)
                logger.info(f"{self.config.function_friendly_name} - Queue was deleted from 'sqs-exports-poison' queue ")
            if count > 0: logger.info(f"{self.config.function_friendly_name} - There were {count} queues and all were exported to 'sqs-exports' queue")
            else: logger.info(f"{self.config.function_friendly_name} - There weren't any queues in 'sqs-exports-poison' queue ")
                     
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - pipeline has failed ")
            raise e


def main(mytimer: func.TimerRequest) -> None:
    try:
        logger.info(f"{FUNCTION_FRIENDLY_NAME} - Starting {FEED_NAME.upper()} FUNCTION")
        mod = managePoisonQueue()
        mod.run()
        logger.info(f"{FUNCTION_FRIENDLY_NAME} - pipeline has completed successfully !")      
    except Exception as ex:
        logger.exception(f"{FUNCTION_FRIENDLY_NAME} - Exception: Export for {FEED_NAME.upper()}")
        raise ex
