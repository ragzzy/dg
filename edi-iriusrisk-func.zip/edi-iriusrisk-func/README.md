# Iriusrisk Ingestion

## Objective
- EDI pipeline to collect hsbc-iriusrisk endpoints.

## RAW ingestion setup
- API: https://hsbc.iriusrisk.com/api/v1/
- Schedule for all possible endpoints: Weekly at 02:00 UTC (All Fridays)

## RAW file structure and definitions
- Storage: default/yyyymmddhhss/int(yyyymmddhhss)/ (edisaprdrisk)

| File | EndPoint | ~ Duration in prd (min) | ~ Size (KB) | # API Calls |  Details | 
| --- | --- | --- | --- | --- | --- | --- |
| products.json.gz | products | 01:00| 650 | 1 | All data |
| groups_ByProduct.json.gz | {product_ref}/products | 05:00 | 40 | # products | All data |
| users_ByProduct.json.gz | {product_ref}/users | 05:00 | 20 | # products | All data |
| businessunits_ByProduct.json.gz | {product_ref}/businessunits | 05:00 | 40 | # products | All data |
| risks_ByProduct.json.gz | {product_ref}/risks |  05:00 | 35 | # products | All data |
| controls_ByProduct.json.gz | {product_ref}/controls/required | 05:00 | 40 | # products | ref, risk, cost & priority |
| threats_ByProduct.json.gz | {product_ref}/risks | 15:00 | 240 | # products | All data |
| weaknesses_ByProduct.json.gz | {product_ref}/weaknesses | 15:00 | 185 | # products | ref, impact & state |

- Key Vault: edi-prd-akv-irisk (EDI team)
- Success/Failure file: EDISTG_SUCCESS.json / EDISTG_FAILURE.json

## Highlights
- Average time in local (4 cores): 1:00 hr
- Average time in prd (sharing VM with cfire & risq): 1:20 min
- Some products don't have data for specific endpoints (ingested as {product: product_ref, endpoint:null})
- Miissing enpoints listed below (reasons vary -> UNAUTHORIZED, NOT FOUND, TIMEOUT)
- Files are gzipped (size in chart)
- 3 Retries if FAILURE/TIMEOUT (each retry is set to be 2 hours from the prev start)

# Contribute
- Get the access permission for the pending endpoints
- Figure out how to extract control's endpoint data

| endpoint | API | Reason | 
| --- | --- | --- |
| groups | groups | Error 401 -> UNAUTHORIZED | 
| users | users | Error 401 -> UNAUTHORIZED | 
| businessunits | businessunits | Error 401 -> UNAUTHORIZED | 
| workflowstates | workflowstates | Error 401 -> UNAUTHORIZED | 
| threats | threats | Error 500 -> SERVER | 
| vulnerabilities | vulnerabilities | Error 404 -> NOT FOUND | 
| libraries | libraries | Error 404 -> NOT FOUND | 
| controls | {product_ref}/controls | TIMEOUT -> 8 hrs in local weren't enough | 
| controls | {product_ref}/controls/implemented | TIMEOUT -> 8 hrs in local weren't enough | 


