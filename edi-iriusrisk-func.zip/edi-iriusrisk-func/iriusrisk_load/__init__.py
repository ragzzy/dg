import os
import json
import requests
import logging
import azure.functions as func
from datetime import datetime, timedelta
from json import JSONDecodeError
from concurrent.futures import ThreadPoolExecutor, as_completed
from retry import retry
from azure.core.exceptions import ResourceNotFoundError

from ..common import config, blob_service
from ..common.constant import FEED_NAME, FUNCTION_FRIENDLY_NAME, FUNCTION_NAME, RETRY, RETRY_INTERVAL

SUFFIX = '-Load'
FEED_NAME += SUFFIX
FUNCTION_FRIENDLY_NAME += SUFFIX.upper()
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger(FEED_NAME)


class Export:

	def __init__(self):
		self.config = config.Config(logger, FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME)
		self.blob_service = blob_service.BlobService(logger, self.config.function_friendly_name, self.config.container_name)	
		self.session = requests.session()	

	@retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
	def getEndPoint(self, endpoint: str):  
		logger.info(f"{self.config.function_friendly_name} - Executing Function getEndPoint for {endpoint}")
		try:
			req =  self.session.get(f"{self.config.APIconnection['url']}/{endpoint}", headers= self.config.APIconnection['header'], proxies= self.config.APIconnection['proxyDict'])
			data = req.json()
			logger.info(f"{self.config.function_friendly_name} - found {len(data)} {endpoint}")
			logger.info(f"{self.config.function_friendly_name} - Success: Executed Function getEndPoint for {endpoint}")
			return data
		except Exception as e:
			logger.error(f"{self.config.function_friendly_name} - Exception - Function getEndPoint for {endpoint} >> {e}")
			raise e

	@retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
	def getDetailData(self, id, detail, labels):
		try:
			response = {'product':id}
			req = self.session.get(f"{self.config.APIconnection['url']}/products/{id}/{detail}", headers= self.config.APIconnection['header'], proxies= self.config.APIconnection['proxyDict'])
			details = req.json()
			if len(labels) >0: 
				details = {label: list(map(lambda id: id[label], details)) for label in labels}
			response[detail] = details
			return response
		except requests.exceptions.JSONDecodeError:
			return {'product':id, detail: None}
		except Exception as e:
			raise e

	@retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
	def getProductDetail(self, prod_ids: list, detail: str, labels: list):
		logger.info(f"{self.config.function_friendly_name} - Executing Function getProductDetails for {detail}")
		try:
			data = []
			with ThreadPoolExecutor(os.cpu_count()) as pool:
				futures = [pool.submit(self.getDetailData, id, detail, labels) for id in prod_ids]	
				for future in as_completed(futures):
					data.append(future.result())
			logger.info(f"{self.config.function_friendly_name} - Success: Function getProductDetails for {detail}")
			return data
		except Exception as e:
			logger.error(f"{self.config.function_friendly_name} - Exception: Function getProductDetails for {detail} >> {e}")
			raise e 

	def readLastExecution(self):
		logger.info(f"{self.config.function_friendly_name} - Executing Function readLastExecution")
		try:
			blob = self.blob_service.blobContainerClient.get_blob_client('lastExecution.json')
			data = blob.download_blob().readall()
			data = json.loads(data.decode('utf-8'))
			blob_execStart = datetime.strptime(data['execStart'], '%Y-%m-%dT%H:%M:%S.%fZ')
			firstExectuion = False if (blob_execStart + timedelta(hours=20)) > datetime.utcnow()  else True
			logger.info(f"{self.config.function_friendly_name} - Success: Function readLastExecution")
			if firstExectuion:
				return self.config.execStart, self.config.basePath, [], 0
			else: 
				return data['execStart'], data['basePath'], data['prod_ids'], data['failureCount']
		except ResourceNotFoundError:
			logger.info(f"{self.config.function_friendly_name} - Success: Function readLastExecution")
			return self.config.execStart, self.config.basePath, [], 0
		except Exception as e:
			logger.error(f"{self.config.function_friendly_name} - Exception: Function readLastExecution >> {e}")


	def run(self):
		try:
			execStart, basePath, prod_ids, failureCount = self.readLastExecution()
			logger.info(f"{self.config.function_friendly_name} - This is the execution number {failureCount+1} from today")
			if failureCount <= 10:  
				if failureCount == 0:
					data = self.getEndPoint('products')
					self.blob_service.Upload(json.dumps(data), f"{basePath}{self.config.endpoints[0][2]}", compress = True)
					prod_ids = list(map(lambda sample: sample['ref'], data))
				self.blob_service.Upload(json.dumps({'execStart': execStart, 'basePath': basePath, 'prod_ids': prod_ids, "failureCount": failureCount+1}), 'lastExecution.json')
				current_file_count, _ = self.blob_service.list_blobs(basePath)
				logger.info(f"{self.config.function_friendly_name} - Currently there are {current_file_count} files ingested in '{basePath}'")
				for i in range(current_file_count, len(self.config.endpoints)):
					detail = self.config.endpoints[i][0]
					labels = self.config.endpoints[i][1]
					filename = self.config.endpoints[i][2]
					data = self.getProductDetail(prod_ids, detail , labels)
					logger.info(f"{self.config.function_friendly_name} - found {len(json.dumps(data))} {detail}")
					self.blob_service.Upload(json.dumps(data), f"{basePath}{filename}", compress = True)
					logger.info(f"{self.config.function_friendly_name} - Success: Executed Function getProductDetails for {detail}")
				file_count, files = self.blob_service.list_blobs(basePath)
				if file_count == len(self.config.endpoints):
					self.blob_service.writeSuccessFile("SUCCESS", self.config.function_name, execStart, file_count, files,basePath)
					self.blob_service.Upload(json.dumps({'execStart': execStart, 'basePath': basePath, 'prod_ids': [], "failureCount": 100}), 'lastExecution.json')
				else:
					raise("The number of files loaded doesn't match with the expected value")
			elif failureCount <100:
				logger.error(f"{self.config.function_friendly_name} - Exception: The app has already failed {failureCount+1} times today")
				raise Exception("The app failed more times than permitted. Should be validated manually")
			else:
				logger.warning(f"{self.config.function_friendly_name} - The app has already been executed succesfully today")
		except Exception as e:
			logger.error(f"{self.config.function_friendly_name} - pipeline has failed ")
			if failureCount >= 3:
				file_count, files = self.blob_service.list_blobs(basePath)
				self.blob_service.writeSuccessFile("FAILURE", self.config.function_name, execStart, file_count, files,basePath)
			raise e


def main(mytimer: func.TimerRequest) -> None:
	try:
		logger.info(f"{FUNCTION_FRIENDLY_NAME} - Starting {FEED_NAME.upper()} Function")
		mod = Export()
		mod.run()
		logger.info(f"{FUNCTION_FRIENDLY_NAME} - pipeline has completed successfully!")
	except Exception as ex:
		logger.exception(f"{FUNCTION_FRIENDLY_NAME} - Exception - Export for {FEED_NAME.upper()}")