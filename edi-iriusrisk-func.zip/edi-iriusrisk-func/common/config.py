import os
import json
from datetime import datetime
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

from .constant import FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME, CONTAINER_NAME


class Config:

    def __init__(self, logger, feedName: str= FEED_NAME, function_name: str= FUNCTION_NAME, function_friendly_name: str = FUNCTION_FRIENDLY_NAME, container_name: str = CONTAINER_NAME):
        utcTimeNow = datetime.utcnow()
        self.execStart = utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.blobFolderName = utcTimeNow.strftime('%Y%m%d%H%M')
        self.epocSubFolderName = int((utcTimeNow.timestamp()))
        self.basePath = "{}/{}/".format(self.blobFolderName, self.epocSubFolderName)
        self.proxyDict = {
			"http": os.getenv("OUTBOUND_PROXY"),
			"https": os.getenv("OUTBOUND_PROXY")
            }
        self.logger = logger
        self.feedName = feedName
        self.function_name = function_name
        self.function_friendly_name = function_friendly_name
        self.container_name = container_name
        self.credentials = self.readSecrets()

        self.APIconnection = {
                            "url": self.credentials['url'],
                            "header": {"api-token":self.credentials['token']},
                            "proxyDict": self.proxyDict
                             } 
        
        self.endpoints = [
                         ["products", 'ref', "products.json.gz"],
                         ["groups", [], "groups_ByProduct.json.gz"],
                         ["users", [], "users_ByProduct.json.gz"],
                         ["businessunits", [], "businessunits_ByProduct.json.gz"],
                         ["risks", [],  "risks_ByProduct.json.gz"], 
                         ["controls/required", ["ref", "risk", "cost", "priority"], "controlsRequired_ByProduct.json.gz"],
                         ["weaknesses", ["ref"], "weaknesses_ByProduct.json.gz"],
                         ["threats", ["ref", "impact", "state"], "threats_ByProduct.json.gz"]
                        ]

        
    def readSecrets(self):
        try:
            self.logger.info(f"{self.function_friendly_name} - Excecuting Function readSecrets")
			
            if os.environ.get("isLocal",None):
                self.credentials = {
                                    'token': os.environ.get("token"),
                                    'url': os.environ.get("url")
                                    }
            else:
                secretClient = SecretClient(
                                            vault_url=os.getenv("DATASOURCE_KEYVAULT_URL"), 
                                            credential=ManagedIdentityCredential()
                                            )
                secret = secretClient.get_secret("credentials")
                self.credentials = json.loads(secret.value)

            self.logger.info(f"{self.function_friendly_name} - Success: Function readSecrets")
            return  self.credentials

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Azure SDK was not able to connect to Key Vault")
            raise 
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Possible wrong Vault name given")
            raise      
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Network Error")
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Azure SDK was not able to deal with my query")
            raise
        except KeyError as ke:
            # check if the key vault URL is present in application insights
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Maybe missing key in Application Insights")
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            self.logger.critical(f"{self.function_friendly_name} - Exception: Function readSecrets >> Unknown error I can't blame Azure for")
            raise  



