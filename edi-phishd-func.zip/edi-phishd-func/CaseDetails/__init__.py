import os
import json
import gzip
import requests
import datetime,timedelta
import logging
from azure.storage.blob import ContentSettings,BlobServiceClient 
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.keyvault.secrets import SecretClient
import azure.functions as func
from retry import retry
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger('phishd')
class Export:
    def __init__(self):
        utcTimeNow         = datetime.datetime.utcnow()
        self.execStart          = utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        blobFolderName     = utcTimeNow.strftime('%Y%m%d%H%M')
        epocSubFolderName  = int((utcTimeNow.timestamp()))
        self.url           = "https://api-v2.phishd.com"
        self.basePath      = "{}/{}/".format(blobFolderName, epocSubFolderName)
        self.lastStopPath  = ""
        self.proxyDict = {
            "http" : os.getenv("OUTBOUND_PROXY"),
            "https": os.getenv("OUTBOUND_PROXY")
        }
        self.stop = datetime.datetime.utcnow().replace(microsecond=0).isoformat()

        self.connectBlob()
        blob_client    = self.blobContainerClient.get_blob_client("lastStop.json")
        exists = blob_client.exists()
        if exists == True:
            content        = blob_client.download_blob().readall()
            data = json.loads(content)
            self.start = data["lastStopDt"]
        else:
            timeNow = datetime.datetime.utcnow().replace(microsecond=0).isoformat()
            self.start = timeNow - timedelta(hours=1)

    def run(self):
        try:
            self.connectBlob()
            self.readSecrets()

            cases = self.getCases()
            self.getDetails(cases)

            self.writeSuccessFile()

            lastStop = {}
            lastStop["lastStopDt"] = self.stop
            self.connectUpload(lastStop, "lastStop.json", self.lastStopPath)   

        except Exception as err:
            logger.exception("EDI-PHISHD-FUNC - Exception - Function run :{}".format(err))
            raise     

    def readSecrets(self):
        try:
            logger.info("EDI-PHISHD-FUNC - Executing Function readSecrets")
            secretClient    = SecretClient(
                vault_url   = os.getenv("DATASOURCE_KEYVAULT_URL")
                ,credential = ManagedIdentityCredential()
            )
            secret = secretClient.get_secret("credentials")
            self.credentials  = json.loads(secret.value)

            self.client_api_id = self.credentials["username"]
            self.client_secret = self.credentials["password"]
            
            logger.info("Success : Executed Function readSecrets")

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical("EDI-PHISHD-FUNC - Exception - Azure SDK was not able to connect to Key Vault", cae)
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical("EDI-PHISHD-FUNC - Exception - Possible wrong Vault name given", hse)
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            logger.critical("EDI-PHISHD-FUNC - Exception - Network Error", sre)
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical("EDI-PHISHD-FUNC - Exception - Azure SDK was not able to deal with my query", ae)
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical("EDI-PHISHD-FUNC - Exception - Unknown error I can't blame Azure for", e)
            raise

    def connectBlob(self):
        try:
            logger.info("EDI-PHISHD-FUNC - Executing Function connectBlob")

            logger.info("connectBlob")
            msiCredential     = ManagedIdentityCredential()
            credentialChain   = ChainedTokenCredential(msiCredential)
            blobServiceClient = BlobServiceClient(
                os.getenv("DATASOURCE_STORAGE_URL")
                ,credential=credentialChain
            )
            self.blobContainerClient = blobServiceClient.get_container_client("default")
            
            logger.info("EDI-PHISHD-FUNC - Success : Executed Function connectBlob")

        except Exception as err:
            logger.critical("EDI-PHISHD-FUNC - Exception - Function connectBlob :{}".format(err))
            raise

    def connectUpload(self, data, fileName,basePath = None):
        logger.info("EDI-PHISHD-FUNC - Executing Function connectUpload")

        blobPath = basePath + fileName
        dataOut = json.dumps(data)
        try:
            self.connectBlob()

            try:
                blob = self.blobContainerClient.get_blob_client(blobPath)

                blobContentSettings = ContentSettings (
                    content_type='application/json'
                )
                blob.upload_blob (
                    dataOut
                    ,blob_type = 'BlockBlob'
                    ,content_settings = blobContentSettings
                    , overwrite=True
                )
            except Exception as e:
                logger.error("EDI-PHISHD-FUNC - Exception - Error Uploading Blob: Crowd Strike phishd : " + blobPath + " >> " + str(e))
                raise
        except Exception as e:
            logger.error( "EDI-PHISHD-FUNC - Exception - Error connecting to Azure Blob Storage:Crowd Strike phishd  >> " + str(e))
            raise

    def compressConnectUpload(self, fileName, data):
        logger.info("EDI-PHISHD-FUNC - Executing Function connectUpload")
        self.blobPath = self.basePath + fileName

        try:
            dataIn = json.dumps(data)
            dataInEncoded = dataIn.encode('utf-8')
            dataOut = gzip.compress(dataInEncoded)

            try:
                self.connectBlob()

                try:
                    blob = self.blobContainerClient.get_blob_client(self.blobPath)

                    blobContentSettings = ContentSettings (
                        content_encoding = "gzip"
                        ,content_type = 'application/octec-stream'
                    )

                    blob.upload_blob (
                        dataOut
                        ,blob_type='BlockBlob'
                        ,content_settings=blobContentSettings
                        
                    )
                except Exception as e:
                    logger.error("EDI-PHISHD-FUNC - Exception - Error Uploading Blob:  Falcon: " + self.blobPath + " >> " + str(e))
                    raise
            except Exception as e:
                logger.error("EDI-PHISHD-FUNC - Exception - Error connecting to Azure Blob Storage: Falcon >> " + str(e))
                raise

        except Exception as e:
            logger.error("EDI-PHISHD-FUNC - Exception - Error Gzipping data >> {}".format(e)) 
            raise

    @retry(Exception, tries=5)
    def getToken(self):
        logger.info("EDI-PHISHD-FUNC - Executing Function getToken")
        try:
            payload = {"client_api_id":self.client_api_id,"client_secret":self.client_secret}
            req = requests.post(self.url + "/auth", json=payload, proxies=self.proxyDict)
            self.token = req.json()["token"]
            self.headers = {"Authorization": "Bearer " + self.token, 'Content-Type': 'application/json'}
            
            logger.info("EDI-PHISHD-FUNC - Success : Executed Function getToken")

        except Exception as err:
            logger.critical("EDI-PHISHD-FUNC - Exception - Error: Function getToken :{}".format(err))
            raise

    @retry(Exception, tries=5)
    def getCases(self):
        logger.info("EDI-PHISHD-FUNC - Executing Function getCases")
        self.getToken()
        try:

            params = {
                "date_available_from": self.start,
                "date_available_to": self.stop,
                "limit": 100,
                "offset": 0,
            }

            cases = []
            while True:
                req = requests.get(self.url + "/cases", headers=self.headers, params=params, proxies=self.proxyDict)
                resp = req.json()

                cases.extend(resp['cases'])

                if resp["paging"]["count"] + resp["paging"]["offset"] < resp["paging"]["total"]:
                    params['offset'] += 100
                    continue
                break

            logger.info("EDI-PHISHD-FUNC - Found {} cases between {} and {}".format(len(cases), self.start, self.stop))
        except Exception as e:
            logger.error("EDI-PHISHD-FUNC - Exception - Error:getCases function :{}".format(e))
            raise

        return cases
        
    @retry(Exception, tries=5)
    def getDetails(self, cases):
        logger.info("EDI-PHISHD-FUNC - Executing Function getDetails")
        try:
            self.getToken()

            casesDetailed = []
            for c in cases:
                req = requests.get(self.url + "/cases/" + str(c["case_id"]), headers=self.headers, proxies=self.proxyDict)
                resp = req.json()

                casesDetailed.append(resp)

            # logger.info(json.dumps(resp, sort_keys=True, indent=4))

            self.connectUpload(casesDetailed, "casesDetailed.json.gz", self.basePath)
        except Exception as e:
            logger.error("EDI-PHISHD-FUNC - Exception - Error:getDetails function :{}".format(e))
            raise

    def writeSuccessFile(self): 
        logger.info("EDI-PHISHD-FUNC - Executing Function writeSuccessFile")
        try:
            blob_list = []
            blob_list = self.blobContainerClient.list_blobs(
                            name_starts_with = self.basePath)

            fileLoadedCount = len(list(blob_list))
            logger.info("The number of files loaded in blob is :{}".format(fileLoadedCount))

            if fileLoadedCount > 0:  
                successFile = {}
                successFile["ediFunctionName"]          = "kk-cde-edi-prd-neu-fa-py-phisd"
                successFile["ediTriggerType"]           = "TimerTrigger"
                successFile["ediFunctionLoadStatus"]    = "Success"
                successFile["ediFeedRunStartDtTime"]    = self.execStart  
                successFile["ediFeedRunEndDtTime"]      = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                successFile["ediFilesWritten"]          = fileLoadedCount
                successFile["ediDestinationPath"]       = self.basePath

                self.connectUpload(successFile, "EDISTG_SUCCESS.json", self.basePath)

                logger.info("EDI-PHISHD-FUNC - Success: Written EDISTG_SUCCESS file to blob >>{}".format(self.basePath))
            else:
                logger.info("EDI-PHISHD-FUNC - There is no data loaded in blob >> {} to write a success file".format(self.basePath))

        except Exception as err:
            logging.error("EDI-PHISHD-FUNC - Exception - Error: Function writeSuccessFile :{}".format(err)) 
            raise

# def main(req: func.HttpRequest) -> func.HttpResponse:
def main(mytimer: func.TimerRequest) -> None:
    logger.info('EDI-PHISHD-FUNC - Starting Phishd Function')
    mod = Export()
    mod.run()
    logger.info("EDI-PHISHD-FUNC - Phishd - pipeline has completed successfully!")
    # return func.HttpResponse("Phishd pipeline has completed successfully!")