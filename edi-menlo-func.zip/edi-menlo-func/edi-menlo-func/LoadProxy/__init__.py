import requests,json,logging,os
import gzip
from datetime import datetime, timedelta
from azure.storage.blob import ContentSettings,BlobServiceClient 
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.keyvault.secrets import SecretClient
import azure.functions as func
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger('menlo')

class Export:
    def __init__(self):
        utcTimeNow         = datetime.utcnow()
        self.execStart     = utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.blobFolderName     = utcTimeNow.strftime('%Y%m%d%H%M')
        self.epocSubFolderName  = int((utcTimeNow.timestamp()))
        feedName           = "menlo"
        self.basePath      = "{}/{}/".format(self.blobFolderName, self.epocSubFolderName)
        self.proxyDict = {
            "http" : os.getenv("OUTBOUND_PROXY"),
            "https": os.getenv("OUTBOUND_PROXY")
        }

    def run(self):
        self.connectBlob()
        blob_client    = self.blobContainerClient.get_blob_client("lastStop.json")
        exists = blob_client.exists()
            
        if exists == True:
            lastStop = blob_client.download_blob().readall()
            self.content = json.loads(lastStop)
            self.lastStopData = self.content["lastRunTsp"]
        else:
            self.now = datetime.utcnow()
            self.lastStopData = (self.now - timedelta(minutes=5))

        self.readSecrets()
        self.downloadProxyLogs() 

        lastStop = {}
        lastStop["lastRunTsp"] = str(self.utcnow)
        self.connectUpload("lastStop.json", lastStop)

    def readSecrets(self):
        try:
            logger.info("EDI-MENLO-FUNC - Executing Function readSecrets")
            secretClient    = SecretClient(
                vault_url   = os.getenv("DATASOURCE_KEYVAULT_URL")
                ,credential = ManagedIdentityCredential()
            )
            secret = secretClient.get_secret("credentials")
            self.credentials  = json.loads(secret.value)

            self.token = self.credentials["token"]
            logger.info("EDI-MENLO-FUNC - Success : Executed Function readSecrets")

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical("EDI-MENLO-FUNC - Exception - Azure SDK was not able to connect to Key Vault", cae)
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical("EDI-MENLO-FUNC - Exception - Possible wrong Vault name given", hse)
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            logger.critical("EDI-MENLO-FUNC - Exception - Network Error", sre)
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical("EDI-MENLO-FUNC - Exception - Azure SDK was not able to deal with my query", ae)
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical("EDI-MENLO-FUNC - Exception - Unknown error I can't blame Azure for", e)
            raise

    def connectBlob(self):
        try:
            logger.info("EDI-MENLO-FUNC - Executing Function connectBlob")

            msiCredential     = ManagedIdentityCredential()
            credentialChain   = ChainedTokenCredential(msiCredential)
            blobServiceClient = BlobServiceClient(
                os.getenv("DATASOURCE_STORAGE_URL")
                ,credential=credentialChain
            )
            self.blobContainerClient = blobServiceClient.get_container_client("default")
            
            logger.info("EDI-MENLO-FUNC -  connected to Blob")

            logger.info("EDI-MENLO-FUNC -  Success : Executed Function connectBlob")
        except Exception as err:
            logger.critical("EDI-MENLO-FUNC - Exception - Error: Function connectBlob :{}".format(err))
            raise

    def connectUpload(self, fileName, data):
        logger.info("EDI-MENLO-FUNC - Executing Function connectBlob")

        if fileName == "lastStop.json":
            blobPath = fileName
            dataOut = json.dumps(data)
        else:
            blobPath = self.basePath + fileName
            dataOut = json.dumps(data)

        try:
            self.connectBlob()

            try:
                blob = self.blobContainerClient.get_blob_client(blobPath)
                blobContentSettings = ContentSettings(
                    content_type='application/json'
                )
                blob.upload_blob(
                    dataOut
                    , blob_type='BlockBlob'
                    , content_settings=blobContentSettings, overwrite=True
                )
                logger.info("EDI-MENLO-FUNC - Success - Executing Function connectBlob")
            except Exception as e:
                logger.error("EDI-MENLO-FUNC - Exception - Error Uploading Blob: Crowd Strike falcon : " + blobPath + " >> " + str(e))
                raise
        except Exception as e:
            logger.error("EDI-MENLO-FUNC - Exception - Error connecting to Azure Blob Storage: Crowd Strike falcon >> " + str(e))
            raise

    def compressConnectUpload(self, fileName, data):
        logger.info("EDI-MENLO - Executing Function compressConnectUpload")
        self.blobPath = self.basePath + fileName

        try:
            dataIn = json.dumps(data)
            dataInEncoded = dataIn.encode('utf-8')
            dataOut = gzip.compress(dataInEncoded)

            try:
                self.connectBlob()

                try:
                    blob = self.blobContainerClient.get_blob_client(self.blobPath)

                    blobContentSettings = ContentSettings (
                        content_encoding = "gzip"
                        ,content_type = 'application/octec-stream'
                    )

                    blob.upload_blob (
                        dataOut
                        ,blob_type='BlockBlob'
                        ,content_settings=blobContentSettings
                        
                    )
                except Exception as e:
                    logger.error("EDI-MENLO - Exception - Error Uploading Blob:  Falcon: " + self.blobPath + " >> " + str(e))
                    raise
            except Exception as e:
                logger.error("EDI-MENLO - Exception - Error connecting to Azure Blob Storage: Falcon >> " + str(e))
                raise

        except Exception as e:
            logger.error("EDI-MENLO - Exception - Error Gzipping data >> {}".format(e)) 
            raise

    def downloadProxyLogs(self):
        try:
            logger.info("EDI-MENLO-FUNC - Executing Function downloadProxyLogs")

            data = []
            payload = {"token": self.token, "log_type": "web"}

            self.utcnow = datetime.utcnow()
            end = int(datetime.timestamp(self.utcnow))
            start = int(datetime.timestamp(datetime.strptime(str(self.lastStopData), '%Y-%m-%d %H:%M:%S.%f')))
            
            logger.info("EDI-MENLO-FUNC - Start {} --- End {}".format(start,end))
            
            while True:
                req = requests.post("https://logs.menlosecurity.com/api/rep/v1/fetch/client_select", json=payload,
                                    params={"start": start, "end": end},proxies=self.proxyDict)
                resp = req.json()[0]
                data.extend(resp['result']['events'])

                logger.info("EDI-MENLO-FUNC - length of response {}".format(len(resp['result']['events'])))

                if len(resp['result']['events']) < 1000:
                    break
                else:
                    if "pagingIdentifiers" not in payload:
                        payload["pagingIdentifiers"] = resp['result']["pagingIdentifiers"]
                    else:
                        for p in resp['result']["pagingIdentifiers"]:
                            payload['pagingIdentifiers'][p] = resp['result']["pagingIdentifiers"][p]

            self.compressConnectUpload("proxy_logs.json.gz", data)

            logger.info("EDI-MENLO-FUNC - Success - Executing Function downloadProxyLogs - Uploaded proxy_logs.json")

            self.writeSuccessFile()

        except Exception as e:
            logger.exception("EDI-MENLO-FUNC - Exception - Error:downloadProxyLogs function :{}".format(e))
            raise

    def writeSuccessFile(self):  # construct success file and write to dest location
        try:
            logger.info("EDI-MENLO-FUNC - Executing Function writeSuccessFile")
            fileLoadedCount = []
            blob_list = self.blobContainerClient.list_blobs(name_starts_with="{}/{}".format(self.blobFolderName, self.epocSubFolderName))
            fileLoadedCount = len(list(blob_list))

            if fileLoadedCount > 0:  # write success file only when data is loaded
                successFile = {}
                successFile["ediFunctionName"]          = "kk-cde-edi-prd-neu-fa-py-menlo"
                successFile["ediTriggerType"]           = "TimerTrigger"
                successFile["ediFunctionLoadStatus"]    = "Success"
                successFile["ediFeedRunStartDtTime"]    = self.execStart
                successFile["ediFeedRunEndDtTime"]      = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                successFile["ediFilesWritten"]          = fileLoadedCount
                successFile["ediDestinationPath"]       = self.basePath

                self.connectUpload("EDISTG_SUCCESS.json",successFile)

                logger.info("EDI-MENLO-FUNC - Successfully Written EDISTG_SUCCESS file {}".format(self.basePath))
            else:
                logger.info("EDI-MENLO-FUNC - There Is No Data Available To Load")
        except Exception as e:
            logging.error("EDI-MENLO-FUNC - Exception - Unable To write EDISTG_SUCCESS file >> Path >> {}".format(e))  
            raise      

# def main(req: func.HttpRequest) -> func.HttpResponse:
def main(mytimer: func.TimerRequest) -> None:
    logger.info('EDI-MENLO-FUNC - Executing Export as standalone script')
    mod = Export()
    logger.info(mod.run())
    logger.info('EDI-MENLO-FUNC - Successfully Executed Menlo Function')
    # return func.HttpResponse("EDI-MENLO-FUNC - Menlo pipeline has completed successfully!")
    
