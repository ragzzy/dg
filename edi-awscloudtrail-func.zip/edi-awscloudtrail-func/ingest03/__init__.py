import boto3
import logging
import sys
import datetime
import azure.functions as func
from azure.keyvault.secrets import SecretClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.storage.blob import BlobServiceClient,ContentSettings
from botocore.config import Config
from  ..util import sqs_handler

# log error format
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("EDI-AWS-CLOUDTRAIL")

def main(mytimer: func.TimerRequest) -> None:
    logger.info("Starting Execution Of EDI-AWS-CLOUDTRAIL")
    mod = sqs_handler.sqsConnector()
    mod.collectS3Location()
    logger.info('Successfully Executed EDI-AWS-CLOUDTRAIL Function')
