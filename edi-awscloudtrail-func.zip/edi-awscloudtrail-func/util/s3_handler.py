import datetime
import os
import logging
import time
import json
import boto3
from azure.keyvault.secrets import SecretClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.storage.blob import BlobServiceClient,ContentSettings
from botocore.config import Config
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceExistsError,
    AzureError
)

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("EDI-AWS-CLOUDTRAIL")


class s3Handler():

    def __init__(self, base_path):
        self.utcTimeNow    = datetime.datetime.utcnow()
        self.basePath      =  base_path
        self.proxyDict     =   {"http": os.getenv("http_proxy") or os.getenv("OUTBOUND_PROXY"),
                                "https": os.getenv("https_proxy") or os.getenv("OUTBOUND_PROXY")}
        self._readSecrets()
        self._connectBlob()

    def _getS3Client(self):
        return boto3.client(
                's3',
                region_name           = self.credentials['sqsRegion'],
                aws_access_key_id     = self.credentials['accessKeyId'],
                aws_secret_access_key = self.credentials['secretAccessKey']
                ,config                = Config(proxies = self.proxyDict)
            ) 
        
    def _connectBlob(self):
        try:
            if (os.getenv("isLocal", None) is not None):
                connection_string = os.environ.get("DATASOURCE_STORAGE_URL", None)
                blobServiceClient = BlobServiceClient.from_connection_string(
                    connection_string
                )
            else:
                msiCredential     = ManagedIdentityCredential()
                credentialChain   = ChainedTokenCredential(msiCredential)
                blobServiceClient = BlobServiceClient(
                    os.environ["DATASOURCE_STORAGE_URL"]
                    ,credential=credentialChain
                )
                
            self.blobContainerClient = blobServiceClient.get_container_client("default")
            logger.info("EDI-AWS-CLOUDTRAIL -Success- Function connectBlob")

        except Exception as err:
            logger.exception('EDI-AWS-CLOUDTRAIL-Exception- Function connectBlob')
            raise
        
        
    def loadBlob(self, blob_file_path:str):
        try:
            logger.info(f"EDI-AWS-CLOUDTRAIL-Started- Function loadBlob -  {blob_file_path}")
            blob =  self.blobContainerClient.get_blob_client(blob_file_path)
            return blob.download_blob().readall()
        except  Exception as e:
            logger.exception("EDI-AWS-CLOUDTRAIL-Exception- Function loadBlob")
            raise
        
        
    def loadS3Files(self,s3bucketName = None,s3bucketFolderPath = None,s3fileName = None , index:int=0):

        try:
            logger.info(f"EDI-AWS-CLOUDTRAIL-Started- Function loadS3Files -  {s3bucketName}/{s3bucketFolderPath}/{s3fileName}")
            #connect to s3
            s3_client = self._getS3Client()
            s3_response_object = s3_client.get_object(Bucket = s3bucketName, Key = s3bucketFolderPath+s3fileName)

            object_content = s3_response_object['Body'].read()
            logger.info("EDI-AWS-CLOUDTRAIL-Started- Function loadS3Files")
            #load s3 data
            self._connectUpload(object_content,s3fileName, index)

            logger.info("EDI-AWS-CLOUDTRAIL-Success- Function loadS3Files")

        except Exception as err:
            logger.exception(f"EDI-AWS-CLOUDTRAIL-Exception- Function loadS3Files ,  {s3bucketName}/{s3bucketFolderPath}/{s3fileName}")
            raise
    

    def _readSecrets(self):
        try:
            if(os.getenv("isLocal", None) is not None):
                self.credentials = {
                            "accessKeyId": os.getenv("accessKeyId", None),
                            "secretAccessKey": os.getenv("secretAccessKey", None),
                            "sqsUrl": os.getenv("sqsUrl", None),
                            "sqsRegion": os.getenv("sqsRegion", None),
                            "storageUrl":os.getenv("DATASOURCE_STORAGE_URL", None),
                        }
            else:
                
                secretClient     = SecretClient(
                    vault_url   = os.environ["DATASOURCE_KEYVAULT_URL"]
                    ,credential  = ManagedIdentityCredential()
                )
                secret           = secretClient.get_secret("credentials")
                self.credentials = json.loads(secret.value)
            logger.info("EDI-AWS-CLOUDTRAIL-Success- Function readSecrets")

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical("EDI-AWS-CLOUDTRAIL-loadS3ToBlob - Exception-Function readSecrets Azure SDK was not able to connect to Key Vault", cae)
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical("EDI-AWS-CLOUDTRAIL-loadS3ToBlob - Exception-Function readSecrets Possible wrong Vault name given", hse)
        except ServiceRequestError:
            # Network error, I will let it raise to higher level
            raise
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical("EDI-AWS-CLOUDTRAIL-loadS3ToBlob - Exception-Function readSecrets Azure SDK was not able to deal with my query", ae)
            raise
        except KeyError as ke:
            #check if the key vault URL is present in application insights
            logger.critical("EDI-AWS-CLOUDTRAIL-loadS3ToBlob -Exception -Function readSecrets Maybe Missing Key in Application Insights", ke)
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical("EDI-AWS-CLOUDTRAIL-loadS3ToBlob - Exception-Function readSecrets Unknown error I can't blame Azure for", e)
            raise


    def _connectUpload(self, data, fileName, index:int=0):
        if index:
            blobPath = f'{self.basePath}/{index}/{fileName}'
        else:
            blobPath = f'{self.basePath}/{fileName}'

        if "SQSMessage" in fileName: 
            blobPath = f'{self.basePath}/rawSqsMessages/{fileName}'
            blobContentSettings = ContentSettings (content_type='application/json')
            data = json.dumps(data)
        elif "EDISTG_SUCCESS" in fileName:
            blobContentSettings = ContentSettings (content_type='application/json')
            data = json.dumps(data)
        else:
            blobContentSettings = ContentSettings(content_encoding = "gzip"
                ,content_type = 'application/gzip'
            )
        try:
            blob = self.blobContainerClient.get_blob_client(blobPath)
            logger.info(f"EDI-AWS-CLOUDTRAIL-processRecords-s3Handler-_connectUpload Starting upload to filepath {blobPath}") 
            blob.upload_blob (
                data
                ,blob_type = 'BlockBlob'
                ,content_settings = blobContentSettings
            )
            logger.info(f"EDI-AWS-CLOUDTRAIL-processRecords-s3Handler-_connectUpload uploaded to filepath {blobPath}") 
        except ResourceExistsError as err:
            ## Copied in a previous run into the same folder
            pass
        except Exception as e:
                logger.error("EDI-AWS-CLOUDTRAIL-Exception- Function connectUpload-Error Uploading Blob: AWS Cloud Trail : " + blobPath + " >> " + str(e))
                raise
            
    def writeSuccessFile(self, index:int=0): 
        try:
            blob_list = []
            blob_list = self.blobContainerClient.list_blobs(name_starts_with = f"{self.basePath}")
            fileLoadedCount = len(list(blob_list))
            logger.info("EDI-AWS-CLOUDTRAIL-writeSuccessFile-The number of files loaded in blob is :{}".format(fileLoadedCount))

            if fileLoadedCount > 0:  
                successFile = {
                    'ediFunctionName': 'kk-cde-edi-prd-neu-fa-py-ctral-ingest03',
                    'ediTriggerType': 'QueueTrigger',
                    'ediFunctionLoadStatus': 'Success',
                    'ediFeedRunStartDtTime': self.utcTimeNow.strftime(
                        '%Y-%m-%dT%H:%M:%S.%fZ'
                    ),
                    "ediFeedRunEndDtTime" : datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ'), 
                    "ediFilesWritten": fileLoadedCount, 
                    "ediDestinationPath":  f"{self.basePath}"
                }


                self._connectUpload(successFile, "EDISTG_SUCCESS.json", None)

                logger.info("EDI-AWS-CLOUDTRAIL -Success- Function writeSuccessFile: Written EDISTG_SUCCESS file to blob >>{}".format(self.basePath))
            else:
                logger.info("EDI-AWS-CLOUDTRAIL -Info-Function writeSuccessFile There is no data loaded in blob >> {} to write a success file".format(self.basePath))

        except Exception as err:
            logging.exception('EDI-AWS-CLOUDTRAIL -Exception - Function writeSuccessFile')
            raise