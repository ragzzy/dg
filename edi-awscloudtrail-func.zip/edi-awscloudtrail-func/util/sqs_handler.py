from typing import Any, Callable, List, Tuple
import boto3
import logging
import datetime
import time
import json
import os
import azure.functions as func
from azure.keyvault.secrets import SecretClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.storage.blob import BlobServiceClient, ContentSettings
from azure.storage.queue import QueueServiceClient, TextBase64EncodePolicy
from botocore.config import Config
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    AzureError,
    ResourceExistsError,
)
import inspect

# log error format
logging.basicConfig(format="%(asctime)s - %(message)s", datefmt="%d-%b-%y %H:%M:%S")
logger = logging.getLogger("EDI-AWS-CLOUDTRAIL")


class sqsConnector:
    def __init__(self):
        self.utcTimeNow = datetime.datetime.utcnow()
        self.epocSubFolder = str(int(time.time()))
        self.blobfolderName = self.utcTimeNow.strftime("%Y%m%d%H%M")
        self.basePath = "{}/{}".format(self.blobfolderName, self.epocSubFolder)
        self.proxyDict = {
            "http": os.getenv("http_proxy") or os.getenv("OUTBOUND_PROXY"),
            "https": os.getenv("https_proxy") or os.getenv("OUTBOUND_PROXY"),
        }
        self.processingQueueName = os.getenv("PROCESSING_QUEUE_NAME", None)
        self._readSecrets()
        self._connectBlob()
        self._connectQueues()

    def _readSecrets(self):
        try:
            if os.getenv("isLocal", None) is not None:
                self.credentials = {
                    "accessKeyId": os.getenv("accessKeyId", None),
                    "secretAccessKey": os.getenv("secretAccessKey", None),
                    "sqsUrl": os.getenv("sqsUrl", None),
                    "sqsRegion": os.getenv("sqsRegion", None),
                    "storageUrl": os.getenv("DATASOURCE_STORAGE_URL", None),
                }
            else:

                secretClient = SecretClient(
                    vault_url=os.environ["DATASOURCE_KEYVAULT_URL"],
                    credential=ManagedIdentityCredential(),
                )
                secret = secretClient.get_secret("credentials")
                self.credentials = json.loads(secret.value)
            logger.info("EDI-AWS-CLOUDTRAIL-loadS3ToBlob-Success- Function readSecrets")

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical(
                "EDI-AWS-CLOUDTRAIL-loadS3ToBlob - Exception-Function readSecrets Azure SDK was not able to connect to Key Vault",
                cae,
            )
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical(
                "EDI-AWS-CLOUDTRAIL-loadS3ToBlob - Exception-Function readSecrets Possible wrong Vault name given",
                hse,
            )
        except ServiceRequestError:
            # Network error, I will let it raise to higher level
            raise
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical(
                "EDI-AWS-CLOUDTRAIL-loadS3ToBlob - Exception-Function readSecrets Azure SDK was not able to deal with my query",
                ae,
            )
            raise
        except KeyError as ke:
            # check if the key vault URL is present in application insights
            logger.critical(
                "EDI-AWS-CLOUDTRAIL-loadS3ToBlob -Exception -Function readSecrets Maybe Missing Key in Application Insights",
                ke,
            )
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical(
                "EDI-AWS-CLOUDTRAIL-loadS3ToBlob - Exception-Function readSecrets Unknown error I can't blame Azure for",
                e,
            )
            raise

    def _connectBlob(self):
        try:
            if os.getenv("isLocal", None) is not None:
                connection_string = os.environ.get("DATASOURCE_STORAGE_URL", None)
                blobServiceClient = BlobServiceClient.from_connection_string(
                    connection_string
                )
            else:
                msiCredential = ManagedIdentityCredential()
                credentialChain = ChainedTokenCredential(msiCredential)
                blobServiceClient = BlobServiceClient(
                    os.environ["DATASOURCE_STORAGE_URL"], credential=credentialChain
                )

            self.blobContainerClient = blobServiceClient.get_container_client("default")

            logger.info("EDI-AWS-CLOUDTRAIL -Success- Function connectBlob")

        except Exception as err:
            logger.error(
                "EDI-AWS-CLOUDTRAIL-Exception- Function connectBlob :{}".format(err)
            )
            raise

    def _connectQueues(self):
        
        try:
            if os.getenv("isLocal", None) is not None:
                connection_string = os.environ.get("DATASOURCE_STORAGE_CONNECTIONSTRING", None)
                queueServiceClient = QueueServiceClient.from_connection_string(
                    connection_string
                )
            else:
                ### Testing with connection string for now
                # msiCredential = ManagedIdentityCredential()
                # credentialChain = ChainedTokenCredential(msiCredential)
                # queueServiceClient = QueueServiceClient(
                #     os.environ["DATASOURCE_QUEUE_URL"],
                #     credential=credentialChain,
                # )
                connection_string = os.environ.get("DATASOURCE_STORAGE_CONNECTIONSTRING", None)
                queueServiceClient = QueueServiceClient.from_connection_string(
                    connection_string
                )
            
            queue_name = self.processingQueueName
            try:
                if queue_name not in queueServiceClient.list_queues():
                    queueServiceClient.create_queue(queue_name)
            except ResourceExistsError as err:
                pass

            self.queueClient = queueServiceClient.get_queue_client(self.processingQueueName)
            self.queueClient.message_encode_policy =  TextBase64EncodePolicy()

            logger.info("EDI-AWS-CLOUDTRAIL -Success- Function _connectQueues")

        except Exception as err:
            logger.exception("EDI-AWS-CLOUDTRAIL-Exception- Function _connectQueues")
            raise

    def connectUpload(self, data, fileName, index=0):
        blobPath = f"{self.basePath}/{fileName}"

        if "SQSMessage" in fileName:
            blobPath = f"{self.basePath}/{index}/rawSqsMessages/{fileName}"
            blobContentSettings = ContentSettings(content_type="application/json")
            data = json.dumps(data)
        elif "EDISTG_SUCCESS" in fileName:
            blobContentSettings = ContentSettings(content_type="application/json")
            data = json.dumps(data)
        else:
            blobContentSettings = ContentSettings(
                content_encoding="gzip", content_type="application/gzip"
            )

        try:
            blob = self.blobContainerClient.get_blob_client(blobPath)

            blob.upload_blob(
                data, blob_type="BlockBlob", content_settings=blobContentSettings , overwrite=True
            )
        except ResourceExistsError:
            pass
        except Exception as e:
            logger.error(
                "EDI-AWS-CLOUDTRAIL-Exception- Function connectUpload-Error Uploading Blob: AWS Cloud Trail : "
                + blobPath
                + " >> "
                + str(e)
            )
            raise

    def _getSQSClient(self) -> Any:
        sqs = boto3.resource(
            "sqs",
            region_name=self.credentials["sqsRegion"],
            aws_access_key_id=self.credentials["accessKeyId"],
            aws_secret_access_key=self.credentials["secretAccessKey"],
            config=Config(proxies=self.proxyDict),
        )
        sqs_client  = boto3.client(
                "sqs",
                region_name=self.credentials["sqsRegion"],
                aws_access_key_id=self.credentials["accessKeyId"],
                aws_secret_access_key=self.credentials["secretAccessKey"],
                config=Config(proxies=self.proxyDict),
            )
        return (sqs.Queue(url=self.credentials["sqsUrl"]) , sqs_client)

    # connect and collect SQS message as list

    def collectSqsMessage(self) -> List[Any]:
        try:
            queue, _ = self._getSQSClient()
            rawMsgList = self._getQueueMessages(queue, 300)

            logger.info(
                "EDI-AWS-CLOUDTRAIL-Success-Function collectSqsMessage: fetched {} messages from SQS".format(
                    len(rawMsgList)
                )
            )
            return rawMsgList
        except Exception as e:
            logger.error(
                "EDI-AWS-CLOUDTRAIL-Exception-Function collectSqsMessage: {}".format(e)
            )
            raise

    def _writeToAzureStorageQueue(self, message):
        try:
            self.queueClient.send_message(message)
        except Exception as e:
            logger.exception(
                "EDI-AWS-CLOUDTRAIL-Exception-Function _writeToAzureStorageQueue"
            )
            raise

    def _getQueueMessages(self, queue, number_of_message: int) -> List:
        try:

            rawMsgList = []
            for _ in range(number_of_message):
                queueList = []
                queueList = queue.receive_messages(
                    VisibilityTimeout=1800, MaxNumberOfMessages=10
                )
                if len(queueList) > 0:
                    rawMsgList.extend(iter(queueList))
                elif rawMsgList:
                    return rawMsgList
            logger.info(
                f"EDI-AWS-CLOUDTRAIL-Success-Function {inspect.stack()[1][3]}: fetched {len(rawMsgList)} messages from SQS"
            )
            return rawMsgList
        except Exception as e:
            logger.error(
                "EDI-AWS-CLOUDTRAIL-Exception-Function collect _getQueueMessagesSqsMessage: {}".format(
                    e
                )
            )

    def collectS3Location(self):
        def chunk_list(seq: List[Any], size: int):
            return (seq[i::size] for i in range(size))

        try:
            rawMsgList = self.collectSqsMessage()
            enrichMsgList = []
            for message in rawMsgList:
                data = json.loads(message.body)
                data["MessageReceiptHandle"] = message.receipt_handle
                data["queueUrl"] = message.queue_url
                enrichMsgList.append(data)

            if len(enrichMsgList) > 0:
                messagesToWrite = filter(
                    lambda x: len(x) > 0, chunk_list(enrichMsgList, 6)
                )

                for index, data in enumerate(messagesToWrite):
                    file_name = (
                        f"{str(round(time.time()*1000000))}_{index}_SQSMessage.json"
                    )
                    queue_message = self._get_storage_queue_message(
                        file_name, index, self.basePath
                    )
                    self.connectUpload(data, file_name, index)
                    self._writeToAzureStorageQueue(queue_message)

        except Exception as err:
            logger.error(
                "EDI-AWS-CLOUDTRAIL-Exception-Function collectS3Location: {}".format(
                    err
                )
            )

    def _get_storage_queue_message(self, file_name: str, index: int, basePath: str):
        return json.dumps(
            {
                "file_name": f"{basePath}/{index}/rawSqsMessages/{file_name}",
                "container_name": "default",
            }
        )

    # Add in retry logic incase of failures.
    def deleteSqsMessage(self, deleteMessageList , environment="prd"):
        def _delete_message(QueueUrl, ReceiptHandle):
            logging.info(f"Deleting message from {QueueUrl}  using {ReceiptHandle}")
            return{
                "ResponseMetadata": {
                    "HTTPStatusCode" : 200
                }
            }
            
        try:
            _, sqs_client  = self._getSQSClient()
            if environment != "prd":
                print(type(sqs_client))
                sqs_client.delete_message = _delete_message
        
            deleteMessageCount = 0
            logger.info("EDI-AWS-CLOUDTRAIL-Starting-Function deleteSqsMessage totalMessages {}".format(len(deleteMessageList)))
            for deleteMsg in deleteMessageList:
                logger.info("EDI-AWS-CLOUDTRAIL-Starting-Function deleteSqsMessage deleting {} {}".format(deleteMsg["queueUrl"] , deleteMsg["MessageReceiptHandle"] ))
                
                respDelete = sqs_client.delete_message(
                    QueueUrl=deleteMsg["queueUrl"],
                    ReceiptHandle=deleteMsg["MessageReceiptHandle"]
                )
                if respDelete["ResponseMetadata"]["HTTPStatusCode"] == 200:
                    deleteMessageCount += 1

            if deleteMessageCount == len(deleteMessageList):
                logger.info("EDI-AWS-CLOUDTRAIL-Success-Function deleteSqsMessage")
                

        except Exception as err:
            logger.exception(
                "EDI-AWS-CLOUDTRAIL-Exception- Function deleteSqsMessage")
