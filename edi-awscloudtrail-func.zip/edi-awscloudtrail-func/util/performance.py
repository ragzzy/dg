import time 
from functools import wraps
from typing import Callable
from time import time
import logging

def logtiming(func: Callable):
    @wraps
    def wrapper(*args, **kwargs):
        start= time.time()
        result=func(*args, **kwargs)
        end= time.time()
        logging.info(f'Function {func.__name__!r} executed in {(start- end):.4f}s')
    