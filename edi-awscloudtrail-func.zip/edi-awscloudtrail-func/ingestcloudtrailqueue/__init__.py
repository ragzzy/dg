from argparse import ArgumentError
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
from typing import Dict, Tuple
import logging
import json
import azure.functions as func
from ..util import s3_handler, sqs_handler
from functools import partial
from datetime import datetime

# log error format
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("EDI-AWS-CLOUDTRAIL")

# Error handling needs to be added into the method.
def main(msg: func.QueueMessage):
    try:
        print(msg.get_body().decode("utf-8")) 
        body = json.loads(msg.get_body().decode("utf-8"))
        logger.info("Starting Execution Of EDI-AWS-CLOUDTRAIL")
        sqsClient = sqs_handler.sqsConnector()  
        return process_blob(body["file_name"], sqsClient)
    except Exception as ex:
        logger.exception("EDI-AWS-CLOUDTRAIL-processRecords-QueueTrigger - Exception-Function processRecords failed")
        raise ex


def  process_blob(blob_path, sqsClient):
    """
    Given a path  like the below.
    /202203151057/1647341833/2/rawSqsMessages/1647341862930591_2_SQSMessage.json
    This method copies files specified in the file from aws into a blob folder /202203151057/1647341833/2/ derived from the above path.
    It uses threads to copy the files in parallel in the event of a failure to copy one file in the batch the whole batch fails and the message is left in the 
    queue. Following a retry of about 5 times(depending on the MaxDequeCount Configuration in host.json) the message will get move into a poision queue
    """
    def get_filepath_structure(filepath_name: str) -> Tuple[str,str,str]:
        basePath = "/".join(
            list(
                filter(
                    lambda x: x != "rawSqsMessages", filepath_name.split("/")[:-1]
                )
            )[:]
        )

        filename = filepath_name.split("/")[-1]
        if "_" in filename and len(filename.split("_")) > 1:
            index = filename.split("_")[1]
        else:
            index = 0
        return (basePath , filename, index) 
            
    deleteMessageList = []
    if "rawSqsMessages" in blob_path:
        basePath, _, index = get_filepath_structure(blob_path)
                
        s3Loader  = s3_handler.s3Handler(basePath)
        logging.info(f"Loading {blob_path} from {basePath}")
        stream = s3Loader.loadBlob(blob_path)
        if stream is not None:
            sqsRawMessages  = json.loads(stream)
                
            copyFromS3ToBlob = partial(processRecords, index,s3Loader)
                
            with ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
                future_to_data = { executor.submit(copyFromS3ToBlob , data): data for data in sqsRawMessages }
                for future in as_completed(future_to_data):
                    try: 
                        e = future.exception()
                        if e:
                            logger.critical("EDI-AWS-CLOUDTRAIL-process_blob-QueueTrigger - One of the worker failed while loading s3 files to blob -{}".format(e))
                            raise e      
                        processedQueue = future.result()
                        deleteMessageList.append(processedQueue)
                    except Exception as  ex:
                        logger.exception("EDI-AWS-CLOUDTRAIL-process_blob-QueueTrigger - Exception-Function processRecords failed")
                        raise e
            sqsClient.deleteSqsMessage(deleteMessageList,  os.getenv("ENVIRONMENT", None))           
            s3Loader.writeSuccessFile(index)
    
def processRecords(index: str, s3Loader , data) -> Dict:
    """
    Copies files from the s3 buckets to the Blob storage using the content of the record passed in as data argument.
    """
    for inc in range(len(data["Records"])):
        try: 
            s3BucketName = data["Records"][inc]["s3"]["bucket"]["name"]
            s3FileName   = data["Records"][inc]["s3"]["object"]["key"].split("/")[-1]
            
            if not s3FileName or not s3BucketName:
                raise Exception(f'S3 File Name/BucketName  cannot be found in the queue message  FileName: {data["Records"][inc]["s3"]["object"]["key"]} and BucketName:{data["Records"][inc]["s3"]["bucket"]["name"]}')
            
            s3FolderName = data["Records"][inc]["s3"]["object"]["key"].split(s3FileName)[0]
            logger.info(f"EDI-AWS-CLOUDTRAIL-processRecords-QueueTrigger about to copy from bucket {s3BucketName} from {s3FolderName}/{s3FileName}") 
            s3Loader.loadS3Files(s3BucketName,s3FolderName , s3FileName, None)
            logger.info(f"EDI-AWS-CLOUDTRAIL-processRecords-QueueTrigger copied  bucket {s3BucketName} from {s3FolderName}")
        except Exception as er:
            logger.exception(
                "EDI-AWS-CLOUDTRAIL-processRecords-QueueTrigger - Exception- for the path {s3BucketName}  for file {s3FileName}"
            )
            raise er from er
    return {"queueUrl" : data["queueUrl"], "MessageReceiptHandle": data["MessageReceiptHandle"]}