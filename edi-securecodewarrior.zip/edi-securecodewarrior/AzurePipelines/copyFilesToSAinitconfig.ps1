param
(
    [Parameter(Position = 0, Mandatory = $True, HelpMessage = "Specify the Tenant ID.")]
    [String] $TenantID,
	[Parameter(Position = 1, Mandatory = $False, HelpMessage = "Specify the name of the subscription.")]
    [String] $subscriptionName,
    [Parameter(Position = 2, Mandatory = $True, HelpMessage = "Specify the Storage Account Resource Group.")]
    [String] $ResourceGroupName,
	[Parameter(Position = 3, Mandatory = $True, HelpMessage = "Specify the Storage Account Name.")]
    [String] $StorageAccountName
)

Import-Module az.storage

## Set proxy - linux agent, trying to run ADO Pipeline.  We proxy to run pwshl in the linux agent.  
$Proxy = "172.20.1.4:3128"

if ($Proxy)
{
    [system.net.webrequest]::defaultwebproxy = new-object system.net.webproxy("http://$($Proxy)")
    [system.net.webrequest]::defaultwebproxy.credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
    [system.net.webrequest]::defaultwebproxy.BypassProxyOnLocal = $true
    [system.net.webrequest]::defaultwebproxy.BypassList = ".core.windows.net"
    write-host "proxy set"
}

# If using AZ CLI then use this, but azcopy will need SAS token anyways, so this may not be useful (or allowed).
#az login --service-principal -u $env:ARMCLIENTID -p $env:ARMCLIENTSECRET --tenant $tenant_id
#Set-PSDebug -Trace 2
#az account set --subscription "kk-cde-edi-dev-sub-01"

$SPNLogin = "true"
try{
if($SPNLogin)
{
    $password = ConvertTo-SecureString $env:ARMCLIENTSECRET -AsPlainText -Force
    $pscredential = New-Object -TypeName System.Management.Automation.PSCredential($env:ARMCLIENTID , $password)
    Connect-AzAccount -ServicePrincipal -Credential $pscredential -Tenant $TenantID -subscription $subscriptionName
}
}
catch {
    write-host "login failed"
}

try{
    $storageAccount = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName
    $ctx = $storageAccount.Context
}
catch {
    write-host "failed to get the storage account details"
}

# TODO: Need to find IP for edi-data agent IP to whitelist

#Set-AzStorageAccount -ResourceGroupName $ResourceGroupName -AccountName $StorageAccountName -NetworkRuleSet (@{ipRules=(@{IPAddressOrRange="99.21.49.205";Action="allow"},@{IPAddressOrRange="103.227.96.20";Action="allow"})})

Get-ChildItem -Path ".\DataFactory\deployment\copyToSAinitconfig\*" | Set-AzStorageBlobContent -Context $ctx -Container "initconfig" -Confirm:$false -Force