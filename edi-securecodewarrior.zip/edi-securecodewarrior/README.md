# SecureCodeWarrior Ingestion

## Objective
- EDI pipeline to load users, developers, activities, assessments and attempts for each assessment from securecodewarrior API portal

## RAW ingestion setup
- API: https://portal-api.securecodewarrior.com/api/v2
- Schedule for all possible endpoints: 24h at 20:00 UTC

## RAW file structure and definitions
- Function App: kk-cde-edi-prd-neu-fa-py-scwr
- Storage: default/yyyymmddhhss/int(yyyymmddhhss)/ (edisaprdscwr)

| File | EndPoint | ~ Duration in prd (min) | ~ Size (MB) | # Chunks |   Params | 
| --- | --- | --- | --- | --- | --- |  --- |
| users.json.gz | users | 03:00 | 3.7 |  1 | &fields=email,role,name,status,tags,team.name,preferredDevLanguages,invite-date,last-login-date |
| developer-progress.json.gz | training/developers-progress | 03:00 | 7.5 |  1 | All data |
| developer-activity.json.gz | training/developers-activity | 45:00 | 29.6 | 1 | All data |
| assessments.json.gz | assessments | 00:30 | 0.004 | 1 | All data | 
| attemtps_{chunk}.json.gz | assessments/{assesment_id}/attemptss | 13:00 per chunk | 12.5 per chunk | 4 | All information |

- Key Vault: edi-prd-akv-scwr (EDI team)
- Success/Failure file: EDISTG_SUCCESS.json / EDISTG_FAILURE.json

## Highlights
- Average time in local (4 cores): 60 min
- Average time in prd (VM shared with jamf, flowlog, akami, ctral): 110 min
- Current Data Factory (edi-prd-adf-securecodewarrior) runs in similar time
- Attempts chunks to avoid memory consumption issue
- Merging attempts chunks creates memory issue
- There are 2 tries for each API call to download all the data. If it didn't, files would be created and logs would warn about it 
- Files are gzipped (size in chart)

## Contribute
- Merge all attempts files to get only one: attempts.json.gz
- Download all the data for each endpoint in the first call and validate it's complete
