
from enum import Enum
import os

APPLICATION_JSON_CONTENT='application/json'
APPLICATION_STREAM_CONTENT='application/octec-stream'
APPLICATION_ENCODING="gzip"
BLOB_TYPE = 'BlockBlob'
FEED_NAME = "scwr" 
FUNCTION_NAME = "kk-cde-edi-prd-neu-fa-py-scwr" 
FUNCTION_FRIENDLY_NAME = "EDI-SCWR-FUNC" 
SUCCESS_FILE_NAME = "EDISTG_SUCCESS"
FAILURE_FILE_NAME =  "EDISTG_FAILURE"
CONTAINER_NAME = "default"
RETRY = os.getenv("RETRY", 10)
RETRY_INTERVAL = os.getenv("RETRY_INTERVAL", 5)
class BlobConnectionStrategy(Enum):
    CONNECTION_STRING =1 
    MSI_CONNECTION_STRING=2