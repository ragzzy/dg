import os
import json
from datetime import datetime
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

from .constant import FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME, CONTAINER_NAME, SUCCESS_FILE_NAME, FAILURE_FILE_NAME, BlobConnectionStrategy


class Config:

    def __init__(self, logger, feedName: str= FEED_NAME, function_name: str= FUNCTION_NAME, function_friendly_name: str = FUNCTION_FRIENDLY_NAME, 
                                container_name: str = CONTAINER_NAME):
        utcTimeNow = datetime.utcnow()
        self.execStart = utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.blobFolderName = utcTimeNow.strftime('%Y%m%d%H%M')
        self.epocSubFolderName = int((utcTimeNow.timestamp()))
        self.basePath = "{}/{}/".format(self.blobFolderName, self.epocSubFolderName)
        self.proxyDict = {
			"http": os.getenv("OUTBOUND_PROXY"),
			"https": os.getenv("OUTBOUND_PROXY")}
        self.logger = logger
        self.feedName = feedName
        self.function_name = function_name
        self.function_friendly_name = function_friendly_name
        self.container_name = container_name
        self.connection_strategy = BlobConnectionStrategy.MSI_CONNECTION_STRING if os.getenv("isLocal", None) is None else BlobConnectionStrategy.CONNECTION_STRING  
        self.credentials = self.readSecrets()
        self.url = self.credentials['url']
        self.header =  {"X-API-Key": self.credentials['key']}
        self.chunks = 4
        self.retryValidaiton = 2
        self.endpoints = {'users': {'api': 'users', 'params': '&fields=email,role,name,status,tags,team.name,preferredDevLanguages,invite-date,last-login-date',
                                    'output': 'users', 'file': 'users'},
                          'developers': {'api': 'training/developers-progress', 'params': '', 'output': 'developers', 'file': 'developer-progress'},
                          'activities': {'api': 'training/developers-activity', 'params': '', 'output': 'activities', 'file': 'developer-activity'},
                          'assessments': {'api': 'assessments', 'params': '', 'output': 'assessments', 'file': 'assessments'}}

    def readSecrets(self):
        try:
            self.logger.info(f"{self.function_friendly_name} - reading secrets")
			
            if os.environ.get("isLocal",None):
                self.credentials = {
                                    'key': os.environ.get("key"),
                                    'url': os.environ.get("url")
                                    }
            else:
                secretClient = SecretClient(vault_url=os.getenv("DATASOURCE_KEYVAULT_URL"), credential=ManagedIdentityCredential())
                secret = secretClient.get_secret("credentials")
                self.credentials = json.loads(secret.value)

            self.logger.info(f"{self.function_friendly_name} - secrets successfully read !")
            return  self.credentials

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            self.logger.exception(f"{self.function_friendly_name} - Exception - Azure SDK was not able to connect to Key Vault")
            raise 
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            self.logger.exception(f"{self.function_friendly_name} - Exception - Possible wrong Vault name given")
            raise      
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            self.logger.exception(f"{self.function_friendly_name} - Exception - Network Error")
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            self.logger.exception(f"{self.function_friendly_name} - Exception - Azure SDK was not able to deal with my query")
            raise
        except KeyError as ke:
            # check if the key vault URL is present in application insights
            self.logger.exception(f"{self.function_friendly_name} - Exception - Maybe missing key in Application Insights")
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            self.logger.critical(f"{self.function_friendly_name} - Exception - Unknown error I can't blame Azure for")
            raise


