import json
import requests
import logging
import re
import azure.functions as func
from retry import retry
from datetime import datetime

from ..common import config, blob_service, utils
from ..common.constant import FEED_NAME, FUNCTION_FRIENDLY_NAME, RETRY, RETRY_INTERVAL, SUCCESS_FILE_NAME, FAILURE_FILE_NAME

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger(FEED_NAME)


class Export:

    def __init__(self):
        self.config = config.Config(logger)
        self.blob_service = blob_service.BlobService(self.config, logger)
        self.session = requests.session()

    
    @retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
    def getData(self, page, args):
        api, params, file = args[0], args[1], args[2]
        logger.error(f"{self.config.function_friendly_name} - Executing Function getData for {file} in page {page}")
        try:
            req = self.session.get(f"{self.config.url}/{api}", params=f"page={page}{params}",headers=self.config.header,  proxies=self.config.proxyDict)
            logger.error(f"{self.config.function_friendly_name} - Sucess: Function getData for {file} in page {page}")
            return req.json()
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function getData for {file} in page {page} >> {e}")
            raise e

    
    @retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
    def getPages(self, api: str, reference: str) -> str:
        logger.info(f"{self.config.function_friendly_name} - Executing Function getPages for {reference}")
        try: 
            req = self.session.get(f"{self.config.url}/{api}", headers=self.config.header,  proxies=self.config.proxyDict)
            logger.info(f"{self.config.function_friendly_name} - Success: Function getPages for {reference}")
            return req.json()['links']['total_pages']
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function getPages for {reference} >> {e}")
            raise e
    

    @retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
    def getTotal(self, api: str, reference: str) -> int:
        logger.info(f"{self.config.function_friendly_name} - Executing Function getTotal for {reference}")
        try: 
            req = self.session.get(f"{self.config.url}/{api}", headers=self.config.header,  proxies=self.config.proxyDict)
            logger.info(f"{self.config.function_friendly_name} - Success: Function getTotal for {reference}")
            return int(req.json()['links']['total_results'])
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} -Exception: Function getTotal for {reference} >> {e}")
            raise e


    @retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
    def getAssesments(self) -> list:
        logger.info(f"{self.config.function_friendly_name} - Executing Function getAssesments")
        try: 
            req = self.session.get(f"{self.config.url}/assessments", headers=self.config.header,  proxies=self.config.proxyDict)
            logger.info(f"{self.config.function_friendly_name} - Success: Function getAssesments")
            return req.json()['assessments']
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function getAssesments >> {e}")
            raise e


    def getValidData(self, endpoint: dict, pages: list, reference: str):
        tries = self.config.retryValidaiton
        logger.info(f"{self.config.function_friendly_name} - Executing Function getValidData for {reference}")
        try:
            for i in range(tries): 
                total_results = self.getTotal(endpoint['api'], reference)
                data = utils.runParallel(self.getData, pages, logger, self.config.function_friendly_name, endpoint['api'], endpoint['params'], endpoint['file'])
                val_total_results = 0
                for sample in data:
                    if type(sample[endpoint['output']]) == list: val_total_results += len(sample[endpoint['output']])
                if val_total_results < total_results and (i+1)< tries: 
                    logger.warning(f"{self.config.function_friendly_name} - Retrying: Function  getValidData for {reference} >> Missmatching current total results with original data")
                    continue
                elif val_total_results < total_results: logger.warning(f"{self.config.function_friendly_name} - found {val_total_results} from {total_results} results for {reference}")
                else: logger.info(f"{self.config.function_friendly_name} - found {val_total_results} results for {reference}")
                logger.info(f"{self.config.function_friendly_name} - Success: Function getValidData for {reference}")
                return data
            raise Exception("Impossible to get valid data after {tries} tries")
        except Exception  as e:
                logger.error(f"{self.config.function_friendly_name} - Exception: Function getValidData for {reference} >> {e}")
                raise e


    def dowloadData(self, endpoint: dict, sub_endpoint: str = ''):
        reference = endpoint['file'] if not sub_endpoint else f"{sub_endpoint}_{endpoint['file']}"
        logger.info(f"{self.config.function_friendly_name} - Executing Function dowloadData for {reference}")
        try:
            page_count = self.getPages(endpoint['api'], reference)
            pages = [str(i) for i in range(1,int(page_count)+1)]
            logger.info(f"{self.config.function_friendly_name} - found {page_count} pages for {reference}")
            data = self.getValidData(endpoint, pages, reference)
            if not sub_endpoint and data:
                self.blob_service.compressUpload(json.dumps(data), f"{self.config.basePath}{reference}.json.gz")
                logger.info(f"{self.config.function_friendly_name} - Success: Function dowloadData for {reference}")
            elif data: 
                logger.info(f"{self.config.function_friendly_name} - Success: Function dowloadData for {reference}")
                return data
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} -  Exception: Function dowloadData for {reference} >> {e}")	
            raise e


    def downloadAttempts(self, assessments: list) -> list:
        logger.info(f"{self.config.function_friendly_name} - Executing Function downloadAttempts")
        try: 
            i , window = 0, int(len(assessments)/self.config.chunks)
            attempt_files = [f"{self.config.basePath}attempts_{chunk}.json.gz" for chunk in range(1,self.config.chunks+1)]
            for chunk in range(self.config.chunks):
                data = []
                for assesment in assessments[i:i+window]: 
                    endpoint = {'api': f"assessments/{assesment['_id']}/attempts", 'params': '',  'output': 'attempts', 'file': 'attempts'}
                    data.extend(self.dowloadData(endpoint, assesment['_id']))
                self.blob_service.compressUpload(json.dumps(data), attempt_files[chunk])
                i += window
            logger.info(f"{self.config.function_friendly_name} - Success: Function downloadAttempts")
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function downloadAttempts >> {e}")
            raise e


    def run(self):
        try: 
            for endpoint in self.config.endpoints.values(): self.dowloadData(endpoint)
            assessments = self.getAssesments()
            self.downloadAttempts(assessments)
            files = self.blob_service.list_blobs(self.config.basePath)
            file_count = len(files['files'])
            if file_count >0:
                manifest  = utils.get_manifest(file_count, files, "SUCCESS", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
                self.blob_service.Upload(json.dumps(manifest), f"{self.config.basePath}{SUCCESS_FILE_NAME}.json")
            else: logger.info(f"{self.config.function_friendly_name} - There is no data available to load to {self.config.basePath}")
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - pipeline has failed ")
            manifest  = utils.get_manifest(file_count, files, "FAILURE", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
            self.blob_service.Upload(json.dumps(manifest), f"{self.config.basePath}{FAILURE_FILE_NAME}.json")
            raise e


def main(mytimer: func.TimerRequest) -> None:
    try:
        logger.info(f"{FUNCTION_FRIENDLY_NAME} - Starting {FEED_NAME} Function")
        mod = Export()
        mod.run()
        logger.info(f"{FUNCTION_FRIENDLY_NAME} - pipeline has completed successfully!")
    except Exception as ex:
        logger.exception(f"{FUNCTION_FRIENDLY_NAME} - Exception: Export for {FEED_NAME}")
        


