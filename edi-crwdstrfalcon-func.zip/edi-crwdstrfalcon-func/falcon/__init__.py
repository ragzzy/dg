import requests,json,time,logging,dateutil,os
import gzip
from datetime import timezone,timedelta,datetime
from typing import List
from azure.storage.blob import ContentSettings,BlobServiceClient 
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.keyvault.secrets import SecretClient
import azure.functions as func
from retry import retry
from dateutil import parser
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

# log error format
logging.basicConfig(format='%(asctime)s - %(message)s',datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("crowdStrikeFalconActivity")

class Export:

    def __init__(self):
        self.alphabet       = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '.']
        self.endDate        = datetime.now(tz=timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        self.startDate      = self.endDate - timedelta(hours=24)
        self.endDatePrint   = self.endDate.isoformat().replace("+00:00", "Z")
        self.startDatePrint = self.startDate.isoformat().replace("+00:00", "Z")
        self.proxyDict = {
            "http" : os.getenv("OUTBOUND_PROXY"),
            "https": os.getenv("OUTBOUND_PROXY")
        }
        self.utcTimeNow        = datetime.utcnow()
        self.execStart         = self.utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.blobFolderName    = self.utcTimeNow.strftime('%Y%m%d%H%M')
        self.epocSubFolderName = int(self.utcTimeNow.timestamp())

    def readSecrets(self):
        logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function readSecrets")
        try:
            local = os.environ.get("isLocal",None)

            if local:
                # self.credentials = os.environ.get("credentials")
                self.credentials = {"UK_client_id": "927f9062a68e4123aea27c98803f0161","UK_client_secret": "VnF57SW9AOkCZricD8b4Kthx0T2M1ae6uwIvo3js","GR_client_id": "d191dc0c79cc401396ae29924875f36b","GR_client_secret": "Ls27WOQhvcxHCa34luU91Nm5JoiSj6zbnIp0F8Zr","CH_client_id": "f66f43b788344235b4e1e4359297f10e","CH_client_secret": "4Zr9gOVkmlcdYU16v3yXIF75x2sSt0T8uKnDqaAh"}
            else:
                secretClient    = SecretClient(vault_url = os.getenv("DATASOURCE_KEYVAULT_URL"), credential = ManagedIdentityCredential())
                secret = secretClient.get_secret("credentials")
                self.credentials  = json.loads(secret.value)
                
            self.client_id = self.credentials[self.country+"_client_id"]
            self.client_secret = self.credentials[self.country+"_client_secret"]

            logger.info("EDI-CRWDSTRFALCON-FUNC - Success : Executed Function readSecrets")

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical("EDI-CRWDSTRFALCON-FUNC - Exception - Azure SDK was not able to connect to Key Vault", cae)
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical("EDI-CRWDSTRFALCON-FUNC - Exception - Possible wrong Vault name given", hse)
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            logger.critical("EDI-CRWDSTRFALCON-FUNC - Exception - Network Error", sre)
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical("EDI-CRWDSTRFALCON-FUNC - Exception - Azure SDK was not able to deal with my query", ae)
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical("EDI-CRWDSTRFALCON-FUNC - Exception - Unknown error I can't blame Azure for", e)
            raise

    def connectBlob(self):
        logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function connectBlob")
        try:
            local = os.environ.get("isLocal",None)
            containerName = "default"

            if local:
                connection_string = os.environ.get("DATASOURCE_STORAGE_URL")
                blobServiceClient = BlobServiceClient.from_connection_string(connection_string)
                self.blobContainerClient = blobServiceClient.get_container_client(containerName)
            else:
                msiCredential     = ManagedIdentityCredential()
                credentialChain   = ChainedTokenCredential(msiCredential)
                blobServiceClient = BlobServiceClient(
                    os.getenv("DATASOURCE_STORAGE_URL")
                    ,credential = credentialChain
                )
                self.blobContainerClient = blobServiceClient.get_container_client(containerName)

            logger.info("EDI-CRWDSTRFALCON-FUNC - connected to Blob")

            logger.info("EDI-CRWDSTRFALCON-FUNC - Success : Executed Function connectBlob")
        except Exception as err:
            logger.critical("EDI-CRWDSTRFALCON-FUNC - Exception - Error: Function connectBlob :{}".format(err))
            raise
    
    def connectUpload(self,fileName,data):
        logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function connectUpload")
        
        if fileName == "lastStop.json":
            blobPath = fileName
            dataOut = json.dumps(data)
        else:
            blobPath = self.basePath + fileName
            dataOut = json.dumps(data)
        
        logger.info(f"EDI-CRWDSTRFALCON-FUNC - Uploading file {fileName} to {blobPath}")

        try:
            self.connectBlob()
            try:
                blob = self.blobContainerClient.get_blob_client(blobPath)
                blobContentSettings = ContentSettings (
                    content_type='application/json'
                )
                blob.upload_blob (
                    dataOut
                    ,blob_type='BlockBlob'
                    ,content_settings=blobContentSettings, overwrite=True
                )
            except Exception as e:
                logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error Uploading Blob: Crowd Strike falcon : " + blobPath + " >> " + str(e))
                raise
        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error connecting to Azure Blob Storage: Crowd Strike falcon >> " + str(e))
            raise

    def compressConnectUpload(self, fileName, data):
        logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function compressConnectUpload")
        self.blobPath = self.basePath + fileName

        logger.info(f"EDI-CRWDSTRFALCON-FUNC - Uploading file {fileName} to {self.basePath}")
        
        try:
            dataIn = json.dumps(data)
            dataInEncoded = dataIn.encode('utf-8')
            dataOut = gzip.compress(dataInEncoded)
            try:
                self.connectBlob()
                try:
                    blob = self.blobContainerClient.get_blob_client(self.blobPath)
                    blobContentSettings = ContentSettings(content_encoding = "gzip", content_type = 'application/octec-stream')
                    blob.upload_blob(dataOut, blob_type='BlockBlob', content_settings=blobContentSettings)

                except Exception as e:
                    logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error Uploading Blob:  Falcon: " + self.blobPath + " >> " + str(e))
                    raise
            except Exception as e:
                logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error connecting to Azure Blob Storage: Falcon >> " + str(e))
                raise
        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error Gzipping data >> {}".format(e)) 
            raise

    def getToken(self):
        logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function getToken")
        try: 
            self.readSecrets()

            req = requests.post("https://api.crowdstrike.com/oauth2/token"
            , data={"client_id": self.client_id 
            , "client_secret":self.client_secret}
            , proxies=self.proxyDict
            )
            r = req.json()
            self.authHeader = {"Authorization": "Bearer "+r['access_token']}
            logger.info("EDI-CRWDSTRFALCON-FUNC - Requested new token")

            return self.authHeader
        except Exception as e:
            logger.error("EDI-CRWDSTRFALCON-FUNC - Exception - Error: getToken function:{} ".format(e))
            raise

    @retry(Exception, tries=5)
    def jsonGet(self, url, jsonPost=None):
        logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function jsonGet")

        try:
            if jsonPost is None:
                logger.info(f"EDI-CRWDSTRFALCON-FUNC - jsonGet - Get - Try = {url[:100]}")
                req = requests.get(url, headers=self.authHeader, proxies=self.proxyDict)
            else:
                logger.info(f"EDI-CRWDSTRFALCON-FUNC - jsonGet - Post - Try = {url[:100]}")
                req = requests.post(url, json=jsonPost, headers=self.authHeader, proxies=self.proxyDict)
            resp = req.json()

            # this grabs all kinds of error messages and just assumes the token is invalid and tries again
            # so far checking logs confirmed that the token expires "randomly" ¯\_(ツ)_/¯
            if len(resp['errors']) != 0:
                logger.info(f"EDI-CRWDSTRFALCON-FUNC - {resp}")
                self.getToken()
                # raise Exception("Invalid Token")

            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Success Executing Function jsonGet - {url}")
            return resp

        except Exception as e:
            logger.exception(f"EDI-CRWDSTRFALCON-FUNC - Exception - download failed {e}")
            raise e

    def filterTimestampByEnd(self, lst):
        logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function filterTimestampByEnd")
        try:
            filteredLst = []
            for e in lst:
                # assuming e['timestamp'] is string in form of "2021-05-17T08:00:00Z"
                d = parser.parse(e['timestamp']).replace(tzinfo=dateutil.tz.UTC)
                if d > self.endDate:
                    continue
                filteredLst.append(e)
            return filteredLst
        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error: filterTimestampByEnd function: {}".format(e)) 
            raise   

    def checklaststop(self):
        logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function checklaststop")
        try:
            self.connectBlob()
            blob_client    = self.blobContainerClient.get_blob_client("lastStop.json")
            exists = blob_client.exists()
            utcTimeNowDate = self.utcTimeNow.date()

            if exists == True:
                logger.info("EDI-CRWDSTRFALCON-FUNC - LastStop exists")
                content = "{}"
                content = blob_client.download_blob().readall()
                lastStopData = json.loads(content)
                lastStopDate = datetime.strptime(str(lastStopData["lastRunTsp"]), '%Y-%m-%d %H:%M:%S.%f').date()

                self.country = lastStopData["country"]

                if lastStopData["country"] == "UK":
                    nextcountry = "GR"
                elif lastStopData["country"] == "GR":
                    nextcountry = "CH"
                elif lastStopData["country"] == "CH":
                    nextcountry = "CH"
            else:
                logger.info("EDI-CRWDSTRFALCON-FUNC - LastStop does not exist")
                lastStopDate = datetime.strptime(str(self.utcTimeNow - timedelta(days=1)), '%Y-%m-%d %H:%M:%S.%f').date()
                self.country = "UK"
            
            if utcTimeNowDate > lastStopDate:
                lastStop = {}
                lastStop["country"] = "UK"
                lastStop["status"] = "WIP"
                lastStop["lastRunTsp"] = str(self.utcTimeNow)
                self.connectUpload("lastStop.json",lastStop)

                self.download("UK")

            elif utcTimeNowDate == lastStopDate:
                if self.country == lastStopData["country"] and lastStopData["status"] == "WIP":
                    pass
                elif nextcountry != lastStopData["country"] and lastStopData["status"] == "Completed":
                    lastStop = {}
                    lastStop["country"] = nextcountry
                    lastStop["status"] = "WIP"
                    lastStop["lastRunTsp"] = str(self.utcTimeNow)
                    self.connectUpload("lastStop.json",lastStop)

                    self.download(nextcountry)
            logger.info("EDI-CRWDSTRFALCON-FUNC - Executing Function checklaststop")

        except Exception as e:
            logger.error("EDI-CRWDSTRFALCON-FUNC - Exception - Error: checklaststop function: {}".format(e))   

    def download(self,country = None):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading <<<<<<<<<<<<<  {country}  >>>>>>>>>>>>>>")

            self.basePath  = "{}/{}/{}/".format(country, self.blobFolderName, self.epocSubFolderName)
            self.country = country
            self.readSecrets() 
            self.authHeader = self.getToken() 

            if country == "UK" or country == "GR":

                incidentIds = self.downloadIncidentIds() 
                self.downloadIncidents(incidentIds)

                behaviorIds = self.downloadIncidentBehaviorIds()
                self.downloadIncidentBehaviors(behaviorIds)

                detectionIds = self.downloadDetectionIds()
                self.downloadDetections(detectionIds)

            hostlist = self.downloadHostlist()
            self.downloadHosts(hostlist)

            self.connectBlob()

            self.authHeader = self.getToken()
            prefix = self.basePath + 'download'
            blobs_list =    self.blobContainerClient.list_blobs(name_starts_with=prefix)

            for blob in blobs_list:
                    self.downloadHostsByIds(blob.name)

            self.delete(basePath = self.basePath)

            self.writeSuccessFile(basePath = self.basePath,execStart = self.execStart)

            lastStop = {}
            lastStop["country"] = country
            lastStop["status"] = "Completed"
            lastStop["lastRunTsp"] = str(self.utcTimeNow)
            self.connectUpload("lastStop.json", lastStop)

            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Successfully Downloaded <<<<<<<<<<<<<  {country}  >>>>>>>>>>>>>>")

            return self.collectfilenames

        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error:{} download function:{}".format(country,e))   
            raise 

    def downloadDetectionIds(self):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Executing Function downloadDetectionIds from {self.country}")
            offset = 0
            detectionIds = []

            while True:
                url  = "https://api.crowdstrike.com/detects/queries/detects/v1?limit=500&offset="+str(offset)+"&"
                resp = self.jsonGet(url)
                detectionIds += resp['resources']
                if (resp != None) and ((len(resp['resources']) == 0) or (len(detectionIds) == resp['meta']['pagination']['total'])):
                    logger.info(f"EDI-CRWDSTRFALCON-FUNC - length of resources = {len(resp['resources'])}")
                    break
                offset += 500
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Success Executing Function downloadDetectionIds from {self.country}. Total detectionIds = {len(detectionIds)}")
            return detectionIds

        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - download failed "+url)
            raise 

    def downloadDetections(self, detectionIds):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading Detections from {self.country}")
            url = "https://api.crowdstrike.com/detects/entities/summaries/GET/v1"
            detections = []
            detectionIdsBatch = []

            for i in detectionIds:
                detectionIdsBatch.append(i)
                if len(detectionIdsBatch) < 100:
                    continue
                resp = self.jsonGet(url, jsonPost={"ids":detectionIdsBatch})
                detections += resp['resources']
                detectionIdsBatch = []
            if len(detectionIdsBatch) > 0:
                resp = self.jsonGet(url, jsonPost={"ids":detectionIdsBatch})
                detections += resp['resources']
            self.compressConnectUpload("detections.json.gz",detections)

            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Succesfully Downloaded Detections from {self.country}. Total detections = {len(detections)}")
        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error in downloadDetections function:{}{} ".format( self.country,e))   
            raise  

    def downloadIncidentBehaviorIds(self):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading IncidentBehaviorIds from {self.country}")
            offset = 0
            behaviorIds = []

            while True:
                url = "https://api.crowdstrike.com/incidents/queries/behaviors/v1?limit=500&offset="+str(offset)+"&filter=timestamp:>'"+self.startDatePrint+"'"
                resp = self.jsonGet(url)
                behaviorIds += resp['resources']
                if len(resp['resources']) == 0 or len(behaviorIds) == resp['meta']['pagination']['total']:
                    break
                offset += 500
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Succesfully Downloaded IncidentBehaviorIds from {self.country}. Total behaviorIds = {len(behaviorIds)}")
            return behaviorIds
        
        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - download failed "+url)
            raise

    def downloadIncidentBehaviors(self, behaviorIds):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading IncidentBehaviors from {self.country}")
            url = "https://api.crowdstrike.com/incidents/entities/behaviors/GET/v1"
            behaviors = []
            behaviorIdsBatch = []

            for i in behaviorIds:
                behaviorIdsBatch.append(i)
                if len(behaviorIdsBatch) < 100:
                    continue

                resp = self.jsonGet(url, jsonPost={"ids":behaviorIdsBatch})
                lst = self.filterTimestampByEnd(resp['resources'])
                behaviors.append(lst)
                behaviorIdsBatch = []

            if len(behaviorIdsBatch) > 0:
                resp = self.jsonGet(url, jsonPost={"ids":behaviorIdsBatch})
                lst = self.filterTimestampByEnd(resp['resources'])
                behaviors.append(lst)

            self.compressConnectUpload("behaviors.json.gz",behaviors)

            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Succesfully Downloaded IncidentBehaviors from {self.country}. Total behaviors = {len(behaviors)}")
        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error in downloadIncidentBehaviors function: {}{}".format( self.country,e))     
            raise

    def downloadIncidentIds(self):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading IncidentIds from {self.country}")
            offset = 0
            incidentIds = []

            while True:
                url = "https://api.crowdstrike.com/incidents/queries/incidents/v1?limit=500&offset="+str(offset)
                resp = self.jsonGet(url)
                incidentIds += resp['resources']
                if len(resp['resources']) == 0 or len(incidentIds) == resp['meta']['pagination']['total']:
                    break
                offset += 500
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Successfully Downloaded IncidentIds from {self.country}. Total incidentIds {len(incidentIds)}")
            return incidentIds 

        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - download failed {}".format(self.country)+url)
            raise e     

    def downloadIncidents(self, incidentIds):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading Incidents from {self.country}")
            url = "https://api.crowdstrike.com/incidents/entities/incidents/GET/v1"
            incidents = []
            incidentIdsBatch = []
            for i in incidentIds:
                incidentIdsBatch.append(i)
                if len(incidentIdsBatch) < 100:
                    continue
                resp = self.jsonGet(url, jsonPost={"ids":incidentIdsBatch})
                incidents += resp['resources']
                incidentIdsBatch = []
            if len(incidentIdsBatch) > 0:
                resp = self.jsonGet(url, jsonPost={"ids":incidentIdsBatch})
                incidents += resp['resources']

            self.compressConnectUpload("incidents.json.gz",incidents)

            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Succesfully Downloaded Incidents from {self.country}. Total incidents = {len(incidents)}")
        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error:downloadIncidents function :{}{}".format( self.country,e)) 
            raise    

    def downloadHostlist(self):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading Hostlist from {self.country}")
            hostlist = []

            for a in self.alphabet:
                hostlist = self.downloadHostlistByHostname(a)
                self.connectUpload(f"hostlist_{a}.json",hostlist)
                logger.info("EDI-CRWDSTRFALCON-FUNC - uploaded hostlist_{}.json".format(a))
            self.merge("hostlist_", "hostlist.json.gz", self.basePath)
            

            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Successfully Downloaded Hostlist from {self.country}. Total hostlist = {len(hostlist)}")

            return hostlist
        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error: downloadHostlist function :{} {}".format( self.country,e))
            raise

    def downloadHostlistByHostname(self, hostname, limit = 5000, offset=0, results=None):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading HostlistByHostname from {self.country}")

            url = "https://api.crowdstrike.com/devices/queries/devices/v1?limit="+str(limit)+"&offset="+str(offset)+"&filter=hostname:'"+hostname+"*'"
            logger.info("EDI-CRWDSTRFALCON-FUNC- URL - {}".format(url))

            if results == None:
                results = []
            resp = self.jsonGet(url)
            # check if we can really get all hosts, added check for broken API responses
            if resp['meta']['pagination']['total'] >= 150000 and len(resp['resources']) == 5000:
                logger.info("Hostname {} produced {} results, trying to narrow search down...".format(hostname, resp['meta']['pagination']['total']))
                for a in self.alphabet:
                    results += self.downloadHostlistByHostname(hostname+a)
                return results
            else:
                results += resp['resources']
                if len(resp['resources']) == 0 or len(results) == resp['meta']['pagination']['total']:
                    return results
                
                if resp['meta']['pagination']['offset'] + resp['meta']['pagination']['limit'] > resp['meta']['pagination']['total']:
                    limit = resp['meta']['pagination']['total'] - resp['meta']['pagination']['offset']
                else:
                    limit = 5000

                return self.downloadHostlistByHostname(hostname, limit, resp['meta']['pagination']['offset'], results)

        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error:downloadHostlistByHostname function: {}{} ".format(self.country,e))
            raise

    def downloadHosts(self, hostlist):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading Hosts from {self.country}")

            ids = []
            urlCount = 0
            fileCount = 1
            self.collectfilenames = []
            
            downloadHostsUrls = []
            for i in hostlist:
                ids.append(i)

                if len(ids) >= 1000:
                    urlSuffix = '&ids='.join(ids)
                    urlCount += 1

                    downloadHostsUrls.append(urlSuffix)
                    ids = []
                    if urlCount >= 49:
                        urlData = {}
                        urlData['prefix'] = 'https://api.crowdstrike.com/devices/entities/devices/v1?ids='
                        urlData['suffix'] = downloadHostsUrls

                        self.connectUpload("downloadHostsUrls_{}.json".format(str(fileCount)), urlData)
                        self.collectfilenames.append("{}downloadHostsUrls_{}.json".format(self.basePath,str(fileCount)))
                        fileCount += 1
                        downloadHostsUrls = []
                        urlCount = 0

            if len(ids) > 0:
                urlSuffix = '&ids='.join(ids)
                downloadHostsUrls.append(urlSuffix)

                urlData = {}
                urlData['prefix'] = 'https://api.crowdstrike.com/devices/entities/devices/v1?ids='
                urlData['suffix'] = downloadHostsUrls

                self.connectUpload("downloadHostsUrls_{}.json".format(str(fileCount)), urlData)
                self.collectfilenames.append("{}downloadHostsUrls_{}.json".format(self.basePath,str(fileCount)))
                downloadHostsUrls = []

            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Successfully Downloaded Hosts from {self.country}. Total downloadHostsUrls = {len(downloadHostsUrls)}")

        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error: downloadHosts function {}: ".format(e))
            raise

    def downloadHostsByIds(self,file = None):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Downloading HostsByIds from {self.country}")
            collectionHost = []
            blob_client    = self.blobContainerClient.get_blob_client(file)
            content        = blob_client.download_blob().readall()

            logger.info("EDI-CRWDSTRFALCON-FUNC - File Read - Now - {}".format(file))

            arr = json.loads(content)

            logger.info("EDI-CRWDSTRFALCON-FUNC - File Length - {}".format(len(arr["suffix"])))
            for i in arr["suffix"]:
                url = "https://api.crowdstrike.com/devices/entities/devices/v1?ids="+str(i)
                
                hosts = self.jsonGet(url)
                if len(hosts) > 0:  # prevent empty lines from broken API responses
                    collectionHost.append(hosts)

            self.compressConnectUpload("hosts_{}.json.gz".format(str(arr["suffix"][0][:10])), collectionHost)
            logger.info("Downloaded hosts_{}.json.gz".format(str(arr["suffix"][0][:10])))

            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Successfully Downloaded HostsByIds from {self.country}")

        except Exception as e:
            logger.exception("EDI-CRWDSTRFALCON-FUNC - Exception - Error: downloadHostsByIds function: {}".format(e)) 
            raise

    def merge(self, startswith, filename, basePath = None):
        try:
            logger.info(f"EDI-CRWDSTRFALCON-FUNC - Merging files {startswith}")
            self.connectBlob()
            prefix = basePath + startswith
            blob_files_names = self.blobContainerClient.list_blobs(name_starts_with = prefix)
            collectionHost = []
            for blob in blob_files_names:
                blob_client = self.blobContainerClient.get_blob_client(blob.name)
                content = "{}"
                content = blob_client.download_blob().readall()
                collectionHost.append(json.loads(content))

            self.compressConnectUpload(filename,collectionHost)

            logger.info("EDI-CRWDSTRFALCON-FUNC - Successfully merged files - {startswith}")

        except Exception as err:
            logger.critical("EDI-CRWDSTRFALCON-FUNC - Exception - Error: Function merge :{}".format(err))
            raise  

    def delete(self, basePath = None):
        try:
            logger.info("EDI-CRWDSTRFALCON-FUNC - Success Executing Function delete")
            self.connectBlob()
            prefixList = ['downloadHostsUrls_','stage1_','hostlist_']

            for i in prefixList:
                logger.info(f"EDI-CRWDSTRFALCON-FUNC - Deleting {i}")
                logger.info(f"EDI-CRWDSTRFALCON-FUNC - Deleting {basePath} {i}")
                prefix = basePath + i
                blob_files_names = self.blobContainerClient.list_blobs(name_starts_with = prefix)
                logger.info(f"EDI-CRWDSTRFALCON-FUNC - blob_files_names = {blob_files_names}")
                for l in blob_files_names:
                    logger.info(f"EDI-CRWDSTRFALCON-FUNC - Deleting {l.name}")
                    self.blobContainerClient.delete_blob(l.name)

            logger.info("EDI-CRWDSTRFALCON-FUNC - Executing delete function sucess")

        except Exception as err:
            logger.critical("EDI-CRWDSTRFALCON-FUNC - Exception - Error: Function delete :{}".format(err))
            raise  
            
    def writeSuccessFile(self,basePath = None,execStart = None): 
        self.connectBlob()

        try:
            logger.info("EDI-CRWDSTRFALCON-FUNC - Success : Invoking writeSuccessFile function")
            blob_list = []
            blob_list = self.blobContainerClient.list_blobs(name_starts_with = basePath)
            fileLoadedCount = len(list(blob_list))

            logger.info("EDI-CRWDSTRFALCON-FUNC - The number of files loaded in blob is :{}".format(fileLoadedCount))

            if (fileLoadedCount > 0):  
                successFile = {}
                successFile["ediFunctionName"]          = "kk-cde-edi-prd-neu-fa-py-cfalco"
                successFile["ediTriggerType"]           = "TimerTrigger"
                successFile["ediFunctionLoadStatus"]    = "Success"
                successFile["ediFeedRunStartDtTime"]    = execStart
                successFile["ediFeedRunEndDtTime"]      = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                successFile["ediFilesWritten"]          = fileLoadedCount
                successFile["ediDestinationPath"]       = basePath

                self.connectUpload("EDISTG_SUCCESS.json",successFile)

                logger.info("EDI-CRWDSTRFALCON-FUNC - Success: Written EDISTG_SUCCESS file to blob >>{}".format(basePath))

                return 1
            else:
                logger.info("EDI-CRWDSTRFALCON-FUNC - There is no data loaded in blob >> {} to write a success file".format(basePath))

        except Exception as err:
            logging.error("EDI-CRWDSTRFALCON-FUNC - Exception - Error: Function writeSuccessFile :{}".format(err)) 

def main(mytimer: func.TimerRequest) -> None:
# def main(req: func.HttpRequest) -> func.HttpResponse:
    logger.info("EDI-CRWDSTRFALCON-FUNC - Success: Invoking falcon function")
    mod = Export()    
    # countryList = ["UK", "GR", "CH"]
    # for country in countryList:   
    mod.checklaststop()
    logger.info("EDI-CRWDSTRFALCON-FUNC - Falcon funtion has completed successfully!")
    # return func.HttpResponse("EDI-CRWDSTRFALCON-FUNC - Falcon funtion has completed successfully!")
