import websocket
import ssl
import certifi
import gzip
import json
import datetime
import time
import os
import logging
from azure.storage.blob import ContentSettings, BlobServiceClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.keyvault.secrets import SecretClient
import azure.functions as func
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

# log error format
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("proofPointPodLogMailLog")

class Export:
    def __init__(self):

        self.utcTimeNow = datetime.datetime.utcnow()
        self.execStart  = self.utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        # blobRecordWriteSize - From experimentation - For eventType maillog use 100000 and message use 25000 to get even sized blobs.
        self.chunkNum  = 0
        self.eventType = "maillog"
        self.blobRecordWriteSize = 100000

        self.blobFolderName    = self.utcTimeNow.strftime('%Y%m%d%H%M')
        self.epocSubFolderName = str(int(time.time()))
        self.feedName          = "pod"
        self.basePath          = "{}/{}/{}/".format(self.feedName,self.blobFolderName, self.epocSubFolderName)
        self.fileNameSuffix    = ".json.gz"

    def compressConnectUpload(self, data, fileName):

        self.blobPath = self.basePath + fileName + self.fileNameSuffix

        try:
            logger.info("EDI-PROOFPOINT-POD-MAILLOG - Executing- Function compressConnectUpload")

            dataIn = json.dumps(data)
            dataInEncoded = dataIn.encode('utf-8')
            dataOut = gzip.compress(dataInEncoded)

            try:
                self.connectBlob()

                try:
                    blob = self.blobContainerClient.get_blob_client(self.blobPath)

                    blobContentSettings = ContentSettings (
                        content_encoding="gzip"
                        ,content_type='application/octec-stream'
                    )

                    blob.upload_blob (
                        dataOut
                        ,blob_type='BlockBlob'
                        ,content_settings=blobContentSettings
                    )
                    logger.info("EDI-PROOFPOINT-POD-MAILLOG - Success- Function compressConnectUpload")

                except Exception as e:
                    logger.error("EDI-PROOFPOINT-POD-MAILLOG- Exception -Error Uploading Blob: " + self.blobPath + " >> " + str(e))
            except Exception as e:
                logger.error("EDI-PROOFPOINT-POD-MAILLOG- Exception -Error connecting to Azure Blob Storage:  >> " + str(e))

        except Exception as e:
            logger.error("EDI-PROOFPOINT-POD-MAILLOG- Exception- Error Gzipping data >> "+str(e))
            raise e

    def connectUpload(self, data, fileName):

        try:
            logger.info("EDI-PROOFPOINT-POD-MAILLOG - Executing- Function connectUpload")

            self.connectBlob()

            # create different path for success file and laststop
            if ("EDISTG_SUCCESS" in fileName):
                self.blobPath      = self.basePath + fileName  
                self.overWriteBool = False

            elif ("podMaillogLastStop" in fileName):
                self.blobPath = self.feedName+'/'+fileName
                self.overWriteBool = True

            try:
                dataOut = json.dumps(data)
                blob = self.blobContainerClient.get_blob_client(self.blobPath)

                blobContentSettings = ContentSettings (
                    content_type='application/json'
                )

                blob.upload_blob (
                    dataOut
                    ,blob_type = 'BlockBlob'
                    ,content_settings = blobContentSettings
                    ,overwrite = self.overWriteBool
                )
                logger.info("EDI-PROOFPOINT-POD-MAILLOG - Success- Function connectUpload path:{}".format(self.blobPath))    
            except Exception as e:
                logger.error("EDI-PROOFPOINT-POD-MAILLOG - Exception - Error Uploading Blob:  Proofpoint POD Log " + self.eventType + " to " + self.blobPath + " >> " + str(e))
                raise
        except Exception as e:
            logger.error("EDI-PROOFPOINT-POD-MAILLOG - Exception - Error connecting to Azure Blob Storage: Proofpoint POD Log MailLog  >> " + str(e))
            raise
        
    def connectBlob(self):
        try:
            logger.info("EDI-PROOFPOINT-POD-MAILLOG - Executing- Function connectBlob") 

            msiCredential = ManagedIdentityCredential()
            credentialChain = ChainedTokenCredential(msiCredential)

            blobServiceClient = BlobServiceClient(
                os.getenv("DATASOURCE_STORAGE_URL")
                ,credential=credentialChain
            )

            self.blobContainerClient = blobServiceClient.get_container_client("default")

            logger.info("EDI-PROOFPOINT-POD-MAILLOG - Success- Function connectBlob") 

        except Exception as e:
            logger.info("EDI-PROOFPOINT-POD-MAILLOG - Exception- Function connectBlob") 
            raise 

    def readSecrets(self):
        try:
            logger.info("EDI-PROOFPOINT-POD-MAILLOG - Executing- Function readSecrets") 

            secretClient = SecretClient(
                vault_url=os.getenv("DATASOURCE_KEYVAULT_URL"), credential=ManagedIdentityCredential())
            secret = secretClient.get_secret("credentialsPodLog")
            self.credentials = json.loads(secret.value)

            self.wsKey = self.credentials['wsKey']
            self._token = self.credentials['token']
            self.cluster_id = self.credentials['clusterId']

            logger.info("EDI-PROOFPOINT-POD-MAILLOG - Success- Function readSecrets") 

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical("EDI-PROOFPOINT-POD-MAILLOG - Exception-Azure SDK was not able to connect to Key Vault", cae)
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical("EDI-PROOFPOINT-POD-MAILLOG - Exception-Possible wrong Vault name given", hse)
        except ServiceRequestError:
            # Network error, I will let it raise to higher level
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical("EDI-PROOFPOINT-POD-MAILLOG - Exception- Azure SDK was not able to deal with my query", ae)
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical("EDI-PROOFPOINT-POD-MAILLOG - Exception- Unknown error I can't blame Azure for", e)
            raise


    def set_websocket_conn(self):

        logger.info( "EDI-PROOFPOINT-POD-MAILLOG- Executing - Function set_websocket_conn")

        self.readSecrets()

        url = f"wss://logstream.proofpoint.com:443/v1/stream?cid={self.cluster_id}&type={self.eventType}&sinceTime={self.startTime}&toTime={self.endTime}"
        logging.info('EDI-PROOFPOINT-POD-MAILLOG- Info - Opening Websocket logstream {}'.format(url))

        # defining headers for websocket connection (do not change this)
        header = {
            "Connection": "Upgrade",
            "Upgrade": "websocket",
            "Authorization": f"Bearer {self._token}",
            "Sec-WebSocket-Key": self.wsKey,
            "Sec-WebSocket-Version": "13"
        }
        sslopt = {
            'cert_reqs': ssl.CERT_REQUIRED,
            'ca_certs': certifi.where(),
            'check_hostname': True
        }
        try:
            proxy = os.getenv("OUTBOUND_PROXY").replace("http://", "").split(":")
            ws = websocket.create_connection(
                url
                ,header=header
                ,sslopt=sslopt
                ,http_proxy_host=proxy[0]
                ,http_proxy_port=proxy[1]
                ,proxy_type="http"
            )
            ws.settimeout(20)
            time.sleep(2)
            logging.info('EDI-PROOFPOINT-POD-MAILLOG -Success - Websocket connection established to cluster_id={}, event_type={}'.format(
                self.cluster_id, self.eventType))
            return ws

        except Exception as err:
            logging.error('EDI-PROOFPOINT-POD-MAILLOG - Exception - Function set_websocket_conn {}'.format(err))
            return None

    def gen_chunks_to_object(self, data, chunksize=100):
        try:
            logger.info( "EDI-PROOFPOINT-POD-MAILLOG- Executing - Function gen_chunks_to_object")
            chunk = []
            for index, line in enumerate(data):
                if (index % chunksize == 0 and index > 0):
                    yield chunk
                    del chunk[:]
                chunk.append(line)
            logger.info( "EDI-PROOFPOINT-POD-MAILLOG- Success - Function gen_chunks_to_object")    
            yield chunk
        except Exception as err:
            logging.error('EDI-PROOFPOINT-POD-MAILLOG - Exception - Function gen_chunks_to_object {}'.format(err)) 
            raise err 

    def gen_chunks(self, data):

        try:
            logger.info( "EDI-PROOFPOINT-POD-MAILLOG - Executing - Function gen_chunks")   
            for chunk in self.gen_chunks_to_object(data, chunksize=10000):
                obj_array = []
                for row in chunk:
                    if row != None and row != '':
                        y = json.loads(row)
                        y.update({'eventType': self.eventType})
                        obj_array.append(y)

                self.compressConnectUpload(obj_array, self.eventType + "_" + str(self.chunkNum))
                self.chunkNum += 1
            logger.info( "EDI-PROOFPOINT-POD-MAILLOG- Success - Function gen_chunks")  
        except Exception as err:
            logging.error('EDI-PROOFPOINT-POD-MAILLOG - Exception - Function gen_chunks {}'.format(err))   
            raise err    

    def run(self):
        #check if laststop exsists
        try:
            self.connectBlob()
            blob_client    = self.blobContainerClient.get_blob_client("{}/podMaillogLastStop.json".format(self.feedName))
            exists = blob_client.exists()

            if exists == True:
                logger.info("EDI-PROOFPOINT-POD-MAILLOG-Info - The lastStop file already exists")
                lastStop             = blob_client.download_blob().readall()
                self.lastStopContent = json.loads(lastStop)
                lastStopTime         = self.lastStopContent["laststopdt"]
                self.lastStopUtcTime = datetime.datetime.strptime(lastStopTime, '%Y-%m-%d %H:%M:%S')
                timeDelta =  datetime.datetime.utcnow() - self.lastStopUtcTime
                
                logger.info(f"EDI-PROOFPOINT-POD-MESSAGES-Info - The lastStop = {timeDelta.total_seconds()}, lastStop = {self.lastStopUtcTime}, utcnow = {datetime.datetime.utcnow()}")

                if timeDelta.total_seconds() < 3600:
                    logger.info("EDI-PROOFPOINT-POD-MAILLOG-Info - The lastStop is within 60minutes")
                    return

                start                = self.lastStopUtcTime.replace(second=0, microsecond=0, minute=0, hour=self.lastStopUtcTime.hour) - datetime.timedelta(hours=1)
                self.startTime       = start.isoformat()[:-3] + ":00.000-0000"
                self.endTime         = start.isoformat()[:-6] +":59:59.999-0000"
                self.lastStopUpdate  = self.lastStopUtcTime + datetime.timedelta(hours=1)
                
            else:
                logger.info("EDI-PROOFPOINT-POD-MAILLOG-Info- The lastStop file doesn't exists,loading data based on utcnow")
                start                = self.utcTimeNow.replace(second=0, microsecond=0, minute=0, hour = self.utcTimeNow.hour) - datetime.timedelta(hours=1)
                self.startTime       = start.isoformat()[:-3] + ":00.000-0000"
                self.endTime         = start.isoformat()[:-6] +":59:59.999-0000" 
                self.lastStopUpdate  = self.utcTimeNow + datetime.timedelta(hours=1)
                self.lastStopUpdate  = self.lastStopUpdate.strftime('%Y-%m-%d %H:%M:%S')

            sent_events = self.get_data()  
            return sent_events

        except Exception as e:
               logging.error('EDI-PROOFPOINT-POD-MAILLOG - Exception - Function checkLastStop {}'.format(e))  

    def get_data(self):

        try:

            logger.info( "EDI-PROOFPOINT-POD-MAILLOG- Executing - Function get_data")  

            sent_events = 0
            ws = self.set_websocket_conn()
            time.sleep(2)

            if ws is not None:
                events = []
                while True:
                    try:
                        data = ws.recv()
                        events.append(data)
                        sent_events += 1
                        if len(events) > self.blobRecordWriteSize:
                            self.gen_chunks(events)
                            events = []
                    except websocket._exceptions.WebSocketTimeoutException as terr:
                        # Reducing the amount of time an alert is triggered for this particular problem.
                        if "The read operation timed out" in str(terr):
                            logging.error('Failed WebSocketTimeoutException: {}'.format(terr))
                        else :
                            logging.error('Error WebSocketTimeoutException: {}'.format(terr))
                        # Keep connection if timeout occurs
                        time.sleep(2)
                        ws = self.set_websocket_conn()
                        break
                    except Exception as err:
                        # Reducing the amount of time an alert is triggered for this particular problem.
                        if "Connection to remote host was lost" in str(err):
                            logging.error('Failed while receiving data: {}'.format(err))
                        else:
                            logging.error('Error while receiving data: {}'.format(err)) 

                        # Keep connection on any other receive exception
                        time.sleep(2)
                        ws = self.set_websocket_conn()
                        break

                # try:
                #     ws.close()
                # except Exception as err:
                #     logging.error('Error while closing socket: {}'.format(err))

                if sent_events > 0:
                    self.gen_chunks(events)

            logging.info('EDI-PROOFPOINT-POD-MAILLOG- Success -Function get_data - Total events sent: {}. Type: {}. Period(UTC): {} - {}'.format(
                sent_events, self.eventType, self.startTime, self.endTime))

            self.writeSuccessFile(sent_events)
            
            #update the last stop file
            lastStop = {"laststopdt" : str(self.lastStopUpdate)}
            self.connectUpload(lastStop,"podMaillogLastStop.json")    

            return sent_events

        except Exception as e:
            logging.error("EDI-PROOFPOINT-POD-MAILLOG - Exception - Function get_data  >> {}".format(e))   
            raise e 

    def writeSuccessFile(self, sentEventsCount):  # construct success file and write to dest location
        try:
            logger.info("EDI-PROOFPOINT-POD-MAILLOG - Executing - Function writeSuccessFile")
            blob_list = self.blobContainerClient.list_blobs(
                name_starts_with="{}/{}/{}".format(
                    self.feedName, self.blobFolderName, self.epocSubFolderName))
            fileLoadedCount = len(list(blob_list))

            if fileLoadedCount > 0:  # write success file only when data is loaded
                successFile = {}
                successFile["ediFunctionName"]       = "kk-cde-edi-prd-neu-fa-py-ppoin-proofPointPodMaillog"
                successFile["ediTriggerType"]        = "TimerTrigger"
                successFile["ediFunctionLoadStatus"] = "Success"
                successFile["ediFeedRunStartDtTime"] = self.execStart
                successFile["ediFeedRunEndDtTime"]   = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                successFile["ediFilesWritten"]       = fileLoadedCount
                successFile["sentEventsCount"]       = sentEventsCount
                successFile["ediDestinationPath"]    = self.basePath

                self.connectUpload(successFile, "EDISTG_SUCCESS.json")

                logger.info("EDI-PROOFPOINT-POD-MAILLOG - Success - Function writeSuccessFile {}".format(self.basePath))
            else:
                logger.info("EDI-PROOFPOINT-POD-MAILLOG - There is no data loaded in target folder")
        except Exception as e:
            logging.error("EDI-PROOFPOINT-POD-MAILLOG - Exception - Function writeSuccessFile  >> {}".format(e))
            raise e

def main(mytimer: func.TimerRequest) -> None:
    logger.info('EDI-PROOFPOINT-POD-MAILLOG - Executing proofPoint POD LOG <MAILLOG> Function')
    mod = Export()  # create object for class
    sentEventsCount = mod.run()  # function call
    logger.info(" EDI-PROOFPOINT-POD-MAILLOG - Successfully executed Proofpoint POD LOG <MAILLOG> function sentEventsCount: " + str(sentEventsCount))
