
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
from typing import Callable, Dict, Optional
import requests
from retry import retry

from .constant import PSAT_CYBERSTRENGTH, PSAT_USERS, RETRY_INTERVAL, RETRY, PSAT_PHISHING_ALARM, PSAT_TRAINING_ENROLMENT, PSAT_PHISHING , PSAT_TRAINING
from .util import chunks
import math

class PsatAPI:
    def __init__(self, token: str, base_path: str, logging, config):
        self.base_path = base_path
        self.logging = logging
        self.token = token
        self.config = config

    @retry(Exception, tries=RETRY, delay=RETRY_INTERVAL)
    def get_users(self, page_size: int = 10):
        url = f"{self.base_path}/api/reporting/v0.1.0/users?page[size]={page_size}"
        yield from self._page_data(url)

    def _page_data(self, url: str):  # sourcery skip: raise-specific-error
        try:
            self.logging.info(f"requesting data  from {url} ")
            data = requests.get(
                url, headers={"x-apikey-token":  self.token}, proxies=self.config.proxyDict)
            pages_infomation = data.json().get("links", None)
            if data.json().get("message", None):
                raise Exception(data.json().get("message"))

            yield data.json()

            while pages_infomation is not None and pages_infomation.get("next", None) is not None:
                if next_api := pages_infomation.get("next", None):
                    url = f"{self.base_path}{next_api}"
                    self.logging.info(f"requesting data  from {url} ")
                    data = requests.get(
                        url, headers={"x-apikey-token":  self.token}, proxies=self.config.proxyDict)
                    pages_infomation = data.json().get("links", None) or None
                    yield data.json()
            return
        except Exception as e:
            self.logging.error(
                f"{self.config.function_name}-Exception - connecting to url: {url} >> " + str(e))
            raise e
        
        
    def extractdata(self, url,  pages):
        '''
        There is a exception handling that needs to happen here  
        '''
        buffer =[]
        
        def get_data(page_number: int):
            
            self.logging.info(f"requesting data  from {url} ")
            data = requests.get(
                self._start_with_page_number(url, page_number), headers={"x-apikey-token":  self.token}, proxies=self.config.proxyDict)
            if data.json().get("message", None):
                raise AttributeError(data.json().get("message"))
            return data.json()
        
        with ThreadPoolExecutor(os.cpu_count()) as pool:
            futures = [pool.submit(get_data, p) for p in pages]
            buffer.extend(future.result() for future in as_completed(futures))
        return buffer
        
    @retry(Exception, tries=RETRY, delay=RETRY_INTERVAL)
    def get_cyberstrength(self, page_size: int = 10, page_number: Optional[int] = 0):
        url = self._start_with_page_number(
            f"{self.base_path}/api/reporting/v0.1.0/cyberstrength?page[size]={page_size}", page_number)
        yield from self._page_data(url)

    @retry(Exception, tries=RETRY, delay=RETRY_INTERVAL)
    def get_training(self,  page_size: int = 10, page_number: Optional[int] = 0):
        url = self._start_with_page_number(
            f"{self.base_path}/api/reporting/v0.1.0/training?page[size]={page_size}", page_number)
        yield from self._page_data(url)

    @retry(Exception, tries=RETRY, delay=RETRY_INTERVAL)
    def get_phishing(self, page_size: int = 10, page_number: Optional[int] = 0):
        url = self._start_with_page_number(
            f"{self.base_path}/api/reporting/v0.1.0/phishing?page[size]={page_size}", page_number)
        yield from self._page_data(url)

    @retry(Exception, tries=RETRY, delay=RETRY_INTERVAL)
    def get_training_enrolment(self, page_size: int = 0, page_number: Optional[int] = 0):
        url = self._start_with_page_number(
            f"{self.base_path}/api/reporting/v0.1.0/trainingenrollments?page[size]={page_size}", page_number)
        yield from self._page_data(url)

    @retry(Exception, tries=RETRY, delay=RETRY_INTERVAL)
    def get_phishing_alarm(self, page_size: int = 10, page_number: Optional[int] = 0):
        url = self._start_with_page_number(
            f"{self.base_path}/api/reporting/v0.1.0/phishalarm?page[size]={page_size}", page_number)
        yield from self._page_data(url)

    def _start_with_page_number(self, url: str, page_number: int):
        return url if page_number == 0 else f"{url}&page[number]={page_number}"

    def get_page_batches(self, url , page_batch=20, page_number: Optional[int] = 0):
        self.logging.info(f"requesting data  from {url} ")
        def chunks(page_list, page_batch): return [page_list[x: x + page_batch] for x in range(0, len(page_list), page_batch)]
        data = requests.get(
            url, headers={"x-apikey-token":  self.token}, proxies=self.config.proxyDict)
        page_batch_segment = []
        if data.status_code == 200 and "meta" in data.json():
            count = int(data.json()["meta"]["count"])
            page_size = int(data.json()["meta"]["page_size"])
            page_list = list(range(0 + page_number, int(math.ceil(count/page_size) + 2)))
            page_batch_segment = list(chunks(page_list, page_batch))

        return {
            "url": f"{url}",
            "page_batch": page_batch_segment
        }

    def get_url_config(self, page_size=200, page_batch_size: int=20):
        return {
            PSAT_USERS: self.get_page_batches(f"{self.base_path}/api/reporting/v0.1.0/users?page[size]={page_size}" , page_batch_size),
            PSAT_CYBERSTRENGTH:  self.get_page_batches(f"{self.base_path}/api/reporting/v0.1.0/cyberstrength?page[size]={page_size}", page_batch_size),
            PSAT_PHISHING:  self.get_page_batches(f"{self.base_path}/api/reporting/v0.1.0/phishing?page[size]={page_size}", page_batch_size),
            PSAT_TRAINING_ENROLMENT :  self.get_page_batches(f"{self.base_path}/api/reporting/v0.1.0/trainingenrollments?page[size]={page_size}" , page_batch_size),
            PSAT_PHISHING_ALARM:   self.get_page_batches(f"{self.base_path}/api/reporting/v0.1.0/phishalarm?page[size]={page_size}", page_batch_size),
            PSAT_TRAINING :  self.get_page_batches(f"{self.base_path}/api/reporting/v0.1.0/training?page[size]={page_size}",page_batch_size)
        }
