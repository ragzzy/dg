import typing as t
from azure.storage.blob import ContentSettings, BlobServiceClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
import json
import gzip
from  .constant import BlobConnectionStrategy

class BlobService:

    def __init__(self, container_name: str, connection_string: str = None, connection_strategy: BlobConnectionStrategy = None, config = None,  logger=None):
        self.connection_string = connection_string
        self.container_name = container_name
        self.logger = logger
        self.strategy  = connection_strategy
        self.config = config
        self.blobContainerClient = self._setup()

    def _validateConnectionDetails():
        pass

    def _setup(self):
        try:
            
            if self.strategy == BlobConnectionStrategy.MSI_CONNECTION_STRING :
                self.logger.info(f"{self.config.function_friendly_name} - configuring connection to blob client")
                msiCredential = ManagedIdentityCredential()
                credentialChain = ChainedTokenCredential(msiCredential)
                blobServiceClient = BlobServiceClient(
                    self.connection_string, credential=credentialChain
                )
                self.logger.info(f"{self.config.function_friendly_name} - blob client configured")
            else:
                blobServiceClient = BlobServiceClient.from_connection_string(
                    conn_str=self.connection_string
                )
            return blobServiceClient.get_container_client(self.container_name)
        except Exception as e :
            self.logger.error(
                f"{self.config.function_friendly_name}-Exception - Creating a blob client with setup for : {self.config.feedName} >> " + str(e))
            raise e 
            
    def Upload(self, data: t.Any, blob_path: str, content_type: str,   overwrite_blob_if_exists: str = False):

        try:
            self.logger.info(f"{self.config.function_friendly_name} - starting file upload")

            try:
                blob = self.blobContainerClient.get_blob_client(blob_path)

                blobContentSettings = ContentSettings(
                    content_type=content_type
                )

                blob.upload_blob(
                    data, blob_type='BlockBlob', content_settings=blobContentSettings, overwrite=overwrite_blob_if_exists
                )
                self.logger.info(
                    f"{self.config.function_friendly_name} - Success - Executing Function Upload")
            except Exception as e:
                self.logger.error(
                    f"{self.config.function_friendly_name} -Exception - Uploading Blob:  {self.config.feedName}: " + blob_path + " >> " + str(e))
        except Exception as e:
            self.logger.error(
                f"{self.config.function_friendly_name}-Exception - connecting to Azure Blob Storage: {self.config.feedName} >> " + str(e))
            raise e

    def list_blobs(self, basePath: str, fullList: bool = False):
        try:
            self.logger.info(f"{self.config.function_friendly_name} - listing blob paths '{basePath}'")
            files = list(self.blobContainerClient.list_blobs(name_starts_with=basePath))
            self.logger.info(f"{self.config.function_friendly_name} - blob paths '{basePath}' successfully listed !")
            if not fullList: return len(files)
            return {'fileCount': len(files), 'files': [{'name':file['name'].replace(basePath,''), 'size':file['size']} for file in files]}
        except Exception as e:
            self.logger.error(f"{self.config.function_friendly_name} - Exception - listing blob  in '{basePath}' >> {e}")
            raise e

    def compress_upload(self, blob_path: str, data: t.Any):
        try:
            self.logger.info(f"{self.config.function_friendly_name}  - Executing- Function compressConnectUpload")
            dataInEncoded = data.encode('utf-8')
            dataOut = gzip.compress(dataInEncoded)
            blob = self.blobContainerClient.get_blob_client(blob_path)

            blobContentSettings = ContentSettings (
                content_encoding="gzip"
                ,content_type='application/octec-stream'
            )

            blob.upload_blob (
                dataOut
                ,blob_type='BlockBlob'
                ,content_settings=blobContentSettings
            )
            self.logger.info(f"{self.config.function_friendly_name}  - Success - Function compressConnectUpload")
        except Exception as e:
            self.logger.info(f"{self.config.function_friendly_name}  - Exception - Function compressConnectUpload")
            raise e
        
    def read_blobfile(self , blob_file_path , post_process_func: t.Callable=None):
        try:
            self.logger.info(f"{self.config.function_friendly_name}  - Executing- Function read_blobfile")
            blob =  self.blobContainerClient.get_blob_client(blob_file_path)
            if post_process_func:
                return post_process_func(blob.download_blob().readall())
            return blob.download_blob().readall()
        except  Exception as e:
            if hasattr(e, "message")  and "BlobNotFound" in e.message :
                self.logger.warning("EDI-AWS-CLOUDTRAIL-Warnings- Function loadBlob - BlobNotFound")
            self.logger.exception("EDI-AWS-CLOUDTRAIL-Exception- Function loadBlob")
            return None 