import os
from itertools  import  chain, islice
from typing import Iterator, Any, Callable, List
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

def chunks(iterable, size=10):
    iterator  =  iterable
    for first in iterator:
        result= chain([first], islice(iterator, size-1))
        yield result

def runParallel(func:Callable, delta:List, logger, function_friendly_name: str, *args):
    try:
        result = []
        with ThreadPoolExecutor(os.cpu_count()) as pool:
            futures = [pool.submit(func, i, args) for i in delta]
            result.extend(future.result() for future in as_completed(futures))
        return result

    except Exception as e:
        logger.error(f"{function_friendly_name} - Exception - Error:runParallel: {e}")
        raise e

def get_manifest(file_count: int, files: dict, status: str, function_friendly_name: str, basePath: str, execStart: str, function_name: str) -> dict :  
    StatusFile = {}
    StatusFile["ediFunctionName"]          = function_name
    StatusFile["ediTriggerType"]           = "TimerTrigger"
    StatusFile["ediFunctionLoadStatus"]    = status
    StatusFile["ediFeedRunStartDtTime"]    = execStart
    StatusFile["ediFeedRunEndDtTime"]      = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
    StatusFile["ediFilesWritten"]          = file_count
    StatusFile["batchInfo"]                = files
    StatusFile["ediDestinationPath"]       = basePath
    return StatusFile     