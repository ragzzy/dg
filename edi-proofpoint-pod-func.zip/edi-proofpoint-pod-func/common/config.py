
import os
import json
import time
from datetime import datetime, timezone, timedelta
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

from .constant import FAILURE_FILE_NAME, PSAT_FUNCTION_FRIENDLY_NAME, SUCCESS_FILE_NAME


class Config:

    def __init__(self, logger, feedName: str, fileNameSuffix: str, functionName: str, functionFriendlyName: str = PSAT_FUNCTION_FRIENDLY_NAME,
                                readSecrets_credential:  str = 'credentialsPSAT'):
        self.utcTimeNow = datetime.utcnow()
        self.execStart = self.utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.blobFolderName = self.utcTimeNow.strftime('%Y%m%d%H%M')
        self.endDate = self.utcTimeNow.strftime('%Y-%m-%d')
        self.logger = logger
        self.feedName = feedName
        self.fileNameSuffix = fileNameSuffix  # ".json.gz"
        self.epocSubFolderName = str(int(time.time()))
        self.basePath = "{}/{}/{}/".format(self.feedName, self.blobFolderName, self.epocSubFolderName)
        self.todayPath = "{}/{}/".format(self.feedName, self.blobFolderName)
        self.stop = datetime.now(tz=timezone.utc).replace(
            microsecond=0)-timedelta(seconds=10)
        self.stopprint = (self.stop.isoformat()+"Z").replace("+00:00", "")
        self.stopFileprint = (
            (self.stop+timedelta(seconds=1)).isoformat()+"Z").replace("+00:00", "")
        self.proxyDict = {"http": os.getenv(
            "OUTBOUND_PROXY") or os.getenv("http_proxy"), "https": os.getenv("OUTBOUND_PROXY") or os.getenv("https_proxy")}
        self.function_name = functionName
        self.function_friendly_name = functionFriendlyName
        self.container_name = "default"
        self.backup_container_name = "initconfig"
        self.extract_url="https://results.eu.securityeducation.com"
        self.baseURL = "https://tap-api-v2.proofpoint.com"
        self.efdBaseURL = "https://data.emaildefense.proofpoint.com"
        self.vaultUrl = os.getenv("DATASOURCE_KEYVAULT_URL")
        self.credentials = self._readSecrets(self.vaultUrl, logger, readSecrets_credential)

    def _readSecrets(self, vault_url: str , logger, credential: str):
        try:
            if os.getenv("token", None) is None: 
                logger.info(
                    f"{self.function_friendly_name} - Executing Function readSecrets- reading from keyault {vault_url}")
                secretClient = SecretClient(
                    vault_url=vault_url,
                    credential=ManagedIdentityCredential()
                )
                secret = secretClient.get_secret(credential)

                credentials = json.loads(secret.value)

            else:
                credentials  =  {
                    "token" : os.getenv("token"), 
                    "campaignSecret": os.getenv("campaignSecret"),
                    "campaignPrincipal": os.getenv("campaignPrincipal"),
                    "baseURL": os.getenv("baseURL"),
                    "efdBaseURL": os.getenv("efdBaseURL"),
                    "emailFraudDefenseKey": os.getenv("emailFraudDefenseKey"),
                    "emailFraudDefenseSecret": os.getenv("emailFraudDefenseSecret")
                }
            logger.info(f"{self.function_friendly_name} - Success : Executed Function readSecrets")
            return credentials
        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            self.logger.exception(
                f"{self.function_friendly_name} - Exception - Azure SDK was not able to connect to Key Vault")
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            self.logger.exception(
                f"{self.function_friendly_name} - Exception - Possible wrong Vault name given")        
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            self.logger.exception(
                f"{self.function_friendly_name} - Exception - Network Error")
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            self.logger.exception(
                f"{self.function_friendly_name} - Exception - Azure SDK was not able to deal with my query")
            raise
        except KeyError as ke:
            # check if the key vault URL is present in application insights
            self.logger.exception(
                f"{self.function_friendly_name} -Exception - Maybe Missing Key in Application Insights")
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            self.logger.critical(
                f"{self.function_friendly_name} - Exception - Unknown error I can't blame Azure for")
            raise
    
    
    def get_full_blob_path(self, file_name:str):
        if file_name is not None:
            return self.basePath + file_name + self.fileNameSuffix
        return None
    def get_success_manifest_blob_path(self):
            return self.basePath + SUCCESS_FILE_NAME + self.fileNameSuffix
    
    def get_failure_manifest_blob_path(self):
        return self.basePath + FAILURE_FILE_NAME + self.fileNameSuffix
    
    
    