
from enum import Enum
import os

APPLICATION_JSON_CONTENT='application/json'
FEED_NAME = "psat"
PSAT_FUNCTION_NAME = "kk-cde-edi-prd-neu-fa-py-ppoin-proofPointPSAT"
SUCCESS_FILE_NAME = "EDISTG_SUCCESS"
PSAT_FUNCTION_FRIENDLY_NAME = "EDI-PROOFPOINT-PSAT-FUNC"
FAILURE_FILE_NAME =  "EDISTG_FAILURE"
RETRY = os.getenv("RETRY", 100)
RETRY_INTERVAL = os.getenv("RETRY_INTERVAL", 10)

PSAT_USERS="user"
PSAT_PHISHING="phishing"
PSAT_TRAINING_ENROLMENT="training_enrolment"
PSAT_PHISHING_ALARM="phishing_alarm"
PSAT_TRAINING="training"
PSAT_CYBERSTRENGTH="cyberstrength"

class BlobConnectionStrategy(Enum):
    CONNECTION_STRING =1 
    MSI_CONNECTION_STRING=2