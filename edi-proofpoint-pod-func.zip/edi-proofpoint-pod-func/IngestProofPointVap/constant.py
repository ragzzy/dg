FEED_NAME = "vap" 
FUNCTION_NAME = "kk-cde-edi-prd-neu-fa-py-ppoin-proofPointVAP" 
FUNCTION_FRIENDLY_NAME = "EDI-PROOFPOINT-VAP-FUNC" 
