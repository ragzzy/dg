import json
import os
import requests
import logging
import base64
import azure.functions as func
from retry import retry
from datetime import datetime

from ..common import config, blob_service, util
from ..common.constant import BlobConnectionStrategy,RETRY, RETRY_INTERVAL, SUCCESS_FILE_NAME, FAILURE_FILE_NAME
from .constant import FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger(FEED_NAME)

class Export:
    def __init__(self):
        self.config = config.Config(logger, FEED_NAME, ".json", FUNCTION_NAME, FUNCTION_FRIENDLY_NAME, "credentials")
        connection_strategy  =  BlobConnectionStrategy.CONNECTION_STRING if os.getenv("isLocal", None) is not None else  BlobConnectionStrategy.MSI_CONNECTION_STRING
        self.blob_service = blob_service.BlobService(self.config.container_name, os.getenv("DATASOURCE_STORAGE_URL"), connection_strategy, self.config, logger)
        self.header = self.getHeader()

    def getHeader(self):
        logger.info(f"{self.config.function_friendly_name} - generating headers")
        try:
            header = f"{self.config.credentials['campaignPrincipal']}:{self.config.credentials['campaignSecret']}"
            header = base64.b64encode(header.encode('ascii'))
            logger.info(f"{self.config.function_friendly_name} - headers successfully generated !")
            return {"Authorization": "Basic "+ header.decode('ascii')}
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception - generating headers >> {e}")
            raise e


    @retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
    def getVap(self):
        logger.info(f"{self.config.function_friendly_name} - Executing Function getVap")
        try:
            req = requests.get(f"{self.config.baseURL}/v2/people/vap?window=30&size=3000", headers= self.header, proxies=self.config.proxyDict)
            data = req.json()
            logger.info(f"{self.config.function_friendly_name} - found {data['totalVapUsers']} users")
            self.blob_service.compress_upload(f"{self.config.basePath}proofpointvap.json.gz", json.dumps(data))
            logger.info(f"{self.config.function_friendly_name} - Success: Executed Function getVap")

        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function getVap >> {e}")
            raise e


    def run(self):
        try: 
            self.getVap()
            files = self.blob_service.list_blobs(self.config.basePath, True)
            file_count = len(files['files'])
            if file_count >0:
                manifest  = util.get_manifest(file_count, files, "SUCCESS", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
                self.blob_service.Upload(json.dumps(manifest), f"{self.config.basePath}{SUCCESS_FILE_NAME}.json", "application/json")
            else: logger.info(f"{self.config.function_friendly_name} - There is no data available to load to {self.config.basePath}")
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - pipeline has failed ")
            manifest  = util.get_manifest(file_count, files, "FAILURE", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
            self.blob_service.Upload(json.dumps(manifest), f"{self.config.basePath}{FAILURE_FILE_NAME}.json", "application/json")
            raise e
			

def main(mytimer: func.TimerRequest) -> None:
	try:
		logger.info(f"{FUNCTION_FRIENDLY_NAME} - Starting {FEED_NAME} Function")
		mod = Export()
		mod.run()
		logger.info(f"{FUNCTION_FRIENDLY_NAME} - pipeline has completed successfully!")
	except Exception as ex:
		logger.exception(f"{FUNCTION_FRIENDLY_NAME} - Exception - Export for PROOFPOINT-VAP")