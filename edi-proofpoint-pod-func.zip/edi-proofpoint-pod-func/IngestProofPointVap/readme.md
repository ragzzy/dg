# ProofPoint VAP

## Objective
- EDI pipeline to load VAP ProofPoint API

## RAW ingestion setup
- API: https://tap-api-v2.proofpoint.com
- Schedule for all possible endpoints: 24h at 09:00 UTC

## RAW file structure and definitions
- Function App: kk-cde-edi-prd-neu-fa-py-ppoin -> IngestProofPointVap
- Storage: default/vap/yyyymmddhhss/int(yyyymmddhhss)/ (edisaprdppoin)

| File | EndPoint | ~ Duration in dev (m) | ~ Size (KB) | # Chunks |   Params | 
| --- | --- | --- | --- | --- | --- |  --- |
| proofpointvap.json.gz | /v2/people/vap | 0:10 | 80 |  1 | window=30&size=3000 |

- Key Vault: edi-dev-prd-ppoin (EDI team)
- Success/Failure file: EDISTG_SUCCESS.json / EDISTG_FAILURE.json

## Highlights
- Average time in local: 15 seg
- Average time in dev (VM shared with mmoni): 15 seg
- Current Data Factory pipeline (LOAD_VAP -> edi-prd-adf-proofpoint): 1:30 min

## Contribute

