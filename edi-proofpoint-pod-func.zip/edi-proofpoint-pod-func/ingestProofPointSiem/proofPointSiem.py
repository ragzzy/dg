import os
import requests
import json
import time
import logging
import gzip
import azure.functions as func
from datetime import datetime, timezone, timedelta
from azure.storage.blob import ContentSettings, BlobServiceClient
from azure.identity import ManagedIdentityCredential, ChainedTokenCredential
from azure.keyvault.secrets import SecretClient
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)

# log error format
logging.basicConfig(format='%(asctime)s - %(message)s',datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("ppointsiem")


class Export:

    def __init__(self):

        self.utcTimeNow     = datetime.utcnow()
        self.execStart      = self.utcTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        self.blobFolderName = self.utcTimeNow.strftime('%Y%m%d%H%M')
        self.feedName       = "siem"
        self.fileNameSuffix = ".json.gz"
        self.epocSubFolderName = str(int(time.time()))
        self.basePath       = "{}/{}/{}/".format(self.feedName,self.blobFolderName, self.epocSubFolderName)
        self.stop           = datetime.now(tz=timezone.utc).replace(microsecond=0)-timedelta(seconds=10)
        self.stopprint      = (self.stop.isoformat()+"Z").replace("+00:00", "")
        self.stopFileprint  = ((self.stop+timedelta(seconds=1)).isoformat()+"Z").replace("+00:00", "")
        self.proxyDict      = {"http" : os.getenv("OUTBOUND_PROXY"),"https": os.getenv("OUTBOUND_PROXY")}

    def connectBlob(self):

        try:
            logger.info("EDI-PROOFPOINT-SIEM-FUNC - Executing Function connectBlob")

            msiCredential = ManagedIdentityCredential()
            credentialChain = ChainedTokenCredential(msiCredential)

            blobServiceClient = BlobServiceClient(
                os.getenv("DATASOURCE_STORAGE_URL")
                ,credential=credentialChain
            )
            self.blobContainerClient = blobServiceClient.get_container_client("default")

            logger.info("EDI-PROOFPOINT-SIEM-FUNC -  Success : Executed Function connectBlob")
        except Exception as err:
            logger.critical("EDI-PROOFPOINT-SIEM-FUNC - Exception - Error: Function connectBlob :{}".format(err))
            raise

    def connectUpload(self, data, fileName):

        try:
            logger.info("EDI-PROOFPOINT-SIEM-FUNC - Executing Function connectBlob")
            self.connectBlob()

            # create different path for success file and laststop
            if ("EDISTG_SUCCESS" in fileName):
                self.blobPath      = self.basePath + fileName  
                self.overWriteBool = False

            elif "lastStop" in fileName:
                self.blobPath = self.feedName+'/'+fileName
                self.overWriteBool = True

            try:
                dataOut = json.dumps(data)
                blob = self.blobContainerClient.get_blob_client(self.blobPath)

                blobContentSettings = ContentSettings (
                    content_type='application/json'
                )

                blob.upload_blob (
                    dataOut
                    ,blob_type='BlockBlob'
                    ,content_settings=blobContentSettings
                    ,overwrite = self.overWriteBool
                )
                logger.info("EDI-PROOFPOINT-SIEM-FUNC - Success - Executing Function connectUpload")
            except Exception as e:
                logger.error("EDI-PROOFPOINT-SIEM-FUNC -Exception - Uploading Blob:  siem: " + self.blobPath + " >> " + str(e))
        except Exception as e:
            logger.error(" EDI-PROOFPOINT-SIEM-FUNC -Exception - connecting to Azure Blob Storage: siem >> " + str(e))

    def readSecrets(self):
        try:
            logger.info("EDI-PROOFPOINT-SIEM-FUNC - Executing Function readSecrets")
            secretClient = SecretClient(
                            vault_url  = os.getenv("DATASOURCE_KEYVAULT_URL"), 
                            credential = ManagedIdentityCredential()
                            )
            secret = secretClient.get_secret("credentials")
            
            self.credentials = json.loads(secret.value)

            logger.info("EDI-PROOFPOINT-SIEM-FUNC - Success : Executed Function readSecrets")

        except ClientAuthenticationError as cae:
            # Can occur if either tenant_id, client_id or client_secret is incorrect
            logger.critical("EDI-PROOFPOINT-SIEM-FUNC - Exception - Azure SDK was not able to connect to Key Vault", cae)
        except HttpResponseError as hse:
            # One reason is when Key Vault Name is incorrect
            logger.critical("EDI-PROOFPOINT-SIEM-FUNC - Exception - Possible wrong Vault name given", hse)
        except ServiceRequestError as sre:
            # Network error, I will let it raise to higher level
            logger.critical("EDI-PROOFPOINT-SIEM-FUNC - Exception - Network Error", sre)
            raise
        except ResourceNotFoundError:
            # Let's assume it's not big deal here, just let it go
            pass
        except AzureError as ae:
            # Will catch everything that is from Azure SDK, but not the two previous
            logger.critical("EDI-PROOFPOINT-SIEM-FUNC - Exception - Azure SDK was not able to deal with my query", ae)
            raise
        except KeyError as ke:
            #check if the key vault URL is present in application insights
            logger.critical("EDI-PROOFPOINT-SIEM-FUNC -Exception - Maybe Missing Key in Application Insights", ke)
            raise
        except Exception as e:
            # Anything else that is not Azure related (network, stdlib, etc.)
            logger.critical("EDI-PROOFPOINT-SIEM-FUNC - Exception - Unknown error I can't blame Azure for", e)
            raise
     
        
    def writeSuccessFile(self):  # construct success file and write to dest location
        try:
            logger.info("EDI-PROOFPOINT-SIEM-FUNC - Executing - Function writeSuccessFile")
            self.connectBlob()

            blob_list = self.blobContainerClient.list_blobs(name_starts_with="{}/{}/{}".format(self.feedName, self.blobFolderName, self.epocSubFolderName))
            fileLoadedCount = len(list(blob_list))

            if fileLoadedCount > 0:  # write success file only when data is loaded
                successFile = {}
                successFile["ediFunctionName"]       = "kk-cde-edi-prd-neu-fa-py-ppoin-proofPointSiem"
                successFile["ediTriggerType"]        = "TimerTrigger"
                successFile["ediFunctionLoadStatus"] = "Success"
                successFile["ediFeedRunStartDtTime"] = self.execStart
                successFile["ediFeedRunEndDtTime"]   = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                successFile["ediFilesWritten"]       = fileLoadedCount
                successFile["ediDestinationPath"]    = self.basePath

                self.connectUpload(successFile, "EDISTG_SUCCESS.json")

                logger.info("EDI-PROOFPOINT-SIEM-FUNC - Success - Function writeSuccessFile {}".format(self.basePath))
            else:
                logger.info("EDI-PROOFPOINT-SIEM-FUNC - There is no data loaded in target folder")
        except Exception as e:
            logging.error("EDI-PROOFPOINT-SIEM-FUNC - Exception - Function writeSuccessFile  >> {}".format(e))   


    def compressConnectUpload(self, data, fileName):

        try:

            logger.info("EDI-PROOFPOINT-SIEM-FUNC- Executing - Function compressConnectUpload")

            self.blobPath = self.basePath + fileName + self.fileNameSuffix
            dataIn = json.dumps(data)
            dataInEncoded = dataIn.encode('utf-8')
            dataOut = gzip.compress(dataInEncoded)

            try:
                self.connectBlob()

                try:
                    blob = self.blobContainerClient.get_blob_client(self.blobPath)

                    blobContentSettings = ContentSettings (
                        content_encoding = "gzip"
                        ,content_type = 'application/octec-stream'
                    )

                    blob.upload_blob (
                        dataOut
                        ,blob_type='BlockBlob'
                        ,content_settings=blobContentSettings
                        
                    )

                    logger.info("EDI-PROOFPOINT-SIEM-FUNC - Success- Function compressConnectUpload")
                except Exception as e:
                    logger.error("EDI-PROOFPOINT-SIEM-FUNC - Exception - compressConnectUpload: " + self.blobPath + " >> " + str(e))
            except Exception as e:
                logger.error("EDI-PROOFPOINT-SIEM-FUNC - Exception - compressConnectUpload connecting to Azure Blob Storage >> " + str(e))

        except Exception as e:
            logger.error("EDI-PROOFPOINT-SIEM-FUNC - Exception - Error Gzipping data >> {}".format(e))         

    def download(self):

        logger.info("EDI-PROOFPOINT-SIEM-FUNC - Executing- Function download")

        self.readSecrets()

        #check if laststop exsists
        self.connectBlob()

        blob_client    = self.blobContainerClient.get_blob_client("{}/lastStop.json".format(self.feedName))
        exists = blob_client.exists()

        if exists == True:
            lastStop = blob_client.download_blob().readall()
            self.lastStopContent = json.loads(lastStop)
            self.startprint = self.lastStopContent["laststopdt"]
            #take my last stop as datetime object
            datetime_object = datetime.strptime(self.startprint, '%Y-%m-%dT%H:%M:%SZ')
            #logger.info("my last stop date is ", datetime_object)
            
            #check time difference
            diff = self.utcTimeNow - datetime_object
            days, seconds = diff.days, diff.seconds
            hours = days * 24 + seconds // 3600
            logger.info("EDI-PROOFPOINT-SIEM-FUNC - Info - my time difference in hours is {}".format(hours))
            #if hours is greater than 1 then; load stopprint for 1 hour from laststop
            if hours > 1:
                self.oneHourFromLastStop = datetime_object + timedelta(hours=1)
                self.stopprint = self.oneHourFromLastStop.strftime('%Y-%m-%dT%H:%M:%SZ')
                logger.info("EDI-PROOFPOINT-SIEM-FUNC - Info - one hour from last stop date is {}".format(self.stopprint))
                self.stopFileprint =  ((self.oneHourFromLastStop+timedelta(seconds=1)).isoformat()+"Z").replace("+00:00", "") 

        else:
            self.startprint = ((datetime.now(tz=timezone.utc).replace(microsecond=0)-timedelta(seconds=610)).isoformat()+"Z").replace("+00:00", "")
            self.lastStopContent = {"laststopdt": self.startprint}
            self.startprint = self.lastStopContent["laststopdt"]

         
        interval = self.startprint + "/" + self.stopprint
        logger.info("EDI-PROOFPOINT-SIEM-FUNC -Info - Requesting data for {}".format(interval))

        for i in range(0, 10):
            try:
                req = requests.get("https://tap-api-v2.proofpoint.com/v2/siem/all?format=json&interval="+interval, 
                auth=(self.credentials['principal']
                , self.credentials['secret'])
                ,proxies = self.proxyDict
                )
                break

            except Exception as e:
                if i == 9:
                    logger.warning("EDI-PROOFPOINT-SIEM-FUNC - Exception - Function download failed - {}".format(e))
                    raise e

                logger.debug("EDI-PROOFPOINT-SIEM-FUNC - Exception -Function download failed, retrying in 10s - {}".format(e))
                time.sleep(10)

        if (req.status_code != 400) and list(str(req.status_code))[0] == "2":

            resp = req.json()

            resp['campaigns'] = self.extractCampaigns(resp)

            self.compressConnectUpload(resp,"siem") 

            lastStop = {"laststopdt" : self.stopFileprint}

            self.connectUpload(lastStop,"lastStop.json")

            self.writeSuccessFile()

            logger.info("EDI-PROOFPOINT-SIEM-FUNC - Success- Function download")


    def extractCampaigns(self, data):

        logger.info("EDI-PROOFPOINT-SIEM-FUNC - Executing- Function extractCampaigns")

        campaignIDs = set()
        campaigns = []

        if len(data['messagesBlocked']) == 0:
            return campaigns

        for m in data['messagesBlocked']:
            if 'threatsInfoMap' not in m:
                continue

            for tm in m['threatsInfoMap']:
                if 'campaignID' in tm and tm['campaignID'] is not None:
                    campaignIDs.add(tm['campaignID'])

        for i in campaignIDs:
            campaigns.append(self.downloadCampaign(i))

        logger.info("EDI-PROOFPOINT-SIEM-FUNC - Success- Function extractCampaigns")
        return campaigns


    def downloadCampaign(self, campaignID):

        logger.info("EDI-PROOFPOINT-SIEM-FUNC - Executing- Function downloadCampaign")

        logger.info("downloadCampaign {}".format(campaignID))

        for i in range(0, 10):
            try:
                req = requests.get("https://tap-api-v2.proofpoint.com/v2/campaign/"+campaignID,
                auth=(self.credentials['campaignPrincipal']
                ,self.credentials['campaignSecret'])
                ,proxies = self.proxyDict
                )
                break

            except Exception as e:
                if i == 9:
                    logger.error("EDI-PROOFPOINT-SIEM-FUNC - Function downloadCampaign failed")
                    raise e

                logger.debug("EDI-PROOFPOINT-SIEM-FUNC - Function downloadCampaign failed, retrying in 10s")
                time.sleep(10)

        if req.status_code != 400 and req.status_code == 200:

            resp = req.json()
            resp['campaignID'] = campaignID

            logger.info("EDI-PROOFPOINT-SIEM-FUNC - Success- Function downloadCampaign")
            return resp

# For Timer trigger
# {
#   "scriptFile": "proofPointSiem.py",
#   "bindings": [
#     {
#       "name": "mytimer",
#       "type": "timerTrigger",
#       "direction": "in",
#       "schedule": "0 */10 * * * *"
#     }
#   ]
# }	

def main(mytimer: func.TimerRequest) -> None:
    logger.info('EDI-PROOFPOINT-SIEM-FUNC - Executing proofPoint SIEM Function')
    mod = Export()  # create object for class
    mod.download()  # function call
    logger.info('EDI-PROOFPOINT-SIEM-FUNC - Successfully Executed proofPoint SIEM Function')

# For HTTP Trigger
# {
#   "scriptFile": "proofPointSiem.py",
#   "bindings": [
#     {
#       "authLevel": "anonymous",
#       "type": "httpTrigger",
#       "direction": "in",
#       "name": "req",
#       "methods": [
#         "get",
#         "post"
#       ]
#     },
#     {
#       "type": "http",
#       "direction": "out",
#       "name": "$return"
#     }
#   ]
# }

# def main(req: func.HttpRequest) -> func.HttpResponse:
#     logger.info('EDI-PROOFPOINT-SIEM-FUNC - Executing Export as standalone script')
#     mod = Export()  # create object for class
#     mod.download()  # function call
#     logger.info('EDI-PROOFPOINT-SIEM-FUNC - Successfully Executed proofPoint SIEM Function')
#     return func.HttpResponse('EDI-PROOFPOINT-SIEM-FUNC - Successfully Executed proofPoint SIEM Function')  
  

