from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import logging
import os
import json
from pickle import TRUE
import azure.functions as func
import uuid
from ..common import constant,  util, config, blob_service, psat_api

logging.basicConfig(format='%(asctime)s - %(message)s',
                    datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger("ppointpssat")


def main(mytimer: func.TimerRequest) -> None:
    try:
        export = Export()
        export.run()

    except Exception as ex:
        logger.exception(
            f"{constant.PSAT_FUNCTION_FRIENDLY_NAME} - Exception - Export for PSAT Feeds")
        raise ex


class Export:
    def __init__(self):
        self.export_config = config.Config(
            logger, constant.FEED_NAME, ".json", constant.PSAT_FUNCTION_NAME)

        connection_strategy = constant.BlobConnectionStrategy.CONNECTION_STRING if os.getenv(
            "isLocal", None) is not None else constant.BlobConnectionStrategy.MSI_CONNECTION_STRING
        self.blob_service = blob_service.BlobService(self.export_config.container_name, os.getenv(
            "DATASOURCE_STORAGE_URL"), connection_strategy, self.export_config, logger)
        self.psat_api = psat_api.PsatAPI(self.export_config.credentials.get(
            "token"), self.export_config.extract_url, logger, self.export_config)
       # self.completed_checkpoint , self.checkpoint  =  self._read_checkpoint(self.export_config)

    def _run(self):
        """
        run the extract for the  psat API
        uploads the extract into the blob storage
        """
        try:
            api_config = {
                "user": self.psat_api.get_users,
                "training":  self.psat_api.get_training,
                "training_enrollment":  self.psat_api.get_training_enrolment,
                "phishalarm":  self.psat_api.get_phishing_alarm,
                "phishing":  self.psat_api.get_phishing,
                "cyberstrength":  self.psat_api.get_cyberstrength
            }

            number_of_document_per_request = 200
            number_of_document_batch_for_upload = 10
            for filename, method in api_config.items():
                logger.info(
                    f"{self.export_config.function_name} - Extracting data from the proofpoint api - {filename}")
                for page_count, page_request in enumerate(util.chunks(method(number_of_document_per_request), number_of_document_batch_for_upload)):
                    path = self.export_config.get_full_blob_path(
                        f"{filename}_{page_count}")
                    data = list(page_request)
                    self.blob_service.Upload(json.dumps(
                        data), path, constant.APPLICATION_JSON_CONTENT, False)
                    logger.info(
                        f"{self.export_config.function_name} - data extracted from the proofpoint api - {path}")

                logger.info(
                    f"{self.export_config.function_name} - data extracted from the proofpoint api - {filename}")

            file_count = self.blob_service.list_blobs(
                self.export_config.basePath)
            manifest = self.get_success_manifest(
                self.export_config, file_count)
            manifest_path = self.export_config.get_success_manifest_blob_path()
            self.blob_service.Upload(json.dumps(
                manifest), manifest_path, constant.APPLICATION_JSON_CONTENT, TRUE)
        except Exception as ex:
            file_count = self.blob_service.list_blobs(
                self.export_config.basePath)
            manifest = self.get_failure_manifest(
                self.export_config, file_count)
            manifest_path = self.export_config.get_failure_manifest_blob_path()
            self.blob_service.Upload(
                json.dumps(manifest),
                manifest_path,
                constant.APPLICATION_JSON_CONTENT,
                TRUE,
            )

            logger.critical(
                f'{self.export_config.function_name} - Exception - Export run failed for path {self.export_config.basePath}',
                str(ex),
            )

    def run(self):
        """
        run the extract for the  psat API
        uploads the extract into the blob storage
        """
        try:
            number_of_document_per_request = 200
            number_of_document_batch_for_upload = 60
            api_config = self.psat_api.get_url_config(
                number_of_document_per_request, number_of_document_batch_for_upload)

            def _extract_all_dataset(filename, config):
                url = config["url"]
                page_batch: list[int] = config["page_batch"]
                for batch in page_batch:
                    try:
                        data = self.psat_api.extractdata(url, batch)
                        path = self.export_config.get_full_blob_path(
                            f"{filename}_{uuid.uuid4().hex}")
                        self.blob_service.Upload(json.dumps(
                            data), path, constant.APPLICATION_JSON_CONTENT, False)
                        logger.info(
                            f"{self.export_config.function_name} - data extracted from the proofpoint api - {path}")
                    except Exception as ex:
                        return {
                            filename:  {
                                "count": sorted(batch)[1][-1],
                                "exception":  str(ex)
                            }
                        }
                if len(page_batch) > 0:
                    return {
                        filename:  {
                            "count": sorted(page_batch)[-1],
                            "exception":  None
                        }
                    }
                else:
                    return {
                        filename:  {
                            "count": 0,
                            "exception":  None
                        }
                    }

            result = []
            with ThreadPoolExecutor(os.cpu_count()) as pool:
                futures = [pool.submit(_extract_all_dataset, filename, config)
                           for filename, config in api_config.items()]
                result.extend(future.result()
                              for future in as_completed(futures))

            for res in result:
                for r, stats in res.items():
                    if stats["exception"] is not None:
                        logger.info(
                            f'{r} failed at count {stats["exception"]}')

            file_count = self.blob_service.list_blobs(
                self.export_config.basePath)
            manifest = self.get_success_manifest(
                self.export_config, file_count)
            manifest_path = self.export_config.get_success_manifest_blob_path()
            self.blob_service.Upload(json.dumps(
                manifest), manifest_path, constant.APPLICATION_JSON_CONTENT, TRUE)

        except Exception as ex:
            file_count = self.blob_service.list_blobs(
                self.export_config.basePath)
            manifest = self.get_failure_manifest(
                self.export_config, file_count)
            manifest_path = self.export_config.get_failure_manifest_blob_path()
            self.blob_service.Upload(
                json.dumps(manifest),
                manifest_path,
                constant.APPLICATION_JSON_CONTENT,
                TRUE,
            )

            logger.critical(
                f'{self.export_config.function_name} - Exception - Export run failed for path {self.export_config.basePath}',
                str(ex),
            )

    def _read_checkpoint(self, export_config):
        checkpoint = self.blob_service.read_blobfile(
            export_config.todayPath + "_checkpoint.json", json.loads)
        completed = self.blob_service.read_blobfile(
            export_config.todayPath + "_completed_checkpoint.json", json.loads)
        return (completed, self.get_checkpoint()) if checkpoint is None else (completed, checkpoint)

    def get_success_manifest(self, export_config, number_of_files: int):
        return {
            'ediFunctionName': export_config.function_name,
            'ediTriggerType': 'TimerTrigger',
            'ediFunctionLoadStatus': 'Success',
            'ediFeedRunStartDtTime': export_config.execStart,
            'ediFeedRunEndDtTime': datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ'),
            'ediFilesWritten': number_of_files,
            'ediDestinationPath': export_config.basePath,
        }

    def get_failure_manifest(self, export_config, number_of_files: int):
        return {
            'ediFunctionName': export_config.function_name,
            'ediTriggerType': 'TimerTrigger',
            'ediFunctionLoadStatus': 'Failure',
            'ediFeedRunStartDtTime': export_config.execStart,
            'ediFeedRunEndDtTime': datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ'),
            'ediFilesWritten': number_of_files,
            'ediDestinationPath': export_config.basePath,
        }

    def get_checkpoint(self, user: int = 0, training: int = 0, training_enrollment: int = 0, phishing: int = 0,  phishalarm: int = 0, cyberstrength: int = 0):
        return {
            "user": 0 if user == 0 else user,
            "training":  0 if training == 0 else training,
            "training_enrollment":  0 if training_enrollment == 0 else training_enrollment,
            "phishalarm":  0 if phishalarm == 0 else phishalarm,
            "phishing":  0 if phishing == 0 else phishing,
            "cyberstrength":  0 if cyberstrength == 0 else cyberstrength
        }
