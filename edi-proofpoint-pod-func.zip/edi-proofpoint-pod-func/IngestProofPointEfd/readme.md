# ProofPoint VAP

## Objective
- EDI pipeline to load VAP ProofPoint API

## RAW ingestion setup
- API: https://tap-api-v2.proofpoint.com
- Schedule for all possible endpoints: 24h at 03:00 UTC

## RAW file structure and definitions
- Function App: kk-cde-edi-prd-neu-fa-py-ppoin -> IngestProofPointEfd
- Storage: default/efd/yyyymmddhhss/int(yyyymmddhhss)/ (edisaprdppoin)
* starDate = default/efd/lastStop.json -> format 'yyyy-mm-dd'
* endDate  = current day -> format 'yyyy-mm-dd'

| File | EndPoint | ~ Duration in dev (m) | ~ Size (B) | # Chunks |   Params | 
| --- | --- | --- | --- | --- | --- |  --- |
| domains.json | /v1/domains | 00:05 | 5.3M |  1 | - |
| ipviewer.json.gz | /v1/ip-viewer/reporters | 00:05 | 1.5K |  1 |- |
| reports_dmarc_auth.json | /v1/reports/dmarc-authentication | 00:05 | 250 |  1 | start_date={startDate}&end_date={endDate} |
| reports_dmarc_coverage_domains.json | /v1/reports/dmarc-coverage-domains | 00:10 | 430 |  1 | start_date={startDate}&end_date={endDate} |
| reports_dmarc_coverage_messages.json | /v1/reports/dmarc-coverage-messages | 00:05 | 270 |  1 | start_date={startDate}&end_date={endDate} |
| reports_dmarc_coverage_effectiveness.json | /v1/reports/dmarc-effectiveness | 00:05 | 430 |  1 |  start_date={startDate}&end_date={endDate} |
| reports_aggregate_domains.json | /v1/reports/aggregate-domains |  00:05 | 75.2K |  1 |  start_date={startDate}&end_date={endDate} |
| threats_tophits.json | /v1/threats/top-hits |  00:01 | 10 |  1 |  start_date={startDate}&end_date={endDate} |

- Key Vault: edi-prd-akv-ppoin (EDI team)
- Success/Failure file: EDISTG_SUCCESS.json / EDISTG_FAILURE.json

## Highlights
- Average time in local: 40 seg
- Average time in dev (VM shared with mmoni): 1 min
- Current Data Factory pipeline (LOAD_EFD -> edi-prd-adf-proofpoint): 3 min
- default/efd/lastStop.json is updated each run to the current day
- If startDate >= endDate, starDate will be modified to endDate -1 day
- All files that include as a parameter startDate would be zipped if they were paginated 

## Contribute

