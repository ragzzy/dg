import json
import os
from tracemalloc import start
import requests
import logging
import base64
import azure.functions as func
from retry import retry
from datetime import datetime
from datetime import timedelta

from ..common import config, blob_service, util
from ..common.constant import BlobConnectionStrategy,RETRY, RETRY_INTERVAL, SUCCESS_FILE_NAME, FAILURE_FILE_NAME
from .constant import FEED_NAME, FUNCTION_NAME, FUNCTION_FRIENDLY_NAME

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger(FEED_NAME)

class Export:
    def __init__(self):
        self.config = config.Config(logger, FEED_NAME, ".json", FUNCTION_NAME, FUNCTION_FRIENDLY_NAME, "credentials")
        connection_strategy  =  BlobConnectionStrategy.CONNECTION_STRING if os.getenv("isLocal", None) is not None else  BlobConnectionStrategy.MSI_CONNECTION_STRING
        self.blob_service = blob_service.BlobService(self.config.container_name, os.getenv("DATASOURCE_STORAGE_URL"), connection_strategy, self.config, logger)
        self.header = self.getHeader()
        self.backup_blob_service = blob_service.BlobService(self.config.backup_container_name, os.getenv("DATASOURCE_STORAGE_URL"), connection_strategy, self.config, logger)


    @retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
    def getData(self, page, args):
        endpoint, api = args[0], args[1]
        logger.info(f"{self.config.function_friendly_name} - Executing Function getData for {endpoint} from page {page}")
        try:
            req = requests.get(f"{self.config.efdBaseURL}{api}{page}", headers=self.header,  proxies=self.config.proxyDict)
            logger.info(f"{self.config.function_friendly_name} - Success: Function getData for {endpoint} from page {page}")
            return req.json()
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function getData for {endpoint} from page {page} >> {e}")
            raise e


    def getHeader(self):
        logger.info(f"{self.config.function_friendly_name} - Executing Function getHeader")
        try:
            header = f"{self.config.credentials['emailFraudDefenseKey']}:{self.config.credentials['emailFraudDefenseSecret']}"
            header = base64.b64encode(header.encode('ascii'))
            logger.info(f"{self.config.function_friendly_name} - Success: Function getHeader")
            return {"Authorization": "Basic "+ header.decode('ascii')}     
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function getHeader >> {e}")
            raise e

    
    def getValidData(self, endpoint: str, api: str, output: str, pages: list, total_results: int):
        logger.info(f"{self.config.function_friendly_name} - Executing Function getValidData for {endpoint}")
        tries = RETRY
        try:
            for i in range(tries): 
                data = util.runParallel(self.getData, pages, logger, self.config.function_friendly_name, endpoint, api)
                val_total_results = 0
                for sample in data:
                    if type(sample[output]) == list: val_total_results += len(sample[output])
                if val_total_results < total_results and (i+1)< tries: 
                    logger.warning(f"{self.config.function_friendly_name} - Retrying: Function  getValidData for {endpoint} >> Missmatching current total results with original data")
                    continue
                elif val_total_results < total_results: logger.warning(f"{self.config.function_friendly_name} - found {val_total_results} from {total_results} results for {endpoint}")
                else: logger.info(f"{self.config.function_friendly_name} - found {val_total_results} results for {endpoint}")
                logger.info(f"{self.config.function_friendly_name} - Success: Function getValidData for {endpoint}")
                return data
            raise Exception("Impossible to get valid data after {tries} tries")
        except Exception  as e:
                logger.error(f"{self.config.function_friendly_name} - Exception: Function getValidData for {endpoint} >> {e}")
                raise e


    def loadData(self, api: str, filename: str, endpoint: str, compress : bool = False):
        logger.info(f"{self.config.function_friendly_name} - Executing Function loadData for {endpoint}")
        try:
            req = requests.get(f"{self.config.efdBaseURL}{api}", headers= self.header, proxies=self.config.proxyDict)
            data = req.json()
            if "pagination" in data.get('metadata', {}).keys():
                pages = [str(i) for i in range(1,int(data['metadata']["pagination"]['totalPages'])+1)]
                logger.info(f"{self.config.function_friendly_name} - found {pages[-1]} pages")
                total_count = int(data['metadata']["pagination"]['totalItemCount'])
                data = self.getValidData(endpoint, f'{api}&page_num=', 'data', pages, total_count)
                compress = True
            else: logger.info(f"{self.config.function_friendly_name} - found {len(data)} {endpoint}")
            if not compress: 
                self.blob_service.Upload(json.dumps(data), f"{self.config.basePath}{filename}.json", "application/json", True)
            else:
                self.blob_service.compress_upload(f"{self.config.basePath}{filename}.json.gz", json.dumps(data))
            logger.info(f"{self.config.function_friendly_name} - Success: Executed Function loadData for {endpoint}")
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function loadData for {endpoint} >> {e}")
            raise e


    @retry(Exception, tries= RETRY, delay= RETRY_INTERVAL)
    def lookLastStop(self):
        logger.info(f"{self.config.function_friendly_name} - Executing Function lookLastStop")
        try:
            files = [file['name'] for file in self.blob_service.list_blobs(self.config.feedName, True)['files']]
            blob = self.blob_service.blobContainerClient.get_blob_client(f'{self.config.feedName}/lastStop.json')
            if '/lastStop.json' not in files:
                logger.info(f"{self.config.function_friendly_name} - 'lastStop.json' was not found in {self.config.feedName}")
                sourceBlob = self.backup_blob_service.blobContainerClient.get_blob_client('lastStop.json')
                blob.start_copy_from_url(sourceBlob.url, requires_sync=True)
                logger.info(f"{self.config.function_friendly_name} - 'lastStop.json' successfully copied in {self.config.feedName}")
            data = blob.download_blob().readall()
            startDate = json.loads(data)['laststopdt']
            try:
                startDate = datetime.strptime(startDate, '%Y-%m-%d')
            except:
                startDate = datetime.strptime(startDate, '%d/%m/%Y %H:%M:%S')
            logger.info(f"{self.config.function_friendly_name} - Success: Function lookLastStop")
            return startDate.strftime('%Y-%m-%d')
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function lookLastStop >> {e}")
            raise e

    
    def validateDates(self, startDate : str, endDate : str):
        logger.info(f"{self.config.function_friendly_name} - Executing Function validateDates")
        try:
            startDate = datetime.strptime(startDate, '%Y-%m-%d')
            endDate = datetime.strptime(endDate, '%Y-%m-%d')
            if startDate >= endDate:
                startDate = endDate - timedelta(days=1)
                logger.warning(f"{self.config.function_friendly_name} - startDate was greater or equal than endDate >> Modified to endDate -1 day")
            logger.info(f"{self.config.function_friendly_name} - Success: Function validateDates")
            return startDate.strftime('%Y-%m-%d'), endDate.strftime('%Y-%m-%d')
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - Exception: Function validateDates >> {e}")
            raise e


    def run(self):
        try:
            startDate = self.lookLastStop()
            endDate = self.config.endDate
            startDate, endDate = self.validateDates(startDate, endDate)
            logger.info(f"{self.config.function_friendly_name} - startDate {startDate} & endDate {endDate}")
            self.loadData("/v1/domains", "domains", "Domains")
            self.loadData("/v1/ip-viewer/reporters?", "ipviewer", "IP Viewers", True)
            self.loadData(f"/v1/reports/dmarc-authentication?start_date={startDate}&end_date={endDate}", "reports_dmarc_auth", "DMARC Auth Reports")
            self.loadData(f"/v1/reports/dmarc-coverage-domains?start_date={startDate}&end_date={endDate}", "reports_dmarc_coverage_domains", "DMARC Coverage Domains Reports")
            self.loadData(f"/v1/reports/dmarc-coverage-messages?start_date={startDate}&end_date={endDate}", "reports_dmarc_coverage_messages", "DMARC Coverage Messages Reports")
            self.loadData(f"/v1/reports/dmarc-effectiveness?start_date={startDate}&end_date={endDate}", "reports_dmarc_coverage_effectiveness", "DMARC Coverage Effectiveness Reports")
            self.loadData(f"/v1/reports/aggregate-domains?start_date={startDate}&end_date={endDate}", "reports_aggregate_domains", "Aggregate Domains Reports")
            self.loadData(f"/v1/threats/top-hits?start_date={startDate}&end_date={endDate}", "threats_tophits", "Threats Tophits")
            self.blob_service.Upload(json.dumps({"laststopdt": endDate}), f'{self.config.feedName}/lastStop.json', "application/json", True)
            logger.info(f"{self.config.function_friendly_name} - 'lastStop.json' successfully updated to {endDate} ! ")
            files = self.blob_service.list_blobs(self.config.basePath, True)
            file_count = len(files['files'])
            if file_count >0:
                manifest  = util.get_manifest(file_count, files, "SUCCESS", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
                self.blob_service.Upload(json.dumps(manifest), f"{self.config.basePath}{SUCCESS_FILE_NAME}.json", "application/json")
            else: logger.info(f"{self.config.function_friendly_name} - There is no data available to load to {self.config.basePath}")
        except Exception as e:
            logger.error(f"{self.config.function_friendly_name} - pipeline has failed ")
            manifest  = util.get_manifest(file_count, files, "FAILURE", self.config.function_friendly_name, self.config.basePath, self.config.execStart, self.config.function_name)
            self.blob_service.Upload(json.dumps(manifest), f"{self.config.basePath}{FAILURE_FILE_NAME}.json", "application/json")
            raise e
			

def main(mytimer: func.TimerRequest) -> None:
	try:
		logger.info(f"{FUNCTION_FRIENDLY_NAME} - Starting {FEED_NAME} Function")
		mod = Export()
		mod.run()
		logger.info(f"{FUNCTION_FRIENDLY_NAME} - pipeline has completed successfully !")
	except Exception as ex:
		logger.exception(f"{FUNCTION_FRIENDLY_NAME} - Exception - Export for PROOFPOINT-EFD")