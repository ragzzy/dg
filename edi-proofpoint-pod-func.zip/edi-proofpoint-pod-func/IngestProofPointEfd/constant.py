FEED_NAME = "efd" 
FUNCTION_NAME = "kk-cde-edi-prd-neu-fa-py-ppoin-proofPointEFD" 
FUNCTION_FRIENDLY_NAME = "EDI-PROOFPOINT-EFD-FUNC" 
